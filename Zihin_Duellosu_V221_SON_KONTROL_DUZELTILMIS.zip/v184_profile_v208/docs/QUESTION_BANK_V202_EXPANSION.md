# Zihin Düellosu V202 — Genişletilmiş Soru Bankası

Önceki banka: 1428
Yeni eklenen kayıt: 1059
Toplam benzersiz soru: 2487

Genel Kültür ve İngilizce Gramer diğer kategorilere göre daha yüksek ekleme hedefiyle genişletildi. İngilizce tarafında tense, modal, passive, reported speech, conditionals, relative clauses, articles, prepositions, quantifiers, gerund/infinitive ve phrasal verbs gibi mevcut konu başlıkları korunmuştur.

KPSS için ÖSYM'nin yayımladığı sınav arşivi ve 2024/2025 Genel Yetenek-Genel Kültür materyalleri soru tarzı ve konu kapsamı referansı olarak kullanılmıştır. ÖSYM soruları telifli olduğu için özgün soru metni yerine konu/beceri temelli içerik kullanılmıştır.
