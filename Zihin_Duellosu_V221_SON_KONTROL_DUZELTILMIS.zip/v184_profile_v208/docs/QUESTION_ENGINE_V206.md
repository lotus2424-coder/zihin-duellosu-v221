# V206 — Soru Kalitesi ve Adaptif Motor

- Soru köklerindeki eski şablon ifadeler temizlendi.
- Kısa/fragman sorular kategoriye uygun doğal soru köklerine dönüştürüldü.
- 4 seçenek ve doğru cevap doğrulaması korunuyor.
- Kalite puanı 70 altındaki kayıtlar motor tarafından havuza alınmıyor.
- Aynı soru ve aynı bilgi ailesi aynı tur içinde tekrar gösterilmiyor.
- Karışık mod kategorileri dengeli dağıtıyor ve aynı kategoriyi arka arkaya mümkün olduğunca engelliyor.
- Oyuncunun son performansına göre zorluk artık gerçekten motor seçiminde kullanılıyor.
- Oyuncu zorlanıyorsa zorluk geri düşebiliyor; iyi performansta yükseliyor.
- Seçenekler oyun ekranında ayrıca karıştırıldığı için doğru cevap pozisyonu tahmin edilemiyor.
