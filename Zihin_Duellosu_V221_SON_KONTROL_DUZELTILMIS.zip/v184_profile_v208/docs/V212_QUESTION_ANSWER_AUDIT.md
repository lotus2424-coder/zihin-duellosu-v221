# Zihin Düellosu V212 — Soru/Cevap Denetim Raporu

## Kapsam ve dürüst durum
- İncelenen soru bankası: **1.600 soru**, 16 kategori.
- Her soruda dört seçenek ve doğru cevabın seçenekler içinde bulunması kontrol edildi.
- Eksik temel alan, yinelenen soru kimliği veya birebir aynı soru metni bulunmadı.
- Bu çalışma, **tam otomatik yapısal tarama + açıkça saptanabilen seçenek/kök kusurlarının düzeltilmesi** aşamasıdır. 1.600 sorunun her birinin olgusal doğruluğunun insan tarafından tek tek kaynakla doğrulandığı anlamına gelmez. Doğrulanmamış bilgi için böyle bir iddiada bulunulmuyor.

## Yapılan somut düzeltmeler

### V206Q00931
- Soru: Türkiye'nin en yüksek dağı hangisidir?
- İşlem: Coğrafi seçenekler aynı türde dağ adlarıyla tutarlı hale getirildi; doğru cevap korunup seçenek kalitesi artırıldı.
- Eski seçenekler: Asya ve Avrupa / Arktik Okyanusu / Pasifik Okyanusu / Ağrı Dağı
- Yeni seçenekler: Erciyes Dağı / Uludağ / Süphan Dağı / Ağrı Dağı

### V206Q00933
- Soru: Türkiye'nin yüzölçümü en büyük gölü hangisidir?
- İşlem: Göl sorusundaki dağ, şelale ve okyanus gibi kategori dışı çeldiriciler göl adlarıyla değiştirildi.
- Eski seçenekler: Ağrı Dağı / Van Gölü / Angel Şelalesi / Arktik Okyanusu
- Yeni seçenekler: Tuz Gölü / Beyşehir Gölü / Van Gölü / Eğirdir Gölü

### V206Q00934
- Soru: Türkiye'nin en büyük adası hangisidir?
- İşlem: Ada sorusundaki dağ, şelale, nehir gibi kategori dışı çeldiriciler ada adlarıyla değiştirildi.
- Eski seçenekler: Ağrı Dağı / Angel Şelalesi / Gökçeada / Kızılırmak
- Yeni seçenekler: Bozcaada / Marmara Adası / Gökçeada / Cunda (Alibey) Adası

### V206Q00937
- Soru: Türkiye'de Akdeniz ikliminin doğal bitki örtüsü nedir?
- İşlem: Bitki örtüsü sorusundaki yer/göl gibi kategori dışı seçenekler bitki örtüsü tipleriyle değiştirildi.
- Eski seçenekler: Çanakkale / Maki / Gökçeada / Van Gölü
- Yeni seçenekler: Bozkır / Maki / Tundra / Tayga

### V206Q00967
- Soru: Türkiye'de çay tarımı en çok hangi yörede yapılır?
- İşlem: Tarım yöresi sorusundaki bitki örtüsü ve şehir çeldiricileri bölge adlarıyla değiştirildi.
- Eski seçenekler: Iğdır / İstanbul / Maki / Doğu Karadeniz
- Yeni seçenekler: Doğu Karadeniz / İç Anadolu / Güneydoğu Anadolu / Trakya

### V206Q00968
- Soru: Türkiye'de zeytin tarımı hangi kıyı bölgelerinde yaygındır?
- İşlem: Zeytin tarımı sorusundaki bitki örtüsü/şehir seçeneği coğrafi bölge seçeneğiyle değiştirildi; doğru cevap korunup seçenekler tutarlılaştırıldı.
- Eski seçenekler: Ege ve Akdeniz kıyıları / Maki / İstanbul / Tuz Gölü çevresi
- Yeni seçenekler: Karadeniz ve Doğu Anadolu kıyıları / Ege ve Akdeniz kıyıları / Doğu Anadolu’nun yüksek kesimleri / Tuz Gölü çevresi

### V206Q00971
- Soru: Türkiye hangi iki kıtada yer alır?
- İşlem: Kıta sorusundaki dağ/göl/nehir çeldiricileri kıta çiftleriyle değiştirildi.
- Eski seçenekler: Ağrı Dağı / Van Gölü / Kızılırmak / Asya ve Avrupa
- Yeni seçenekler: Asya ve Afrika / Asya ve Avrupa / Avrupa ve Afrika / Kuzey Amerika ve Asya

### V206Q00766
- Soru: By the end of this month, she ___ at the company for five years?
- İşlem: Boşluk doldurma cümlesindeki soru işareti nokta ile düzeltildi; soru kökü daha doğal hale getirildi.

### V206Q00815
- Soru: The scientist, ___ research changed the field, received the award?
- İşlem: Boşluk doldurma cümlesindeki soru işareti nokta ile düzeltildi; soru kökü daha doğal hale getirildi.

## Kategori dağılımı
- ⚖️ Hukuk: 100
- ⚽ Spor: 100
- 🌍 Coğrafya: 100
- 🌍 Genel Kültür: 100
- 🎨 Sanat: 100
- 🎬 Sinema: 100
- 🎵 Müzik: 100
- 🏛️ Tarih: 100
- 💭 Felsefe: 100
- 💻 Teknoloji: 100
- 💼 Ekonomi: 100
- 📖 Edebiyat: 100
- 📘 İngilizce Gramer: 100
- 📚 Dil: 100
- 🔬 Bilim: 100
- 🩺 Tıp: 100

## Kullanılacak birincil kaynaklar
Kaynaklar kategori bazında referans noktalarıdır; her bir sorunun tek tek doğrulandığını tek başına kanıtlamazlar.
- Hukuk: Türkiye Mevzuat Bilgi Sistemi https://www.mevzuat.gov.tr/ ; Anayasa Mahkemesi https://www.anayasa.gov.tr/
- Tarih: Türk Tarih Kurumu https://www.ttk.gov.tr/ ; TBMM https://www.tbmm.gov.tr/ ; Atatürk Araştırma Merkezi https://atam.gov.tr/
- Coğrafya/istatistik: Meteoroloji Genel Müdürlüğü https://www.mgm.gov.tr/ ; MTA https://www.mta.gov.tr/ ; TÜİK https://data.tuik.gov.tr/
- Spor: IOC https://olympics.com/ ; FIFA https://www.fifa.com/ ; ITF https://www.itftennis.com/
- Bilim/uzay: NASA https://science.nasa.gov/solar-system/planets/ ; NIST https://www.nist.gov/
- Tıp: WHO https://www.who.int/ ; T.C. Sağlık Bakanlığı https://www.saglik.gov.tr/
- Felsefe: Stanford Encyclopedia of Philosophy https://plato.stanford.edu/ ; Internet Encyclopedia of Philosophy https://iep.utm.edu/
- Edebiyat/dil: TDK https://tdk.gov.tr/ ; British Council / Cambridge English kaynakları
- Sanat/sinema/müzik: The Met https://www.metmuseum.org/ ; Oscars https://www.oscars.org/ ; Britannica ve ilgili resmî kurum katalogları

## Sonraki zorunlu aşama
Özellikle değişken/güncel bilgi içeren sorular, tarih ve hukukta istisnalar, tıp soruları, “en büyük/en çok/ilk” gibi ölçütü belirsiz sorular ve birbirine çok benzeyen soru kümeleri tek tek kaynak kontrolünden geçirilmelidir. Bu ZIP, ilk tarama ve açık düzeltmeleri içerir; tüm cevapların kaynak düzeyinde kesin onaylandığı nihai sürüm olarak sunulmamalıdır.
