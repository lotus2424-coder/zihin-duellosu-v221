# Zihin Düellosu V187 — canlı mobil + Supabase OAuth

## Bu sürümde düzeltilenler
- itch.io iframe içinden doğrudan Google OAuth yönlendirmesi kaldırıldı.
- OAuth URL'si alınarak kullanıcı tıklamasıyla üst seviye tarayıcıya taşınıyor.
- Google ve Apple sağlayıcı fonksiyonları eklendi.
- Oyun başlangıcında üyelik seçimi: Google / Apple / Misafir.
- Misafir seçimi yerel oyuna devam eder; gerçek hesap seçilirse Supabase profili kullanılmaya devam eder.
- Portrait/mobile viewport CSS koruması eklendi.
- Manifest portrait olarak korunuyor.

## itch.io için zorunlu canlı ayarlar
1. HTML5 upload: ZIP browser'da oynatılacak.
2. Embed options: Click to launch in fullscreen tercih edilir.
3. Mobile friendly: ON.
4. Orientation: Portrait.
5. Eğer manuel viewport kullanılıyorsa 360 x 640 gibi portrait değerler kullanılmalı; mobilde itch.io zaten fullscreen başlatır.
6. Save sonrası yeni ZIP'in eski ZIP yerine browser'da oynatıldığını kontrol et.

## Google Cloud
Authorized JavaScript origins:
https://lotus2424-coder.itch.io

Authorized redirect URI:
https://mzzfuktigdsdrycmnwpz.supabase.co/auth/v1/callback

## Supabase
Site URL:
https://lotus2424-coder.itch.io/yeni

Redirect URL allowlist:
https://lotus2424-coder.itch.io/yeni

Google provider: enabled.
Apple provider: Supabase tarafında Apple Service ID / secret yapılandırması tamamlandıktan sonra çalışır.


## V188 OAuth callback düzeltmesi
- Google/Apple OAuth dönüşü itch.io proje sayfasına değil, OAuth'u başlatan gerçek oyun dokümanına yapılır.
- Bunun nedeni supabase-js PKCE akışının doğrulama bilgisini başlangıç origin'inde saklamasıdır.
- Supabase Authentication → URL Configuration → Redirect URLs bölümünde itch.io oyun hostunu kapsayan izinli bir pattern bulunmalıdır. Güvenlik için mümkünse gerçek oyun URL'sini kullanın; itch.io oyun URL'si sürüm/host nedeniyle değişiyorsa kontrollü bir wildcard gerekir.
