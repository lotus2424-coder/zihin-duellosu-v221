# Zihin Düellosu V214 — Benzersiz Soru Temizliği ve Doğrulama Durumu

## Yapılan işlemler
- Girdi: V213 soru bankası, 1600 soru kaydı.
- Aynı kategoride, aynı cevaplı ve çok yüksek benzerlikteki 23 tekrar/neredeyse tekrar kaydı kaldırıldı.
- Aynı kategori başına 100 soru korunacak şekilde 23 yeni, özgün soru eklendi.
- Son soru sayısı: 1600. Kategori başına 100 soru.
- Normalize edilmiş soru kökü kontrolünde aynı kategori içinde tam tekrar: 0.
- Dört seçenek ve doğru cevabın seçeneklerde tam bir kez bulunması yapısal kontrolünde sorun: 0.

## Önemli sınır
Bu sürüm, tekrar temizliği ve yeni eklenen soruların kaynak yönlendirmesi bakımından iyileştirilmiştir; ancak **mevcut 1.577 sorunun tüm cevapları henüz tek tek dış kaynaklarla doğrulanmış değildir**. Bu kayıtların her biri `V214_QUESTION_REGISTER.json` içinde `requires_individual_source_verification` olarak işaretlidir. Yeni eklenen 23 sorunun kaynakları `sourceGuide` alanında kayıtlıdır. Bu nedenle bu ZIP, tüm cevapları kesin doğrulanmış nihai sürüm olarak tanımlanmamaktadır.

## Kaynak yaklaşımı
Hukukta mevzuat.gov.tr; uzay biliminde NASA; sağlıkta WHO; teknoloji ve web standartlarında MDN/ICANN gibi resmî veya uzman kaynaklar tercih edilmelidir. Film, edebiyat, sanat ve tarih kayıtları ilgili kurum/müze/ansiklopedi referanslarıyla ayrıca doğrulanmalıdır.
