# Zihin Düellosu V199 — Banka-Bağımsız Soru Tekrarsızlık Motoru

- Motor `js/core/question-engine.js` içinde bağımsızdır. Skor, DNA, profil, localStorage ve sunucu verilerine bağlı değildir.
- Her oyun başlangıcında yalnızca soru bankasından bir havuz oluşturur.
- Soru metnini Unicode/boşluk/noktalama normalizasyonuyla imzalar; aynı soru farklı cevap sırasıyla gelse bile aynı soru kabul edilir.
- Aynı kimlik ve aynı normalize edilmiş soru ikinci kez seçilemez.
- Dört seçenek yapısı ve doğru cevabın seçeneklerde bulunması kontrol edilir.
- Karışık modda kategoriler kendi içindeki kullanım sayısına göre dengelenir ve aynı kategori mümkün olduğunca art arda seçilmez.
- Uygun benzersiz soru kalmadığında motor `null` döndürür; motor hiçbir koşulda eski soruyu yeniden açmaz.
- V199 bankası 439 benzersiz kullanılabilir soru içerir; 16 kategoriye dağıtılmıştır.

## Kaynak yaklaşımı

Açık kaynak soru veri tabanları incelendi. Open Trivia DB ve OpenTriviaQA gibi kaynaklar CC BY-SA 4.0 lisansındadır. CC BY-SA materyalinin uyarlanmış biçimde dağıtımında atıf ve ShareAlike koşulları bulunduğu için, lisans yükümlülüğü taşımayan üçüncü taraf sitelerden soru kopyalanmadı. V199 eklemeleri Zihin Düellosu için özgün olarak yazıldı ve bankaya `source: Original Zihin Düellosu Bankası` etiketiyle işlendi.
