# Soru Bankası Kaynak Notu — V199

Araştırılan açık kaynaklar:
- Open Trivia DB — CC BY-SA 4.0
- OpenTriviaQA — CC BY-SA 4.0
- Open Quiz Commons — CC BY-SA 4.0

Bu kaynakların içerikleri doğrudan V199 bankasına topluca kopyalanmadı. Amaç, kullanılabilecek lisanslı havuzların niteliğini ve atıf/ShareAlike yükümlülüklerini doğrulamaktı. V199 yeni soruları özgün hazırlanmıştır.
