# Zihin Düellosu V213 — Tüm Soru Bankası Denetim Raporu

- Kayıt sayısı: **1600**
- Kategori sayısı: **16**
- Yapısal sorun: **0**
- Aynı kategori içinde benzer soru çifti (karakter n-gram benzerliği ≥ 0,72): **92**
- Kaynakla doğrulanıp düzeltilen kayıt: **2**

## Kaynakla doğrulanarak düzeltilen hatalar

**V206Q00186 ve V206Q00991 — hak ehliyeti.** Önceki cevap “sağ ve tamamıyla doğmakla” şeklinde verilmişti. Bu ifade kişiliğin başlangıcını anlatır ancak hak ehliyetinin cenin bakımından koşullu olarak ana rahmine düşme anından başlamasını eksik bırakıyordu. Sorular ve açıklamalar 4721 sayılı Türk Medeni Kanunu madde 28 ile uyumlu olacak şekilde yeniden yazıldı. Kaynak: https://www.mevzuat.gov.tr/mevzuatmetin/1.5.4721.pdf

## Benzer soru çiftleri

Aşağıdaki liste otomatik benzerlik taramasıdır; her çift kesin tekrar anlamına gelmez. Konu kapsamı aynı olan ama farklı bilgiyi soran çiftler de bulunabilir.

- **0.975** — V206Q00890: I. Meşrutiyet hangi yılda ilan edilmiştir? → `1876`; V206Q00891: II. Meşrutiyet hangi yılda ilan edilmiştir? → `1908`
- **0.947** — V206Q00204: Yargıtay hangi yargı kolunun en yüksek mahkemesidir? → `Adli yargı`; V206Q00989: Yargıtay hangi yargı kolunun yüksek mahkemesidir? → `Adli yargı`
- **0.939** — V206Q00175: Haksız fiilin temel unsurlarından biri hangisidir? → `Hukuka aykırılık`; V206Q00996: Haksız fiilin temel unsurlarından biri nedir? → `Hukuka aykırı fiil`
- **0.925** — V206Q01350: SaaS neyin kısaltmasıdır? → `Software as a Service`; V206Q01351: IaaS neyin kısaltmasıdır? → `Infrastructure as a Service`
- **0.921** — V206Q01236: Böbreklerin temel işlevlerinden biri nedir? → `Kanı süzmek`; V208R1594: Böbreklerin temel işlevlerinden biri hangisidir? → `Kanın süzülmesine ve idrar oluşumuna katkı sağlamak`
- **0.916** — V206Q00895: Sakarya Meydan Muharebesi hangi yılda gerçekleşmiştir? → `1921`; V208R1563: Sakarya Meydan Muharebesi hangi yıl gerçekleşmiştir? → `1921`
- **0.909** — V206Q01290: Arz artarsa diğer şartlar sabitken fiyat üzerinde genel etki nedir? → `Aşağı yönlü baskı`; V206Q01291: Talep artarsa diğer şartlar sabitken fiyat üzerinde genel etki nedir? → `Yukarı yönlü baskı`
- **0.888** — V206Q00813: Boşluğa hangisi gelir? “The more you practice, ___ you become.” → `the better`; V206Q01599: Boşluğa hangisi gelir? “The more you practise, ___ you become.” → `the better`
- **0.885** — V206Q00056: Anadolu Selçuklu Devleti'nin başkenti hangisidir? → `Konya`; V206Q00907: Anadolu Selçuklu Devleti'nin başkenti hangi şehirdir? → `Konya`
- **0.881** — V206Q00545: HTTPS'nin HTTP'den farkı nedir? → `TLS ile şifreli iletişim sağlaması`; V206Q01337: HTTPS'nin HTTP'den temel farkı nedir? → `TLS ile şifreli iletişim sağlaması`
- **0.871** — V206Q01050: Eş anlamlı sözcüklere ne denir? → `Anlamdaş`; V206Q01051: Zıt anlamlı sözcüklere ne denir? → `Karşıt anlamlı`
- **0.870** — V206Q00896: Büyük Taarruz hangi yılda başlamıştır? → `1922`; V208R1564: Büyük Taarruz hangi yıl başlamıştır? → `1922`
- **0.869** — V206Q01230: Elektronun elektrik yükü nedir? → `Negatif`; V206Q01232: Nötronun elektrik yükü nedir? → `Yüksüz`
- **0.862** — V206Q00025: Birleşmiş Milletler'in merkezi hangisidir? → `New York`; V206Q00839: Birleşmiş Milletler'in merkezi hangi şehirdedir? → `New York`
- **0.861** — V206Q00027: Dünya'nın doğal uydusu nedir? → `Ay`; V206Q00033: Dünya'nın doğal uydusu hangisidir? → `Ay`
- **0.860** — V206Q00782: Boşluğa hangisi gelir? “This is the book ___ I told you about.” → `that`; V206Q00819: Boşluğa hangisi gelir? “This is the book ___ I told you about yesterday.” → `which`
- **0.856** — V206Q00172: Danıştay hangi yargı kolunun en yüksek mahkemesidir? → `İdari yargı`; V206Q00204: Yargıtay hangi yargı kolunun en yüksek mahkemesidir? → `Adli yargı`
- **0.855** — V206Q00709: Yüzüklerin Efendisi film üçlemesinin yönetmeni kimdir? → `Peter Jackson`; V206Q00710: Yüzüklerin Efendisi üçlemesinin yönetmeni kimdir? → `Peter Jackson`
- **0.855** — V206Q00771: Boşluğa hangisi gelir? “He said that he ___ tired.” → `was`; V206Q01577: Boşluğa hangisi gelir? “He said that he ___ very tired.” → `was`
- **0.847** — V206Q01529: Dekatlonda kaç farklı yarışma vardır? → `10`; V206Q01530: Heptatlonda kaç farklı yarışma vardır? → `7`
- **0.846** — V206Q00747: Maratonun resmî uzunluğu kaç kilometredir? → `42,195`; V206Q01527: Maratonun resmi uzunluğu kaç kilometredir? → `42,195`
- **0.844** — V206Q00720: Basketbolda serbest atış kaç sayı değerindedir? → `1`; V206Q00721: Basketbolda serbest atış kaç sayı? → `1`
- **0.844** — V206Q00856: Almanya'nın başkenti nedir? → `Berlin`; V206Q00874: Romanya'nın başkenti nedir? → `Bükreş`
- **0.835** — V206Q00189: Masumiyet karinesi nedir? → `Suçluluğu hükmen sabit oluncaya kadar kişinin masum sayılması`; V206Q00210: Masumiyet karinesi neyi ifade eder? → `Suçluluğu kesinleşene kadar kişinin masum kabul edilmesini`
- **0.835** — V206Q01361: BIOS kısaltmasının açılımı nedir? → `Basic Input/Output System`; V206Q01362: DNS kısaltmasının açılımı nedir? → `Domain Name System`
- **0.830** — V206Q00190: Masumiyet karinesi hangi ilkeyi ifade eder? → `Suçluluğu kesinleşene dek kişinin masum sayılmasını`; V206Q00210: Masumiyet karinesi neyi ifade eder? → `Suçluluğu kesinleşene kadar kişinin masum kabul edilmesini`
- **0.829** — V206Q01243: Alyuvarların temel görevi nedir? → `Gaz taşımak`; V206Q01244: Akyuvarların temel görevi nedir? → `Bağışıklık savunması`
- **0.828** — V206Q00481: Enflasyon neyi ifade eder? → `Genel fiyat düzeyinin sürekli artışını`; V206Q01279: Deflasyon neyi ifade eder? → `Genel fiyat düzeyinin sürekli düşmesi`
- **0.827** — V206Q00793: Boşluğa hangisi gelir? “I have lived here ___ 2020.” → `since`; V206Q00824: Boşluğa hangisi gelir? “I have lived here ___ 2019.” → `since`
- **0.825** — V206Q00509: İşsizlik oranı nedir? → `İşsizlerin işgücüne oranı`; V206Q01284: İşsizlik oranı neyi ifade eder? → `İşgücündeki işsizlerin oranını`
- **0.823** — V206Q00282: Kürk Mantolu Madonna romanının yazarı kimdir? → `Sabahattin Ali`; V206Q00283: Kürk Mantolu Madonna'nın yazarı kimdir? → `Sabahattin Ali`
- **0.821** — V206Q00713: Diegetik ses nedir? → `Hikâye dünyasındaki karakterlerin de duyabileceği ses`; V206Q01507: Non-diegetik ses nedir? → `Film dünyası dışından gelen, karakterlerin duymadığı ses`
- **0.820** — V206Q01217: Asitlerin pH değeri genellikle hangi aralıktadır? → `7'nin altında`; V206Q01218: Bazların pH değeri genellikle hangi aralıktadır? → `7'nin üstünde`
- **0.817** — V206Q00007: Bir insanın vücudundaki en büyük organ hangisidir? → `Deri`; V206Q00050: İnsan vücudundaki en büyük organ hangisidir? → `Deri`
- **0.817** — V206Q00898: Cumhuriyet hangi tarihte ilan edilmiştir? → `29 Ekim 1923`; V208R1566: Türkiye Cumhuriyeti hangi tarihte ilan edilmiştir? → `29 Ekim 1923`
- **0.815** — V206Q00567: Barok sanatın belirgin özelliklerinden biri hangisidir? → `Hareket, dramatik ışık ve güçlü duygusal etki`; V206Q00568: Barok sanatın özelliklerinden biri hangisidir? → `Dramatik ışık ve hareket`
- **0.813** — V206Q00484: Fırsat maliyeti nedir? → `Bir tercihin vazgeçilen en değerli alternatifinin maliyeti`; V206Q00485: Fırsat maliyeti neyi ifade eder? → `Bir seçimin vazgeçilen en değerli alternatifinin maliyetini`
- **0.810** — V206Q00541: HTTP durum kodu 404 genellikle neyi ifade eder? → `Kaynak bulunamadı`; V206Q00542: HTTP durum kodu 404 neyi ifade eder? → `Kaynak bulunamadı`
- **0.808** — V206Q00767: Boşluğa hangisi gelir? “By the time we arrived, the movie ___.” → `had started`; V206Q00768: Boşluğa hangisi gelir? “By the time we arrived, the train ___.” → `had left`
- **0.801** — V206Q00147: Türkiye'nin Asya kıtasındaki topraklarının adı hangisidir? → `Anadolu`; V206Q00148: Türkiye'nin Avrupa kıtasındaki topraklarının adı hangisidir? → `Trakya`
- **0.801** — V206Q00431: Hemoglobinin temel görevlerinden biri nedir? → `Oksijen taşımak`; V206Q01242: Hemoglobinin temel görevi nedir? → `Oksijen taşınmasına katkı sağlamak`
- **0.798** — V206Q00485: Fırsat maliyeti neyi ifade eder? → `Bir seçimin vazgeçilen en değerli alternatifinin maliyetini`; V208R1569: Ekonomide fırsat maliyeti neyi ifade eder? → `Bir seçimin vazgeçilen en değerli alternatifinin maliyetini`
- **0.796** — V206Q00172: Danıştay hangi yargı kolunun en yüksek mahkemesidir? → `İdari yargı`; V206Q00989: Yargıtay hangi yargı kolunun yüksek mahkemesidir? → `Adli yargı`
- **0.795** — V206Q00841: NATO'nun merkezi hangi şehirdedir? → `Brüksel`; V208R1535: UNESCO'nun merkezi hangi şehirdedir? → `Paris`
- **0.794** — V206Q00567: Barok sanatın belirgin özelliklerinden biri hangisidir? → `Hareket, dramatik ışık ve güçlü duygusal etki`; V206Q01380: Barok sanatın belirgin özelliği nedir? → `Dramatik hareket ve ışık`
- **0.792** — V206Q00589: Kaplumbağa Terbiyecisi tablosunun ressamı kimdir? → `Osman Hamdi Bey`; V206Q01374: Kaplumbağa Terbiyecisi'nin ressamı kimdir? → `Osman Hamdi Bey`
- **0.791** — V206Q00525: Bulut bilişim nedir? → `Uzak sunucularda bilgi işlem kaynaklarının kullanımı`; V206Q01349: Bulut bilişim neyi ifade eder? → `Bilişim kaynaklarının internet üzerinden hizmet olarak sunulması`
- **0.790** — V206Q01230: Elektronun elektrik yükü nedir? → `Negatif`; V206Q01231: Protonun elektrik yükü nedir? → `Pozitif`
- **0.787** — V206Q00888: Tanzimat Fermanı hangi yılda ilan edilmiştir? → `1839`; V206Q00889: Islahat Fermanı hangi yılda ilan edilmiştir? → `1856`
- **0.787** — V206Q00425: Böbreklerin temel görevlerinden biri hangisidir? → `Kandaki atıkları süzmek`; V208R1594: Böbreklerin temel işlevlerinden biri hangisidir? → `Kanın süzülmesine ve idrar oluşumuna katkı sağlamak`
- **0.786** — V206Q01496: The Seventh Seal'in yönetmeni kimdir? → `Ingmar Bergman`; V208R1547: The Seventh Seal filminin yönetmeni kimdir? → `Ingmar Bergman`
- **0.783** — V206Q00172: Danıştay hangi yargı kolunun en yüksek mahkemesidir? → `İdari yargı`; V206Q00988: Danıştay esas olarak hangi yargı kolunun yüksek mahkemesidir? → `İdari yargı`
- **0.783** — V206Q01123: Benim Adım Kırmızı'nın yazarı kimdir? → `Orhan Pamuk`; V208R1581: Benim Adım Kırmızı romanının yazarı kimdir? → `Orhan Pamuk`
- **0.782** — V206Q00806: Boşluğa hangisi gelir? “Not only ___ late, but he also forgot his keys.” → `was he`; V206Q01590: Boşluğa hangisi gelir? “Not only ___ late, but he also forgot the documents.” → `was he`
- **0.777** — V206Q01093: İkinci Yeni şairlerinden biri kimdir? → `Cemal Süreya`; V206Q01094: İkinci Yeni'nin önemli şairlerinden biri kimdir? → `Turgut Uyar`
- **0.776** — V206Q00426: Böbreğin temel işlevsel birimi hangisidir? → `Nefron`; V206Q01237: Böbreğin işlevsel birimi nedir? → `Nefron`
- **0.775** — V206Q00746: Maratonun resmi mesafesi yaklaşık kaç kilometredir? → `42,195`; V208R1526: Olimpik maratonun resmi mesafesi kaç kilometredir? → `42,195`
- **0.775** — V206Q00591: Kübizmle ilişkilendirilen sanatçı kimdir? → `Pablo Picasso`; V206Q01385: Sürrealizmle ilişkilendirilen sanatçı kimdir? → `Salvador Dalí`
- **0.772** — V206Q00072: Islahat Fermanı'nın ilan yılı hangisidir? → `1856`; V206Q00095: Tanzimat Fermanı'nın ilan yılı hangisidir? → `1839`
- **0.772** — V206Q01231: Protonun elektrik yükü nedir? → `Pozitif`; V206Q01232: Nötronun elektrik yükü nedir? → `Yüksüz`
- **0.769** — V206Q00532: DNS'nin görevi nedir? → `Alan adını IP adresiyle eşlemek`; V206Q00533: DNS'nin temel görevi nedir? → `Alan adlarını IP adreslerine çözümlemek`
- **0.764** — V206Q00065: Büyük Taarruz hangi tarihte başlamıştır? → `26 Ağustos 1922`; V208R1564: Büyük Taarruz hangi yıl başlamıştır? → `1922`
- **0.764** — V206Q01184: Demirin kimyasal sembolü nedir? → `Fe`; V206Q01185: Altının kimyasal sembolü nedir? → `Au`
- **0.762** — V206Q00344: Sokrates'in yöntemi nedir? → `Sorgulama ve diyalog`; V206Q01141: Sokrates'in yöntemlerinden biri nedir? → `Sokratik sorgulama`
- **0.761** — V206Q00065: Büyük Taarruz hangi tarihte başlamıştır? → `26 Ağustos 1922`; V206Q00896: Büyük Taarruz hangi yılda başlamıştır? → `1922`
- **0.761** — V206Q00387: Işığın boşluktaki yaklaşık hızı kaç km/s'dir? → `300.000`; V206Q00388: Işığın boşluktaki yaklaşık hızı nedir? → `300000 km/s`
- **0.760** — V206Q00722: Basketbolda serbest atış çizgisinden atılan isabetli şut kaç sayı değerindedir? → `1`; V206Q00724: Basketbolda üçlük çizgisinin gerisinden atılan isabetli şut kaç sayı değerindedir? → `3`
- **0.759** — V206Q00700: Pulp Fiction filminin yönetmeni kimdir? → `Quentin Tarantino`; V206Q01469: Pulp Fiction'ın yönetmeni kimdir? → `Quentin Tarantino`
- **0.758** — V206Q00751: Satrançta her oyuncunun başlangıçta kaç taşı vardır hangisidir? → `16`; V206Q01542: Satrançta her oyuncunun başlangıçta kaç piyonu vardır? → `8`
- **0.754** — V206Q00716: The Godfather filminin yönetmeni kimdir? → `Francis Ford Coppola`; V208R1545: The Godfather filmini kim yönetmiştir? → `Francis Ford Coppola`
- **0.753** — V206Q01441: Keman hangi çalgı ailesindedir? → `Yaylı`; V206Q01442: Flüt hangi çalgı ailesindedir? → `Nefesli`
- **0.748** — V206Q01441: Keman hangi çalgı ailesindedir? → `Yaylı`; V206Q01444: Obua hangi çalgı ailesindedir? → `Tahta nefesli`
- **0.746** — V206Q00972: Türkiye'nin kuzeyinde hangi deniz bulunur? → `Karadeniz`; V206Q00974: Türkiye'nin güneyinde hangi deniz bulunur? → `Akdeniz`
- **0.746** — V206Q00507: İhracat nedir? → `Mal ve hizmetlerin yurt dışına satılması`; V206Q01303: İhracat neyi ifade eder? → `Mal ve hizmetlerin yurt dışına satılması`
- **0.745** — V206Q00070: Halifelik hangi tarihte kaldırılmıştır? → `3 Mart 1924`; V206Q00899: Halifelik hangi yılda kaldırılmıştır? → `1924`
- **0.745** — V206Q00768: Boşluğa hangisi gelir? “By the time we arrived, the train ___.” → `had left`; V206Q01585: Boşluğa hangisi gelir? “When we arrived, the train ___.” → `had left`
- **0.743** — V206Q00872: Macaristan'ın başkenti nedir? → `Budapeşte`; V206Q00875: Bulgaristan'ın başkenti nedir? → `Sofya`
- **0.743** — V206Q00623: Bağlama hangi müzik geleneğinde önemli hangisidir? → `Türk halk müziği`; V206Q01448: Ney hangi müzik geleneğinde önemlidir? → `Türk tasavvuf müziği`
- **0.742** — V206Q01225: Mitozun temel sonucu nedir? → `Genetik olarak büyük ölçüde özdeş iki hücre`; V206Q01226: Mayozun temel sonucu nedir? → `Kromozom sayısının yarıya indirilmesi ve genetik çeşitlilik`
- **0.739** — V206Q01488: Roma filminin yönetmeni kimdir? → `Alfonso Cuarón`; V208R1546: 8½ filminin yönetmeni kimdir? → `Federico Fellini`
- **0.739** — V206Q01442: Flüt hangi çalgı ailesindedir? → `Nefesli`; V206Q01444: Obua hangi çalgı ailesindedir? → `Tahta nefesli`
- **0.739** — V206Q01339: HTML ne için kullanılır? → `Web sayfasının yapısını tanımlamak için`; V206Q01342: SQL ne için kullanılır? → `İlişkisel veritabanlarında sorgulama ve yönetim`
- **0.736** — V206Q01185: Altının kimyasal sembolü nedir? → `Au`; V206Q01186: Gümüşün kimyasal sembolü nedir? → `Ag`
- **0.736** — V206Q01197: Newton'un ikinci hareket yasası hangi ilişkiyi ifade eder? → `Kuvvet, kütle ve ivme ilişkisini`; V208R1591: Newton'un ikinci hareket yasası nasıl ifade edilir? → `Kuvvet = kütle × ivme`
- **0.732** — V206Q00508: İthalat nedir? → `Mal ve hizmetlerin yurt dışından alınması`; V206Q01304: İthalat neyi ifade eder? → `Mal ve hizmetlerin yurt dışından satın alınması`
- **0.732** — V206Q00824: Boşluğa hangisi gelir? “I have lived here ___ 2019.” → `since`; V206Q01573: Boşluğa hangisi gelir? “She has lived here ___ 2019.” → `since`
- **0.730** — V206Q00119: Dünyanın en büyük adası hangisidir? → `Grönland`; V206Q00934: Türkiye'nin en büyük adası hangisidir? → `Gökçeada`
- **0.730** — V206Q00088: Saltanat hangi tarihte kaldırılmıştır? → `1 Kasım 1922`; V206Q00906: Saltanat hangi yılda kaldırılmıştır? → `1922`
- **0.729** — V206Q00712: Citizen Kane filminin yönetmeni kimdir? → `Orson Welles`; V206Q01474: Citizen Kane'in yönetmeni kimdir? → `Orson Welles`
- **0.729** — V206Q00564: İki faktörlü kimlik doğrulama hangi amaçla kullanılır? → `Hesap güvenliğini ek bir doğrulama katmanıyla artırmak`; V206Q01359: İki faktörlü kimlik doğrulama ne sağlar? → `İkinci doğrulama adımıyla güvenliği artırır`
- **0.725** — V206Q00149: Türkiye'nin en büyük gölü hangisidir? → `Van Gölü`; V206Q00933: Türkiye'nin yüzölçümü en büyük gölü hangisidir? → `Van Gölü`
- **0.725** — V206Q00673: Baba (The Godfather) filminin yönetmeni kimdir? → `Francis Ford Coppola`; V206Q00716: The Godfather filminin yönetmeni kimdir? → `Francis Ford Coppola`

## Kaynak doğrulama durumu

Her kayıt envantere alındı. Yalnızca yukarıda belirtilen iki hukuki soru kaynakla karşılaştırılarak düzeltildi. Diğer kayıtlar tek tek birincil kaynakla doğrulanmadan “doğru” olarak işaretlenmedi; JSON envanterinde bu durum açıkça gösterilmiştir. Bu nedenle bu paket, tam kaynak doğrulaması bitmiş nihai sürüm değildir; dürüst ara denetim sürümüdür.
