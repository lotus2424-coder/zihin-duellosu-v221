# V211 Soru-Cevap Doğruluk İncelemesi

## Düzeltilen kesin hata

- **Soru kimliği:** V208R1521
- **Soru:** Anayasa değişikliklerinin kanunlaşabilmesi için TBMM Genel Kurulunda en az kaç milletvekilinin kabul oyu gerekir?
- **Eski cevap:** 200 (yanlış)
- **Yeni cevap:** 360 (doğru; TBMM'nin 600 üyelik tam sayısının beşte üçü)
- **Düzenleme:** Seçenekler 200, 300, 360, 400 olarak düzenlendi. Açıklama, Anayasa'nın 175. maddesindeki kabul eşiğini ve 200 sayısının teklif verme eşiğiyle karıştırılmaması gerektiğini belirtiyor.
- **Resmî kaynak:** https://www.anayasa.gov.tr/tr/mevzuat/anayasa/ (Madde 175)

## Kapsam ve sınırlama

Soru bankasındaki 1.600 kaydın yapısal doğrulaması yapıldı: her soruda dört seçenek bulunuyor ve `correct` alanı seçeneklerden biriyle eşleşiyor. Bu kontroller tek başına bütün bilgilerin olgusal olarak doğru olduğunu kanıtlamaz. Bu sürümde yukarıdaki yanlış bilgi kaynak metniyle karşılaştırılarak doğrulandı ve düzeltildi. Diğer tüm 1.600 sorunun tek tek dış kaynakla doğrulanmış olduğu iddia edilmemektedir; kalan sorular için konu konu kaynak denetimi sürdürülmelidir.
