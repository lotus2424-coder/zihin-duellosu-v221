# V197 — Google giriş / iPhone / itch.io düzeltmesi

## Kök neden
V196 Google akışı `about:blank` popup açıyor, Supabase OAuth URL'sini daha sonra bu popup'a yönlendiriyordu. iOS Safari/itch.io iframe ortamında bu yaklaşım ikinci sekme, kapanan oyun veya başarısız geri dönüş üretebiliyordu.

Ayrıca V196 istemcisi `exchangeCodeForSession()` kullanmasına rağmen Supabase istemcisinde PKCE akışı açıkça belirtilmemişti. Bu, OAuth callback kodunun güvenilir biçimde eşleşmemesine neden olabiliyordu.

## V197 çözümü
- `flowType: 'pkce'` etkinleştirildi.
- `detectSessionInUrl:false` korunarak OAuth kodu yalnızca `bootAuth()` içindeki `exchangeCodeForSession()` tarafından bir kez işleniyor.
- `about:blank`, popup ve `window.opener` bağımlılığı tamamen kaldırıldı.
- Google URL'si hazırlandıktan sonra oyun sekmesi/top-level itch.io sayfası doğrudan Google'a yönlendiriliyor.
- Google iframe içinde açılmaya çalışılmıyor.
- OAuth dönüşünde `code/error/state` URL parametreleri temizleniyor.
- `appReturnUrl()` OAuth'u başlatan gerçek oyun dokümanını kullanıyor.
