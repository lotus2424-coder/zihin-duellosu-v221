# V215 — Kategori Bazlı Soru Denetimi

## Kapsam ve dürüst durum bildirimi

- Soru kayıtları: 1600
- Kategori sayısı: 16
- Yapısal kontrol uyarısı olan kayıt: 3
- Tam normalize metin tekrarı grupları: 0
- Yüksek benzerlikli metin adayı çiftleri: 58

**Önemli:** Bu turda tüm kayıtlar envantere alındı ve soru/cevap/şık/açıklama/kaynak alanları yapısal olarak kontrol edildi. Bu, 1.600 sorunun tamamının içerik doğruluğunun resmi kaynaklardan tek tek doğrulandığı anlamına gelmez. Bu nedenle doğrulanmamış cevaplar değiştirilmedi ve tamamlandı diye işaretlenmedi. CSV kaydında her soru için bu durum açıkça yazılıdır.

## Önerilen birincil kaynak haritası

- ⚖️ Hukuk: Mevzuat Bilgi Sistemi https://www.mevzuat.gov.tr/ ; TBMM Kanun ve Karar Bilgi Sistemi https://www.tbmm.gov.tr/kanun-ve-karar-bilgi-sistemi ; Anayasa Mahkemesi https://www.anayasa.gov.tr/
- 🔬 Bilim: NASA Science https://science.nasa.gov/ ; NIST https://www.nist.gov/ ; ilgili bilimsel kurum/akademik birincil yayınlar
- 🩺 Tıp: WHO https://www.who.int/ ; NIH https://www.nih.gov/ ; konuya göre Sağlık Bakanlığı ve hakemli klinik rehberler
- 🌍 Coğrafya: MGM https://www.mgm.gov.tr/ ; MTA https://www.mta.gov.tr/ ; TÜİK https://www.tuik.gov.tr/ ; UN Data https://data.un.org/
- 🏛️ Tarih: Türk Tarih Kurumu https://www.ttk.gov.tr/ ; Atatürk Araştırma Merkezi https://atam.gov.tr/ ; arşiv ve müze kaynakları
- ⚽ Spor: IOC/Olympics https://olympics.com/ ; ilgili uluslararası federasyonların resmî kuralları
- 🎨 Sanat: The Metropolitan Museum of Art https://www.metmuseum.org/ ; Tate https://www.tate.org.uk/ ; koleksiyon/kurum katalogları
- 🎬 Sinema: BFI https://www.bfi.org.uk/ ; Academy of Motion Picture Arts and Sciences https://www.oscars.org/ ; film arşivleri
- 🎵 Müzik: Met Opera https://www.metopera.org/ ; Britannica konu başlıkları ve müzik kurumlarının katalogları
- 💭 Felsefe: Stanford Encyclopedia of Philosophy https://plato.stanford.edu/ ; Internet Encyclopedia of Philosophy https://iep.utm.edu/
- 💻 Teknoloji: NIST https://www.nist.gov/ ; RFC Editor https://www.rfc-editor.org/ ; üreticilerin resmi teknik belgeleri
- 💼 Ekonomi: TCMB https://www.tcmb.gov.tr/ ; TÜİK https://www.tuik.gov.tr/ ; World Bank https://www.worldbank.org/
- 📖 Edebiyat: TDK https://tdk.gov.tr/ ; Kültür ve Turizm Bakanlığı https://www.ktb.gov.tr/ ; eserler için yayınevi/edisyon ve akademik kaynaklar
- 📘 İngilizce Gramer: British Council https://learnenglish.britishcouncil.org/ ; Cambridge Dictionary Grammar https://dictionary.cambridge.org/grammar/
- 📚 Dil: TDK https://tdk.gov.tr/ ; Türkçe için TDK Güncel Türkçe Sözlük https://sozluk.gov.tr/
- 🌍 Genel Kültür: sorunun konusuna göre BM https://www.un.org/ ; AB https://european-union.europa.eu/ ; resmî ülke ve kurum kaynakları

## Yapısal uyarılar
- V206Q00551 (💻 Teknoloji): Bir JSON nesnesini gösteren sözdizimi nedir? — Seçenek tekrarı; Doğru cevap seçeneklerde tam bir kez eşleşmiyor
- V206Q00400 (🔬 Bilim): Dünya yüzeyine yakın bir yerde serbest düşen bir cismin yerçekimi ivmesi yaklaşık kaç m/s² kabul edilir? — Seçenek tekrarı; Doğru cevap seçeneklerde tam bir kez eşleşmiyor
- V208R1592 (🔬 Bilim): Ohm yasasına göre gerilim, akım ve direnç arasındaki ilişki hangisidir? — Seçenek tekrarı; Doğru cevap seçeneklerde tam bir kez eşleşmiyor

## Tam metin tekrar adayları

## Yüksek benzerlikli soru kökü adayları
- Benzerlik 0.93: V206Q00172 [⚖️ Hukuk] Danıştay hangi yargı kolunun en yüksek mahkemesidir? || V206Q00204 Yargıtay hangi yargı kolunun en yüksek mahkemesidir?
- Benzerlik 0.92: V206Q00175 [⚖️ Hukuk] Haksız fiilin temel unsurlarından biri hangisidir? || V206Q00996 Haksız fiilin temel unsurlarından biri nedir?
- Benzerlik 0.90: V206Q00190 [⚖️ Hukuk] Masumiyet karinesi hangi ilkeyi ifade eder? || V206Q00210 Masumiyet karinesi neyi ifade eder?
- Benzerlik 0.88: V206Q00723 [⚽ Spor] Basketbolda üç sayı çizgisinin gerisinden atılan başarılı şut kaç sayı değerindedir? || V206Q00724 Basketbolda üçlük çizgisinin gerisinden atılan isabetli şut kaç sayı değerindedir?
- Benzerlik 0.92: V206Q01529 [⚽ Spor] Dekatlonda kaç farklı yarışma vardır? || V206Q01530 Heptatlonda kaç farklı yarışma vardır?
- Benzerlik 0.94: V206Q00147 [🌍 Coğrafya] Türkiye'nin Asya kıtasındaki topraklarının adı hangisidir? || V206Q00148 Türkiye'nin Avrupa kıtasındaki topraklarının adı hangisidir?
- Benzerlik 0.92: V206Q00972 [🌍 Coğrafya] Türkiye'nin kuzeyinde hangi deniz bulunur? || V206Q00974 Türkiye'nin güneyinde hangi deniz bulunur?
- Benzerlik 0.90: V206Q00841 [🌍 Genel Kültür] NATO'nun merkezi hangi şehirdedir? || V208R1535 UNESCO'nun merkezi hangi şehirdedir?
- Benzerlik 0.93: V206Q00843 [🌍 Genel Kültür] Birleşmiş Milletler hangi yıl kurulmuştur? || V214N0001 Birleşmiş Milletler hangi yıl resmen kurulmuştur?
- Benzerlik 0.94: V206Q00851 [🌍 Genel Kültür] Avustralya'nın başkenti nedir? || V206Q00871 Avusturya'nın başkenti nedir?
- Benzerlik 0.89: V206Q00854 [🌍 Genel Kültür] İspanya'nın başkenti nedir? || V206Q00855 İtalya'nın başkenti nedir?
- Benzerlik 0.89: V206Q00855 [🌍 Genel Kültür] İtalya'nın başkenti nedir? || V206Q00856 Almanya'nın başkenti nedir?
- Benzerlik 0.91: V206Q00856 [🌍 Genel Kültür] Almanya'nın başkenti nedir? || V206Q00874 Romanya'nın başkenti nedir?
- Benzerlik 0.88: V206Q00857 [🌍 Genel Kültür] Fransa'nın başkenti nedir? || V206Q00860 Rusya'nın başkenti nedir?
- Benzerlik 0.89: V206Q00857 [🌍 Genel Kültür] Fransa'nın başkenti nedir? || V206Q00874 Romanya'nın başkenti nedir?
- Benzerlik 0.90: V206Q00860 [🌍 Genel Kültür] Rusya'nın başkenti nedir? || V206Q00876 İran'ın başkenti nedir?
- Benzerlik 0.92: V206Q00862 [🌍 Genel Kültür] Çin'in başkenti nedir? || V206Q00876 İran'ın başkenti nedir?
- Benzerlik 0.88: V206Q00872 [🌍 Genel Kültür] Macaristan'ın başkenti nedir? || V206Q00878 Kazakistan'ın başkenti nedir?
- Benzerlik 0.95: V206Q00876 [🌍 Genel Kültür] İran'ın başkenti nedir? || V206Q00877 Irak'ın başkenti nedir?
- Benzerlik 0.91: V206Q00567 [🎨 Sanat] Barok sanatın belirgin özelliklerinden biri hangisidir? || V206Q00568 Barok sanatın özelliklerinden biri hangisidir?
- Benzerlik 0.88: V206Q00576 [🎨 Sanat] Düşünen Adam heykelinin sanatçısı kimdir? || V206Q00577 Düşünen Adam heykeliyle tanınan sanatçı kimdir?
- Benzerlik 0.90: V206Q00591 [🎨 Sanat] Kübizmle ilişkilendirilen sanatçı kimdir? || V206Q01385 Sürrealizmle ilişkilendirilen sanatçı kimdir?
- Benzerlik 0.95: V206Q00673 [🎬 Sinema] Baba (The Godfather) filminin yönetmeni kimdir? || V206Q00716 The Godfather filminin yönetmeni kimdir?
- Benzerlik 0.90: V206Q00697 [🎬 Sinema] Parasite filminin yönetmeni kimdir? || V206Q00698 Parazit (Parasite) filminin yönetmeni kimdir?
- Benzerlik 0.90: V206Q00700 [🎬 Sinema] Pulp Fiction filminin yönetmeni kimdir? || V206Q01469 Pulp Fiction'ın yönetmeni kimdir?
- Benzerlik 0.90: V206Q00712 [🎬 Sinema] Citizen Kane filminin yönetmeni kimdir? || V206Q01474 Citizen Kane'in yönetmeni kimdir?
- Benzerlik 0.91: V206Q00713 [🎬 Sinema] Diegetik ses nedir? || V206Q01507 Non-diegetik ses nedir?
- Benzerlik 0.89: V206Q01471 [🎬 Sinema] Jaws filminin yönetmeni kimdir? || V206Q01488 Roma filminin yönetmeni kimdir?
- Benzerlik 0.97: V206Q00074 [🏛️ Tarih] Magna Carta hangi yılda kabul edilmiştir? || V214N0018 Magna Carta hangi yıl kabul edilmiştir?
- Benzerlik 0.88: V206Q00888 [🏛️ Tarih] Tanzimat Fermanı hangi yılda ilan edilmiştir? || V206Q00889 Islahat Fermanı hangi yılda ilan edilmiştir?
- Benzerlik 0.99: V206Q00890 [🏛️ Tarih] I. Meşrutiyet hangi yılda ilan edilmiştir? || V206Q00891 II. Meşrutiyet hangi yılda ilan edilmiştir?
- Benzerlik 0.88: V206Q01169 [💭 Felsefe] Kant'ta fenomen nedir? || V206Q01170 Kant'ta numen nedir?
- Benzerlik 0.89: V206Q01331 [💻 Teknoloji] USB ne için kullanılır? || V206Q01340 CSS ne için kullanılır?
- Benzerlik 0.89: V206Q01331 [💻 Teknoloji] USB ne için kullanılır? || V206Q01342 SQL ne için kullanılır?
- Benzerlik 0.89: V206Q01340 [💻 Teknoloji] CSS ne için kullanılır? || V206Q01342 SQL ne için kullanılır?
- Benzerlik 0.95: V206Q01350 [💻 Teknoloji] SaaS neyin kısaltmasıdır? || V206Q01351 IaaS neyin kısaltmasıdır?
- Benzerlik 0.91: V206Q01361 [💻 Teknoloji] BIOS kısaltmasının açılımı nedir? || V206Q01362 DNS kısaltmasının açılımı nedir?
- Benzerlik 0.95: V206Q00481 [💼 Ekonomi] Enflasyon neyi ifade eder? || V206Q01279 Deflasyon neyi ifade eder?
- Benzerlik 0.95: V206Q01290 [💼 Ekonomi] Arz artarsa diğer şartlar sabitken fiyat üzerinde genel etki nedir? || V206Q01291 Talep artarsa diğer şartlar sabitken fiyat üzerinde genel etki nedir?
- Benzerlik 0.90: V206Q01303 [💼 Ekonomi] İhracat neyi ifade eder? || V206Q01304 İthalat neyi ifade eder?
- Benzerlik 0.91: V206Q00767 [📘 İngilizce Gramer] Boşluğa hangisi gelir? “By the time we arrived, the movie ___.” || V206Q00768 Boşluğa hangisi gelir? “By the time we arrived, the train ___.”
- Benzerlik 0.89: V206Q00768 [📘 İngilizce Gramer] Boşluğa hangisi gelir? “By the time we arrived, the train ___.” || V206Q01585 Boşluğa hangisi gelir? “When we arrived, the train ___.”
- Benzerlik 0.89: V206Q00781 [📘 İngilizce Gramer] Boşluğa hangisi gelir? “They ___ the project yesterday.” || V206Q01576 Boşluğa hangisi gelir? “The report ___ yesterday.”
- Benzerlik 0.91: V206Q00782 [📘 İngilizce Gramer] Boşluğa hangisi gelir? “This is the book ___ I told you about.” || V206Q00819 Boşluğa hangisi gelir? “This is the book ___ I told you about yesterday.”
- Benzerlik 0.90: V206Q00791 [📘 İngilizce Gramer] Boşluğa hangisi gelir? “I ___ dinner when he called.” || V206Q01574 Boşluğa hangisi gelir? “They ___ dinner when I called.”
- Benzerlik 0.90: V206Q00247 [📚 Dil] 'Eyvah!' sözcüğü hangi türdendir? || V206Q00263 'Ve' sözcüğü hangi türdendir?
- Benzerlik 0.93: V206Q01038 [📚 Dil] Yüklemi isim olan cümleye ne denir? || V206Q01039 Yüklemi fiil olan cümleye ne denir?
- Benzerlik 0.91: V206Q01050 [📚 Dil] Eş anlamlı sözcüklere ne denir? || V206Q01051 Zıt anlamlı sözcüklere ne denir?
- Benzerlik 0.91: V206Q01063 [📚 Dil] İşaret zamirlerinden biri hangisidir? || V206Q01064 Kişi zamirlerinden biri hangisidir?
- Benzerlik 0.89: V206Q00387 [🔬 Bilim] Işığın boşluktaki yaklaşık hızı kaç km/s'dir? || V206Q00388 Işığın boşluktaki yaklaşık hızı nedir?
- Benzerlik 0.92: V206Q01217 [🔬 Bilim] Asitlerin pH değeri genellikle hangi aralıktadır? || V206Q01218 Bazların pH değeri genellikle hangi aralıktadır?
- Benzerlik 0.91: V206Q01225 [🔬 Bilim] Mitozun temel sonucu nedir? || V206Q01226 Mayozun temel sonucu nedir?
- Benzerlik 0.88: V206Q01230 [🔬 Bilim] Elektronun elektrik yükü nedir? || V206Q01232 Nötronun elektrik yükü nedir?
- Benzerlik 0.88: V206Q01231 [🔬 Bilim] Protonun elektrik yükü nedir? || V206Q01232 Nötronun elektrik yükü nedir?
- Benzerlik 0.93: V206Q00425 [🩺 Tıp] Böbreklerin temel görevlerinden biri hangisidir? || V208R1594 Böbreklerin temel işlevlerinden biri hangisidir?
- Benzerlik 0.91: V206Q00456 [🩺 Tıp] İnsülin hormonu hangi organda üretilir? || V206Q00458 İnsülin hormonunu hangi organ üretir?
- Benzerlik 0.91: V206Q01236 [🩺 Tıp] Böbreklerin temel işlevlerinden biri nedir? || V208R1594 Böbreklerin temel işlevlerinden biri hangisidir?
- Benzerlik 0.96: V206Q01243 [🩺 Tıp] Alyuvarların temel görevi nedir? || V206Q01244 Akyuvarların temel görevi nedir?