# V219 — Kategori ve Türkçe soru düzeltmesi

- Önceki sürüm: V218 denetim kanıtı ZIP
- Soru bankası: 1.600 kayıt; kategori sayıları değiştirilmedi.
- Düzeltilen kayıt: 15 adet İngilizce yazılmış Spor ve Sinema sorusu Türkçeye çevrildi.
- İngilizce Gramer kategorisindeki İngilizce örnek cümleler bilerek İngilizce bırakıldı; bu kategoride İngilizce soru metni doğru davranıştır.
- Kategori etiketleri arayüzde zaten Türkçe tanımlanmıştı (ör. ⚽ Spor, 🎬 Sinema). Sorun, bazı soru metinlerinin İngilizce kalmış olmasıydı.
- Yapısal doğrulama: tüm kayıtlar JSON olarak çözümlendi; her soruda 4 seçenek var ve doğru cevap seçeneklerden biri.
- Kapsam sınırı: Bu değişiklik dil ve kategori sunumu düzeltmesidir; 1.600 sorunun tamamının olgusal doğruluğunun tek tek doğrulandığı anlamına gelmez.

## Değiştirilen kayıtlar
- `V206Q01557`: In basketball, how many points is a free throw worth? → Basketbolda serbest atış kaç sayı kazandırır?
- `V206Q01558`: In football, how many minutes is regulation playing time? → Futbolda normal maç süresi kaç dakikadır?
- `V206Q01559`: In volleyball, how many hits may a team normally use before returning the ball? → Voleybolda bir takım topu karşı sahaya göndermeden önce normalde en fazla kaç kez dokunabilir?
- `V206Q01564`: In baseball, how many strikes normally make an out? → Beyzbolda bir vurucu kaç strike aldığında oyun dışı kalır?
- `V206Q01566`: In ice hockey, how many players from one team are normally on the ice including the goalkeeper? → Buz hokeyinde kaleci dâhil bir takımdan normalde kaç oyuncu buz üzerinde bulunur?
- `V206Q01567`: In handball, how many players from one team are on court? → Hentbolda bir takımdan kaleci dâhil sahada kaç oyuncu bulunur?
- `V206Q01568`: In water polo, how many players from one team are in the pool? → Su topunda bir takımdan kaleci dâhil havuzda kaç oyuncu bulunur?
- `V206Q01569`: In rugby union, how many players are on a team? → Rugby union türünde bir takım sahada kaç oyuncuyla oynar?
- `V206Q01570`: In cricket, how many players are on a team? → Krikette bir takım kaç oyuncudan oluşur?
- `V206Q01513`: What is a storyboard? → Storyboard (çekim taslağı) nedir?
- `V206Q01514`: What is cinematography? → Sinematografi nedir?
- `V206Q01515`: What is mise-en-scène? → Sinemada mise-en-scène (sahne düzenlemesi) neyi ifade eder?
- `V206Q01516`: What is a tracking shot? → Sinemada tracking shot (takip çekimi) nedir?
- `V206Q01517`: What is a jump cut? → Sinemada jump cut (atlamalı kesme) nedir?
- `V206Q01518`: What is a flashback? → Sinemada flashback (geriye dönüş) nedir?
