# Zihin Düellosu V200 — Kalıcı Tekrarsızlık Motoru + Genişletilmiş Banka

## Neden değişti?

V199 motoru her yeni oyunda (`start()` çağrıldığında) sıfırdan bir
`ZDQuestionEngine` örneği oluşturuyor ve havuzu baştan kuruyordu. Bu,
**tek bir oyun içinde** tekrarı önlese de, bir kategori sadece ~26-28
benzersiz soru içerdiğinden, arka arkaya birkaç tur oynayan bir
kullanıcı kısa süre sonra aynı soruları yeniden görüyordu. "Belli bir
sorudan sonra sorular tekrar ediyor" şikâyetinin kaynağı buydu.

## V200'de ne değişti?

1. **Kalıcı (oturumlar arası) hafıza.** Motor artık hangi sorunun
   gösterildiğini `localStorage` içinde saklıyor (`zd_engine_seen_v200`
   anahtarı, kategori bazlı listeler hâlinde). Uygulama kapatılıp
   açılsa, yeni bir oyun/tur başlasa bile bir kategori veya "Karışık"
   modu tamamen bitmeden hiçbir soru ikinci kez gösterilmiyor.
2. **Otomatik tur yenileme.** Bir kategorideki (veya Karışık moddaki)
   tüm benzersiz sorular gösterildiğinde motor yalnızca o kategori
   için geçmişi temizler ve yeni, yeniden karıştırılmış bir tur
   başlatır — oyun sonlanmaz, akış kesintisiz sürer.
3. **Oyun-içi anlık tekrar koruması aynen korunuyor.** Aynı round
   içinde bir soru veya aynı "bilgi ailesi" (topic/duplicateGroup)
   yine ikinci kez gösterilmez.
4. **API uyumluluğu.** `new ZDQuestionEngine(bank)` ve
   `engine.next(category)` çağrıları önceki sürümle birebir aynı
   şekilde çalışır; `app.js` içinde başka bir değişiklik gerekmedi.
   Ek olarak `engine.resetProgress(category?)` metoduyla kalıcı
   geçmiş elle de sıfırlanabilir (ör. ileride bir ayar ekranından).

## Soru bankası genişletmesi

V199'daki 439 benzersiz sorunun üzerine, her kategoriye özgü ve
**mantığa dayalı** (bilgiyi doğrudan ezber yerine "neden" sorusuyla
kavrayan), doğru cevabı bilen biri için hemen anlaşılır ama diğer
şıkları da inandırıcı/çelişkili kılan 192 yeni, özgün soru eklendi.
Toplam **631 benzersiz soru**, 16 kategoriye dağılmış durumda
(kategori başına ~37-40 soru; önceki ~26-28'e göre belirgin artış).

Yeni sorular tamamen özgün olarak yazıldı ve bankaya
`source: "Original Zihin Düellosu Bankası"` etiketiyle işlendi (bkz.
`QUESTION_BANK_SOURCES_V199.md`'deki telif yaklaşımı — üçüncü taraf
lisanslı içerik kopyalanmadı).

## Bilinen sınırlar

- `localStorage` kullanılamayan bir ortamda (ör. bazı gizli/incognito
  yapılandırmaları) motor sessizce sadece round-içi tekrarsızlığa geri
  düşer; hata fırlatmaz.
- Kalıcı geçmiş cihaz/tarayıcıya bağlıdır; farklı bir cihazda oynayan
  aynı kullanıcı için ayrı bir döngü işler (bu, hesap bazlı bir sunucu
  senkronizasyonu gerektirir ve bu sürümün kapsamı dışındadır).
