# V192 Knowledge Vault

- 16 categories × 320 cards = 5,120 question cards.
- Wording is generated in original Turkish phrasing from the curated V191 knowledge seeds; no TV-program question archive is copied.
- Each card carries a knowledge-family key so the engine can suppress the same knowledge family across a wider recent window.
- First two rounds are level 1; later rounds climb through levels 2–5.
- Same question ID cannot repeat in one game.
- Mixed mode balances categories and suppresses immediate category repetition.
