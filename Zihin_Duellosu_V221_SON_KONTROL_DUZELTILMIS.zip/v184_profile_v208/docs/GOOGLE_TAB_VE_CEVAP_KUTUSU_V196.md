# V196 — Google girişte kalıcı boş sekme ve cevap kutusunda taşan metin

## 1) "Google ile bağlan" → about:blank sekmesi açılıp öylece kalıyor — KOD HATASIYDI, DÜZELTİLDİ
`js/core/supabase-client.js` içinde giriş penceresi şöyle açılıyordu:
```js
window.open('about:blank','_blank','noopener,noreferrer')
```
`noopener` ve `noreferrer` seçeneklerinin ikisi de (ayrı ayrı bile) tarayıcıyı
`window.open()`'ın **null** döndürmesine zorlar — yani script'in az sonra o
sekmeyi Google'ın giriş adresine yönlendirmek için kullanacağı referans hiçbir
zaman var olmuyordu. Sekme gerçekten açılıyor ama script ona asla
"şimdi Google'a git" diyemiyor, bu yüzden sonsuza kadar `about:blank`'te kalıyordu.

**Düzeltme:** Pencere artık `noopener`/`noreferrer` olmadan açılıyor, böylece
referans korunuyor ve Google OAuth adresi hazır olur olmaz o sekme gerçekten
yönlendiriliyor. Ayrıca: giriş o sekmede tamamlandığında (Google → Supabase geri
dönüşü) artık kullanıcıya "giriş başarılı, bu sekmeyi kapatabilirsin" mesajı
gösterilip sekme birkaç saniye sonra otomatik kapanıyor; oturum aynı origin
içindeki orijinal oyun sekmenize otomatik yansır (Supabase istemcisi sekmeler
arası oturum senkronizasyonunu localStorage üzerinden zaten kendisi yapıyor).

## 2) Cevap seçeneklerinin metni kutucuğa sığmıyor, alttan kesiliyor — KOD HATASIYDI, DÜZELTİLDİ
Cevap kutuları (`.v141Answers .answer`) sabit/oranlı yükseklikte ve
`overflow:hidden`. CSS tarafında daha önce "V194 ANSWER FIT FIX" ile metnin alt
satıra kaymasına izin verilmişti, ama kutunun yüksekliği metne göre BÜYÜYEMEDİĞİ
için (4 seçenek her zaman eşit sabit yükseklik paylaşıyor), uzun bir seçenek
2-3 satıra düşünce son satır kutunun dışında/altında kalıp görünmez oluyordu.
Salt CSS ile (clamp/viewport genişliği) bu garanti edilemez, çünkü sorun ekran
genişliğinden değil, metnin KARAKTER UZUNLUĞUNDAN kaynaklanıyor.

**Düzeltme:** `js/core/app.js` içine her soru render edildikten hemen sonra
çalışan bir `fitAnswerButtons()` fonksiyonu eklendi. Bu fonksiyon her cevap
kutusunun gerçek içerik yüksekliğini (`scrollHeight`) görünür yüksekliğiyle
(`clientHeight`) karşılaştırır; taşma varsa o kutunun yazı boyutunu (CSS'teki
`!important` kuralını `setProperty(...,'important')` ile aşarak) küçük adımlarla
kutuya sığana kadar küçültür. Hem tek oyunculu hem düello ekranında, hem ekran
döndürüldüğünde/yeniden boyutlandığında çalışır. Sonuç: seçenek metni ne kadar
uzun olursa olsun kutunun dışına taşmaz veya kesilmez.
