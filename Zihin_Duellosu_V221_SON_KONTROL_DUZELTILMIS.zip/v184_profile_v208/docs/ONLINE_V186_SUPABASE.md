# Zihin Düellosu V186 — Supabase Online Hesap

## Bağlanan servisler
- Google OAuth → Supabase Auth
- profiles → gerçek kullanıcı profili
- game_scores → gerçek skor kayıtları
- profiles.season_points → liderlik sıralaması
- presence → 90 saniyelik heartbeat ile gerçek online oyuncu sayısı

## Uygulama anahtarı
Uygulama içinde yalnızca Supabase Publishable Key kullanılır. Secret API key ve Google Client Secret koda eklenmez.

## Google OAuth dönüş adresi
`js/core/supabase-client.js` mevcut sayfanın URL'sini `redirectTo` olarak kullanır. Yayına alınacak gerçek oyun adresi Supabase Dashboard → Authentication → URL Configuration → Redirect URLs listesine eklenmelidir.

## Supabase tabloları
Beklenen tablolar: `profiles`, `game_scores`, `presence`.
RLS politikaları kullanıcı bazlı insert/update ve authenticated select erişimini sağlar.

## Not
`server/` klasörü mevcut gerçek zamanlı düello WebSocket altyapısını korur. V186 online hesap/liderlik/presence akışı bu Node JSON backend'ini kullanmaz.
