# V191 Question Engine

## Soru mimarisi
- 16 kategori, toplam 160 özgün soru.
- Her kategoride 10 soru: seviye sırası `1, 1, 2, 2, 3, 3, 4, 4, 5, 5`.
- İlk iki soru her kategoride erişilebilir başlangıç sorusudur.
- Sonraki sorular kademeli olarak zorlaşır; oyuncu çok iyi performans gösterirse motor mevcut basamağın üzerine çıkabilir.
- Aynı soru aynı oyun içinde tekrar etmez.
- `topic` etiketleri ile aynı bilgi/konu ailesinin peş peşe gelmesi engellenir.
- Karışık modda kategori tekrarı cezalandırılır ve kategori dengesi korunur.
- Her soruda açıklama ve öğrenme notu bulunur; amaç sadece doğru cevabı buldurmak değil, yeni bilgi kazandırmaktır.
- Soruların metinleri oyun için özgün biçimde yazılmıştır; hazır soru kalıplarından oluşan eski 1018 soruluk havuz kaldırılmıştır.
