# V203 — Bilgi Odaklı Soru Standardı

- Mevcut V202 soru bankası korunarak kalite filtresinden geçirildi.
- Bilgi dışı/bariz çeldiriciler mümkün olduğunca aynı kategori içinden alan bilgisiyle değiştirildi.
- İngilizce Gramer seçenekleri gramer yapısını koruyacak şekilde bırakıldı.
- Her kayda questionType, answerStyle ve qualityVersion metadata alanları eklendi.
- Amaç: doğru cevabı yalnızca seçenek eleme yoluyla değil, konu bilgisiyle bulmayı gerektiren yapı.
