# V221 Son Kontrol Raporu

- Soru sayısı: 1600
- Kategori sayısı: 16
- Dil düzeltmesi yapılan metin: 122
- Yapısal kontrol hatası: 0

## Doğrulama kapsamı

Bu sürüm tespit edilen İngilizce soru/şık metinlerinde düzeltme ve yapısal son kontrol içerir. Bu rapor 1.600 sorunun tamamının olgusal doğruluğunun birincil kaynaklarla tek tek doğrulandığını iddia etmez. Her sorunun kaynakla tek tek doğrulanması ayrı bir editoryal aşamadır.
