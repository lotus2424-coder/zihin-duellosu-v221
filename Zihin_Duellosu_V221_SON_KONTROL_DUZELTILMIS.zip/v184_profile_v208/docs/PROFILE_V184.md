# Zihin Düellosu V184 — Profesyonel Oyuncu Profili

- Persistent player identity: display name, avatar, title, theme.
- XP progression: 1,000 XP per level with level progress tracking.
- Profile dashboard: games, correct answers, accuracy, streak, best score, duel wins.
- Achievement rewards: unlock conditions and claimable XP rewards.
- Collections remain connected to the profile identity.
- Storage uses the existing IndexedDB/localStorage resilient store.
- Existing Zihin DNA, adaptive question engine and joker systems remain unchanged. Audio playback has been removed in V210.
