# Zihin Düellosu V216 — devam eden soru bankası denetimi

Bu sürüm, önceki V215 proje dosyasının üzerine devam edilerek hazırlanmıştır; proje sıfırdan oluşturulmamıştır.

## Bu sürümde yapılan somut değişiklikler
- Aynı cevabı hedefleyen ve metin benzerliği yüksek bulunan 16 soru varyantı, aynı kategoride farklı bir öğrenme hedefi ölçen yeni sorularla değiştirildi.
- Yeni soruların dört seçeneği ve doğru cevap eşleşmesi kontrol edildi.
- Yeni/yeniden yazılmış sorular için kaynak URL'leri kayda geçirildi.
- 1.600 soru ve 16 kategori korunmuştur.
- Her soru için denetim listesi eklendi: `docs/V216_QUESTION_REGISTER.csv`.
- Değiştirilen kayıtlar: `docs/V216_DUPLICATE_REPLACEMENT_LOG.json`.

## Dürüst denetim durumu
Bu sürüm, tüm 1.600 sorunun kaynaklarla tek tek doğrulandığı anlamına gelmez. Kaynak bağlantısı eklenmesi, o kaynağın her ifadeyi doğruladığı anlamına da gelmez. Kayıt listesindeki `review_status` alanı, tek tek kaynak karşılaştırmasının tamamlanıp tamamlanmadığını açıkça gösterir. V216'da 16 tekrar-benzeri soru değiştirildi; kalan sorular için madde madde doğrulama işi devam etmektedir.

## Kaynak ilkesi
- Hukuk: güncel mevzuat metni ve Anayasa Mahkemesi/TBMM gibi birincil kurumlar.
- Bilim/coğrafya: NASA, NOAA, NIST ve konuya özel kamu bilim kurumları.
- Sağlık: WHO, NIH/NIDDK ve resmî sağlık otoriteleri.
- Dil/İngilizce: TDK, British Council ve Cambridge Dictionary.
- Sinema/sanat/müzik: Academy of Motion Picture Arts and Sciences, BFI, Met Museum ve konuya ait kurumsal arşivler.
- Spor: ilgili federasyonların güncel kuralları.

## Sonraki kontrol
Her sorunun soru kökü, dört seçeneği, doğru cevabı ve açıklaması kaynakta açıkça desteklenmelidir. Belirsiz veya tartışmalı sorular yeniden yazılmalı; güncel bilgi isteyen sorulara tarih/sürüm bilgisi eklenmeli. Anlamca aynı sorular, yalnızca kelime değişikliğiyle korunmamalıdır.
