# V195 — Google girişi ve canlı (Düello) bağlantısı: tespit edilen hatalar ve düzeltmeler

## 1) "Düello bağlantısı / Load failed" hatası — KOD HATASIYDI, DÜZELTİLDİ
Ön yüz (`js/core/duel-client.js`) gerçek zamanlı düello için bir **WebSocket**
sunucusu bekliyordu (hello / queue_join / question / answer / match_result gibi
mesajlarla). Ama `server/server.js` içinde WebSocket desteği **hiç yoktu** —
sadece düz HTTP REST uçları (guest/profile/score/leaderboard) vardı. Yani siz
`server/` klasörünü çalıştırsanız bile düello asla bağlanamazdı; sunucu WebSocket
bağlantı isteğini hiç anlamıyordu.

**Düzeltme:** `server/server.js` içine eksik olan WebSocket eşleştirme motorunu
(rakip bulma, soru gönderme, cevap toplama, puanlama, maç sonucu, bağlantı kopunca
20 sn içinde yeniden bağlanma) tamamen ekledim. `package.json`'a gerekli `ws`
paketi eklendi. Ayrıntı ve deploy adımları: `server/README.md`.

**Sizin yapmanız gereken:** `server/` klasörünü bir yere (Render/Railway/Fly.io)
deploy edip `index.html` içindeki `window.ZD_DUEL_URL` satırını gerçek adresle
değiştirmeniz gerekiyor — aksi halde düello, telefonda hâlâ `ws://localhost:8787`'ye
bağlanmaya çalışıp aynı hatayı verir (bu adres sadece kendi bilgisayarınızda
anlamlıdır, itch.io'daki bir telefon oradan sizin bilgisayarınıza asla ulaşamaz).

## 2) Google ile giriş — bu bir DEĞİL KOD, KONFİGÜRASYON meselesi
Google girişi tamamen Supabase üzerinden yürüyor (`js/core/supabase-client.js`).
Kod tarafında bariz bir hata görmedim; bu adımda genelde şu 3 noktadan biri
kırılır — sırayla kontrol edin:

**a) itch.io'nun gerçek oyun adresi Supabase'de izinli değil.**
itch.io, HTML5 oyunları kendi sayfanızda değil, `*.itch.zone` (veya
`*.hwcdn.net`) gibi değişken bir alt alan adından iframe içinde servis eder.
`appReturnUrl()` bu adresi doğru tespit edip Google dönüşünü oraya yönlendiriyor,
ama Supabase'in **Authentication → URL Configuration → Redirect URLs** listesinde
bu adres izinli değilse giriş "tamamlanamadı" hatasıyla düşer. Ekleyin:
```
https://lotus2424-coder.itch.io/yeni
https://*.itch.zone/**
```
(Supabase'de `*` tek segment, `**` her şeyle eşleşir — joker karakter destekleniyor.)

**b) Google Cloud Console taraflı yanlış origin/redirect.**
- Authorized JavaScript origins: `https://lotus2424-coder.itch.io`
- Authorized redirect URI: `https://mzzfuktigdsdrycmnwpz.supabase.co/auth/v1/callback`
Bu ikisi projenizdeki gerçek Supabase proje URL'siyle birebir aynı olmalı
(büyük/küçük harf, sondaki `/` dahil).

**c) itch.io iframe'inde üçüncü taraf çerez/localStorage engeli (özellikle Safari/iOS).**
Supabase oturumu tarayıcı depolamasına yazar; itch.io içindeki gömülü iframe bazı
tarayıcılarda (Safari/iOS, gizli sekme) üçüncü taraf depolamayı engelleyebilir.
Bunu ayırt etmek için: oyunu itch.io sayfası içinde DEĞİL, doğrudan
`https://lotus2424-coder.itch.io/yeni` linkini yeni sekmede açarak deneyin — eğer
orada çalışıp itch.io ana sayfasındaki gömülü oynatıcıda çalışmıyorsa, sorun (c)'dir
ve çözümü tarayıcı düzeyinde bir engel olduğundan proje kodundan düzeltilemez;
kullanıcıya "tam ekran aç / yeni sekmede aç" seçeneğini önermek gerekir.

Bu üç madde Supabase/Google Cloud panellerinde tuttuğunuz ayarlarla ilgili
olduğu için buradan doğrudan test edip düzeltemedim — panellerinize erişimim yok.
Yukarıdaki listeyi sırayla kontrol edip eşleştirirseniz giriş sorunu çözülür.
