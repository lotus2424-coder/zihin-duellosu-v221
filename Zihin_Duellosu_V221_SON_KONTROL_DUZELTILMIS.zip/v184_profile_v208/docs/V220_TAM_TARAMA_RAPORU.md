# V220 — Tüm soru bankası tarama raporu

## Kapsam
- İncelenen ZIP: `Zihin_Duellosu_V219_KATEGORI_VE_TURKCE_SORULAR_FIX.zip`
- Soru bankası: `v184_profile_v208/js/data/question-bank.js`
- Soru sayısı: 1600
- Kategori sayısı: 16
- Kategori dağılımı: her kategori için 100 soru = True

## Otomatik kontroller
- Zorunlu alanı eksik soru: 0
- Dört seçenek/benzersiz seçenek/doğru cevap seçeneklerde kontrolünde sorunlu soru: 0
- Birebir normalize soru metni tekrar grubu: 0
- Tekrarlanan ID grubu: 0
- Soru bazlı satır: 1600 (ayrıntı CSV dosyasında)

## Dil taraması (otomatik işaretleme)
İngilizce Gramer kategorisi hariç, İngilizce olabilecek kelimeleri içeren soru kökü sayıları: {"⚖️ Hukuk": 2, "⚽ Spor": 5, "🌍 Coğrafya": 1, "🌍 Genel Kültür": 16, "🎨 Sanat": 16, "🎬 Sinema": 22, "🎵 Müzik": 6, "🏛️ Tarih": 4, "💭 Felsefe": 24, "💻 Teknoloji": 5, "💼 Ekonomi": 1, "📖 Edebiyat": 7, "📘 İngilizce Gramer": 0, "📚 Dil": 0, "🔬 Bilim": 1, "🩺 Tıp": 0}. Bu tarama sadece adayları işaretler; özel isimler, alıntılar ve dilbilgisi örnekleri nedeniyle tek başına hata kararı değildir.

## Önemli doğruluk durumu
Bu rapor **tam olgusal doğrulama belgesi değildir**. Yapısal ve birebir tekrar taraması tüm 1600 soru üzerinde çalıştırılmıştır; ancak her sorunun doğru cevabı ve açıklaması ayrı ayrı birincil kaynakla karşılaştırılmadığı için her soru CSV'de `NOT_YET_INDIVIDUALLY_FACT_CHECKED` olarak işaretlenmiştir. Kaynak URL'sinin varlığı, o URL'nin ilgili iddiayı doğruladığını kanıtlamaz. Bu nedenle bu ZIP'e “tam doğrulandı” denmemelidir.

## Yayın kararı
Otomatik yapısal kontroller tek başına yayın için yeterli değildir. CSV'yi soru bazlı denetim kuyruğu olarak kullanın; her satırın kaynakla kontrolü tamamlanmadan bankanın bütünü doğrulanmış sayılmaz.
