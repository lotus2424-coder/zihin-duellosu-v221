# Zihin Düellosu V185 — Online Hesap + Gerçek Liderlik + Gerçek Online Oyuncu

V184 profil sistemi korunarak online katman eklendi.

## Eklenenler
- Sunucuda kalıcı oyuncu kimliği ve imzalı token.
- Profil XP/seviye/istatistik senkronizasyonu.
- Oyun skorlarının sunucuya kaydı.
- Gerçek liderlik tablosu.
- Son 90 saniyedeki heartbeat'lerden hesaplanan gerçek aktif oyuncu sayısı.
- Çevrimdışı durumda sahte oyuncu/sayı gösterilmez.
- Yeniden bağlantıda online kimlik yerel ayarlardan geri yüklenir.
- Leaderboard yenileme ve online oyuncu ekranı.

## Çalıştırma
`server/` klasöründe Node 18+ ile:
`ZD_SECRET="uzun-rastgele-secret" node server.js`

Sunucu aynı zamanda `v185_profile` klasörünü statik olarak servis eder. Böylece oyun ve API aynı origin üzerinde çalışabilir.

Alternatif olarak oyunu itch.io gibi statik bir hostta tutup URL'ye `?api=https://API-SUNUCU` eklenebilir.

## Güvenlik
Bu sürüm gerçek online skor/kimlik altyapısını sağlar ancak Google/Apple OAuth sağlayıcıları henüz bağlanmış değildir. OAuth bağlantısı için ilgili sağlayıcı kimlik bilgileri ve üretim alan adı gerekir. Bu nedenle mevcut kimlik mekanizması cihaz/oyuncu bazlı imzalı online kimliktir.
