# Zihin Düellosu V201 — Soru Bankası Genişletme

## Sonuç
- Önceki banka: 631 soru / 16 kategori
- V201 banka: 1428 benzersiz soru / 16 kategori
- Eklenen yeni kayıt: 797
- Kategori başına hedef: yaklaşık 90 soru
- Aynı soru metni normalize edilerek tekrarlar temizlendi.
- Seçenek sırası yeni sorularda bağımsız olarak karıştırıldı.
- Yeni soruların `id`, `fingerprint`, `duplicateGroup` alanları motorun V200 tekilleştirme mantığıyla uyumludur.

## İçerik yaklaşımı
ÖSYM'nin KPSS soru kitapçıkları ve konu yaklaşımı, özellikle Genel Kültür bölümünde tarih/coğrafya/vatandaşlık/genel bilgi eksenini belirlemek için referans alınmıştır. ÖSYM soruları telifli olduğu için birebir soru kopyalanmamış; aynı sınav becerilerini ölçen özgün sorular hazırlanmıştır.

İngilizce Gramer havuzunda tense, conditionals, passive, reported speech, modals, articles, prepositions, conjunctions ve relative clauses gibi başlıklar genişletildi. Cambridge English ve British Council'ın grammar konu başlıkları referans alınmıştır.

Genel bilgi tarafında UNESCO Dünya Mirası verileri, ATAM, TBMM ve TDK gibi kurumsal kaynaklar referans alınmıştır.

## Web kaynakları
- ÖSYM KPSS sınav grubu ve yayımlanan temel soru kitapçıkları
- UNESCO Türkiye / World Heritage List
- Atatürk Araştırma Merkezi
- TBMM kurumsal ve anayasal bilgiler
- TDK Yazım Kılavuzu ve Noktalama
- British Council LearnEnglish Grammar
- Cambridge English Grammar activities

## Telif notu
Bankaya internet sitelerinden soru metinleri topluca kopyalanmamıştır. Sorular özgün biçimde yazılmış, kaynaklar konu/doğrulama amacıyla kullanılmıştır.
