# Zihin Düellosu V217 — soru bankası düzeltme raporu

## Kapsam
- 1.600 soru kaydı korundu.
- 16 kategoride 100'er soru bulunmaktadır.
- Soru bankası dosyası: `js/data/question-bank.js`
- Bu sürüm V216 arşivi üzerinden devam eder; proje sıfırdan oluşturulmadı.

## Bu turda yapılanlar
- 14 soru kaydı (indeksler 17, 32, 52, 71, 693, 965, 863, 918, 1316? no, 1418, 1465, 1469, 1561, 1571, 1385 ve diğerleri; ayrıntı için JSON değişiklik günlüğü) benzer/tekrarlı bilgi hedefini azaltmak üzere yeniden yazıldı. Toplam değişiklik sayısı `V217_CHANGELOG.json` içinde sayısal olarak kayıtlıdır.
- Yeni/yenilenen sorulara kategoriye uygun kaynak bağlantıları eklendi.
- Her soru için 4 seçenek, doğru cevabın seçeneklerde tam bir kez bulunması ve seçeneklerin birbirinden farklı olması otomatik olarak kontrol edildi.
- Tam normalize soru metni tekrarları: 0.
- Benzerlik taramasında yüksek benzerlikli 8 çift kaldı. Bunların bir kısmı bilinçli karşılaştırma sorularıdır (ör. I./II. Meşrutiyet, SaaS/IaaS, arz/talep, elektron/nötron); bu yüzden otomatik olarak silinmedi. Ayrıntılar `V217_SIMILARITY_REVIEW.csv` içindedir.

## Kaynak standardı
Hukuk: Mevzuat Bilgi Sistemi ve Anayasa/ilgili resmî kurumlar.
Bilim: NASA ve ilgili bilimsel kurumlar.
Tıp: WHO, NIH/NIDDK gibi sağlık kurumları.
Ekonomi: St. Louis Fed eğitim kaynakları.
Teknoloji: RFC Editor ve Open Source Initiative.
Edebiyat: NobelPrize.org gibi ödül veren kurumların resmî kayıtları.
Tarih: TTK ve ilgili resmî tarih kurumları.

## Önemli sınırlama
Bu sürüm, soru bankasında yapılan somut düzeltmeleri ve otomatik tutarlılık denetimini içerir. **1.600 sorunun tamamı henüz ayrı ayrı birincil kaynak üzerinden insan tarafından doğrulanmış olarak işaretlenmemiştir.** Kaynak rehberi veya genel kategori bağlantısı bulunması, tek başına her olgusal iddianın doğrulandığı anlamına gelmez. Bu rapor, tam kaynak doğrulamasının yerine geçmez.
