# V209 — Soru Kökü Düzeltmesi

- 16 kategorideki 1600 sorunun kökü tarandı, 1085 kök düzeltildi.
- "X hangisidir aşağıdakilerden hangisidir?" çift soru kalıbı kaldırıldı.
- "… bilgisine göre", "Tarihsel/Bilimsel açıdan" ön ekleri kaldırıldı.
- "… hakkında aşağıdakilerden hangisi doğrudur?" ve Felsefe "kavramı aşağıdaki seçeneklerden hangisiyle doğru açıklanır?" şablonları doğal soru köküne çevrildi.
- İngilizce Gramer: "Boşluğa hangisi gelir? “cümle”" biçimine standartlaştırıldı.
- Yarım kalmış kökler ("Hukukta?", "Bir filmin aşağıdakilerden hangisidir?" vb.) açıklama/cevaba bakılarak yeniden yazıldı.
- Küçük harfli özel adlar düzeltildi (Avrupa Birliği, NATO, İstiklal Marşı…).
- Temizlik sonrası aynı köke düşen 37 kayıt ayrıştırıldı; motorun sessizce eleyeceği yinelenen soru kalmadı.
- Tüm değişiklikler: docs/QUESTION_STEM_FIX_V209_CHANGELOG.json

## Ses (iOS / Apple) düzeltmesi
- Ses öğeleri ilk dokunuşta sessizce çalınıp durdurularak iOS "kilit açma" kuralı karşılandı.
- Yüklenmemiş dosyada currentTime/pause yüzünden düşen play() çağrıları hazır olunca yeniden deneniyor.
- Uygulama arka plana gidince ses duruyor, dönünce soru sürüyorsa devam ediyor.


V210: Projedeki tüm müzik/ses dosyaları ve ses oynatma arayüzü kaldırıldı. Oyun sessiz çalışır.
