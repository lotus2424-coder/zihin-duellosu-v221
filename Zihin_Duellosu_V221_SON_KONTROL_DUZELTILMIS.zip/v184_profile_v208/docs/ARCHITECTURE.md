# Zihin Düellosu V182 — CORE

Structural refactor of V181 with no intended gameplay behavior changes.

- V181 remains the rollback/reference build.
- JavaScript execution order is preserved exactly.
- Question bank, adaptive logic, joker logic, UI and existing screens are preserved. Audio playback is removed in V210.
- Inline CSS is extracted to `css/app.css`.
- Inline JavaScript is extracted into ordered modules under `js/`.
- `index.html` is now the root composition document.

Next stage after iOS/Android verification: split `js/core/app.js` into stable services: QuestionEngine, GameSession, JokerEngine and ScoreEngine.
