# V205 Soru Bankası

{
  "version": "V205",
  "total": 1600,
  "categories": {
    "🌍 Genel Kültür": 100,
    "🏛️ Tarih": 100,
    "🌍 Coğrafya": 100,
    "⚖️ Hukuk": 100,
    "📚 Dil": 100,
    "📖 Edebiyat": 100,
    "💭 Felsefe": 100,
    "🔬 Bilim": 100,
    "🩺 Tıp": 100,
    "💼 Ekonomi": 100,
    "💻 Teknoloji": 100,
    "🎨 Sanat": 100,
    "🎵 Müzik": 100,
    "🎬 Sinema": 100,
    "⚽ Spor": 100,
    "📘 İngilizce Gramer": 100
  },
  "added": 764,
  "principles": [
    "100 soru/kategori",
    "özgün soru metinleri",
    "aynı bilgi alanından çeldiriciler",
    "doğru cevap ve 4 benzersiz seçenek doğrulaması",
    "fingerprint tekrar kontrolü",
    "ÖSYM soruları birebir kopyalanmadı"
  ]
}

Final QA: V205 sorularında 4 benzersiz seçenek ve doğru cevap kontrolleri tekrarlandı; V205 yeni sorularında çeldiriciler mümkün olduğunda aynı konu başlığından seçildi.