/* V181 script 8; execution order preserved. */

/* Zihin Düellosu V58 — resilient, authenticated, reconnectable duel client. */
(()=>{
'use strict';
class DuelClient{
 constructor(){this.ws=null;this.url=null;this.httpBase=null;this.token=null;this.playerId=null;this.connected=false;this.matchId=null;this.round=0;this.sentAnswer=false;this.handlers={};this.reconnectTimer=null;this.manualClose=false;this.retry=0;this.helloTimer=null;}
 endpoint(){const q=new URLSearchParams(location.search).get('duel');return q||window.ZD_DUEL_URL||'ws://localhost:8787';}
 httpEndpoint(){const u=this.endpoint();return u.replace(/^wss:/,'https:').replace(/^ws:/,'http:').replace(/\/$/,'');}
 async authenticate(){
  const settings=await ZDStore.get('settings')||{}; this.token=settings.duelToken||null;
  if(this.token){try{const payload=JSON.parse(atob(this.token.split('.')[1]));this.playerId=payload.sub; if(payload.exp>Date.now()/1000)return;}catch{}}
  const r=await fetch(this.httpEndpoint()+'/api/guest',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:(await ZDStore.get('profile')||{}).name||'Oyuncu'})});
  if(!r.ok)throw new Error('Düello hesabı oluşturulamadı'); const data=await r.json(); this.token=data.token;this.playerId=data.playerId;
  await ZDStore.set('settings',{...(settings||{}),duelToken:this.token});
 }
 async connect(){
  if(this.ws?.readyState===WebSocket.OPEN)return;
  await this.authenticate(); this.url=this.endpoint(); this.manualClose=false;
  return new Promise((resolve,reject)=>{
   const ws=new WebSocket(this.url); this.ws=ws; let opened=false;
   const timer=setTimeout(()=>{if(!opened){try{ws.close()}catch{};reject(new Error('Düello sunucusuna bağlanılamadı'))}},9000);
   ws.onopen=()=>{opened=true;clearTimeout(timer);this.connected=true;this.retry=0;this.send({type:'hello',token:this.token});clearTimeout(this.helloTimer);this.helloTimer=setTimeout(()=>{if(this.connected) this.send({type:'resume',matchId:this.matchId||null})},1500);resolve()};
   ws.onerror=()=>{if(!opened){clearTimeout(timer);reject(new Error('Düello bağlantısı başarısız'))} this.handlers.error?.('Düello bağlantısında sorun oluştu')};
   ws.onclose=()=>{clearTimeout(timer);clearTimeout(this.helloTimer);this.connected=false;this.handlers.close?.();if(!this.manualClose&&this.matchId)this.scheduleReconnect()};
   ws.onmessage=e=>{try{this.receive(JSON.parse(e.data))}catch{this.handlers.error?.('Sunucudan geçersiz veri alındı')}};
  })
 }
 scheduleReconnect(){if(this.reconnectTimer)return;const delay=Math.min(8000,1000*Math.pow(2,this.retry++));this.reconnectTimer=setTimeout(async()=>{this.reconnectTimer=null;try{await this.connect();this.send({type:'resume',matchId:this.matchId||null})}catch{this.scheduleReconnect()}},delay)}
 send(msg){if(this.ws?.readyState===WebSocket.OPEN)this.ws.send(JSON.stringify(msg))}
 async join(category){await this.connect();this.send({type:'queue_join',category:category||'Karışık'})}
 leave(){this.manualClose=true;clearTimeout(this.reconnectTimer);this.reconnectTimer=null;this.send({type:'queue_leave'});try{this.ws?.close()}catch{}this.ws=null;this.connected=false;this.matchId=null}
 answer(answer,timedOut=false){if(this.sentAnswer)return;this.sentAnswer=true;this.send({type:'answer',matchId:this.matchId,round:this.round,answer:timedOut?null:answer,timedOut:!!timedOut})}
 receive(m){switch(m.type){case'hello_ok':this.playerId=m.playerId;this.matchId=m.matchId||this.matchId;this.handlers.auth?.(m);break;case'queue_wait':this.handlers.wait?.(m);break;case'match_found':this.matchId=m.matchId;this.round=m.round||0;this.sentAnswer=false;this.handlers.match?.(m);break;case'resumed':this.matchId=m.matchId;this.round=m.round;this.sentAnswer=!!m.answered;this.handlers.resume?.(m);break;case'question':this.round=m.round;this.sentAnswer=false;this.handlers.question?.(m.question,m);break;case'round_result':this.sentAnswer=true;this.handlers.result?.(m);break;case'match_result':this.handlers.finish?.(m);this.matchId=null;break;case'error':this.handlers.error?.(m.message||'Düello hatası');break;}}
}
window.ZDuelClient=new DuelClient();
})();

