/* Zihin Düellosu V207 — content-quality + adaptive + family-aware engine */
(()=>{'use strict';
const STORAGE_KEY='zd_engine_seen_v207';
const clean=s=>String(s??'').normalize('NFKC').toLocaleLowerCase('tr-TR').replace(/[“”"'`´]/g,'').replace(/[.,!?;:()[\]{}<>/\\|+*=_%#@^~–—-]/g,' ').replace(/\s+/g,' ').trim();
const optionClean=s=>String(s??'').normalize('NFKC').toLocaleLowerCase('tr-TR').replace(/\s+/g,' ').trim();
const signature=q=>clean(q.question);
const optionSignature=q=>[...(q.options||[])].map(optionClean).sort().join('|');
const family=q=>clean(q.knowledgeKey||q.familyKey||q.duplicateGroup||`${q.category||''}|${q.topic||''}|${q.correct||''}`);
function shuffle(a){const x=a.slice();for(let i=x.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[x[i],x[j]]=[x[j],x[i]]}return x}
function loadSeen(){try{return JSON.parse(localStorage.getItem(STORAGE_KEY)||'{}')||{}}catch{return {}}}
function saveSeen(x){try{localStorage.setItem(STORAGE_KEY,JSON.stringify(x))}catch{}}
class ZDQuestionEngine{
 constructor(source){this.bank=Array.isArray(source)?source.slice():[];this.seen=loadSeen();this.reset()}
 reset(){this.roundIds=new Set();this.roundQuestions=new Set();this.roundFamilies=new Set();this.servedByCategory={};this.lastCategory='';this.lastTopic='';this.lastCorrectPos=-1;this.pool=this.#buildPool()}
 #buildPool(){const out=[],qs=new Set(),ops=new Set();for(const q of this.bank){if(!q?.id||!q.question||!Array.isArray(q.options)||q.options.length!==4)continue;if((q.qualityScore??0)<80)continue;const s=signature(q),o=s+'||'+optionSignature(q);const os=q.options.map(optionClean);if(qs.has(s)||ops.has(o)||new Set(os).size!==4||!os.includes(optionClean(q.correct)))continue;qs.add(s);ops.add(o);out.push(q)}return shuffle(out)}
 #key(c){return c&&c!=='Karışık'?'cat:'+c:'mixed'}
 #isSeen(q,c){const a=this.seen[this.#key(c)];return Array.isArray(a)&&a.includes(q.id)}
 #mark(q,c){const k=this.#key(c);if(!Array.isArray(this.seen[k]))this.seen[k]=[];if(!this.seen[k].includes(q.id))this.seen[k].push(q.id);saveSeen(this.seen)}
 #resetCycle(c){this.seen[this.#key(c)]=[];saveSeen(this.seen)}
 #available(c,unseen=true){return this.pool.filter(q=>{if(this.roundIds.has(q.id)||this.roundQuestions.has(signature(q)))return false;if(c&&c!=='Karışık'&&q.category!==c)return false;return !unseen||!this.#isSeen(q,c)})}
 #score(q,target,stats){const lvl=Number(q.cognitiveLevel||q.level||2);let s=100-Math.abs(lvl-target)*28;s+=(q.qualityScore||80)*0.22;if(q.questionType==='neden-sonuc')s+=7;if(q.questionType==='kronoloji')s+=7;if(q.questionType==='grammar-context')s+=6;if(this.roundFamilies.has(family(q)))s-=80;if(this.lastTopic&&clean(q.topic)===clean(this.lastTopic))s-=45;const st=stats?.[q.id];if(st?.attempts){const acc=(st.correct||0)/st.attempts;s+=(0.5-acc)*45;const avg=(st.totalMs||0)/st.attempts;s+=Math.max(-12,Math.min(12,(9000-avg)/500))}const pos=(q.options||[]).findIndex(x=>optionClean(x)===optionClean(q.correct));if(this.lastCorrectPos>=0&&pos===this.lastCorrectPos)s-=18;s+=Math.random()*5;return s}
 #pick(cands,target,stats){let fresh=cands.filter(q=>!this.roundFamilies.has(family(q)));if(fresh.length)cands=fresh;return cands.map(q=>[this.#score(q,target,stats),q]).sort((a,b)=>b[0]-a[0])[0]?.[1]||null}
 #mixed(cands,target,stats){const cats=[...new Set(cands.map(q=>q.category))];const counts=this.servedByCategory;let eligible=cats.filter(c=>c!==this.lastCategory);if(!eligible.length)eligible=cats;const min=Math.min(...eligible.map(c=>counts[c]||0));eligible=eligible.filter(c=>(counts[c]||0)===min);const c=eligible[Math.floor(Math.random()*eligible.length)];return this.#pick(cands.filter(q=>q.category===c),target,stats)}
 next(category='Karışık',targetLevel=3,stats={}){let c=this.#available(category,true),cycled=false;if(!c.length){this.#resetCycle(category);cycled=true;c=this.#available(category,false)}if(!c.length)return null;const target=Math.max(1,Math.min(5,Number(targetLevel)||3));const q=category==='Karışık'?this.#mixed(c,target,stats):this.#pick(c,target,stats);if(!q)return null;this.roundIds.add(q.id);this.roundQuestions.add(signature(q));this.roundFamilies.add(family(q));this.servedByCategory[q.category]=(this.servedByCategory[q.category]||0)+1;this.lastCategory=q.category;this.lastTopic=q.topic||q.fact||'';this.lastCorrectPos=(q.options||[]).findIndex(x=>optionClean(x)===optionClean(q.correct));this.#mark(q,category);q.__cycleReset=cycled;return q}
 remaining(c='Karışık'){return this.#available(c,false).length}
 remainingUnseen(c='Karışık'){return this.#available(c,true).length}
 totalUnique(){return this.pool.length}
 resetProgress(c){if(c)this.#resetCycle(c);else{this.seen={};saveSeen(this.seen)}}
 stats(){const cats=[...new Set(this.pool.map(q=>q.category))];return{totalUnique:this.pool.length,usedThisRound:this.roundQuestions.size,remainingUnseen:this.remainingUnseen(),remainingUnseenByCategory:Object.fromEntries(cats.map(c=>[c,this.remainingUnseen(c)]))}}
}
window.ZDQuestionEngine=ZDQuestionEngine;window.ZDQuestionEngineUtils={normalize:clean,optionNormalize:optionClean,signature,optionSignature};})();
