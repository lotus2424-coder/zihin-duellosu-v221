/* Zihin Düellosu V189 — real Supabase online account, scores, leaderboard and presence. */
(()=>{
'use strict';
const CONFIG={heartbeatMs:30000,onlineTtlSec:90};
let user=null,session=null,heartbeatTimer=null,ready=false,authListener=null;
const client=()=>ZDSupabase.getClient();
const now=()=>new Date().toISOString();
async function loadLocalProfile(){return await ZDStore.get('profile')||{}}
function cleanName(v){return String(v||'Zihin Oyuncusu').replace(/[<>]/g,'').trim().slice(0,32)||'Zihin Oyuncusu'}
async function ensureProfile(u){
 if(!u)return null;
 const p=await loadLocalProfile();
 const meta=u.user_metadata||{};
 const providerName=cleanName(meta.full_name||meta.name||u.email?.split('@')[0]||'Zihin Oyuncusu');
 const currentName=cleanName(p.displayName);
 const displayName=(currentName==='Zihin Oyuncusu'||!currentName)?providerName:currentName;
 const nextProfile={...p,displayName,lastActiveAt:now()};
 try{await ZDStore.set('profile',nextProfile)}catch(_){}
 const row={user_id:u.id,username:displayName,avatar:p.avatar||'brain',xp:Number(p.xp||0),level:ZDModel?.xpLevel?ZDModel.xpLevel(Number(p.xp||0)):Math.floor(Number(p.xp||0)/1000)+1,league:'Bronz',updated_at:now()};
 const {data,error}=await client().from('profiles').upsert(row,{onConflict:'user_id'}).select().single();
 if(error)throw error;
 try{window.dispatchEvent(new CustomEvent('zd-auth-profile',{detail:{user:u,profile:nextProfile}}))}catch(_){}
 return data;
}
async function ensurePresence(){
 if(!user)return false;
 const {error}=await client().from('presence').upsert({user_id:user.id,last_seen:now(),status:'online'},{onConflict:'user_id'});
 if(error)throw error; return true;
}
async function init(){
 try{
  session=await ZDSupabase.getSession(); user=session?.user||null;
  if(authListener)authListener.unsubscribe();
  authListener=ZDSupabase.onAuthStateChange(async(_event,s)=>{session=s;user=s?.user||null;if(user){try{await ensureProfile(user);await ensurePresence();ready=true;startHeartbeat()}catch(e){console.warn('Supabase profile sync failed',e)}}else{ready=false;stopHeartbeat();try{window.dispatchEvent(new CustomEvent('zd-auth-profile',{detail:{user:null,profile:null}}))}catch(_){} }});
  if(user){await ensureProfile(user);await ensurePresence();ready=true;startHeartbeat()}else ready=false;
  return !!user;
 }catch(e){console.warn('Supabase init failed',e);ready=false;return false}
}
async function signInGoogle(){return ZDSupabase.signInGoogle()}
async function signOut(){stopHeartbeat();await ZDSupabase.signOut();user=null;session=null;ready=false}
async function syncProfile(){
 if(!user)return false;
 const p=await loadLocalProfile();
 const row={user_id:user.id,username:cleanName(p.displayName),avatar:p.avatar||'brain',xp:Number(p.xp||0),level:ZDModel?.xpLevel?ZDModel.xpLevel(Number(p.xp||0)):Math.floor(Number(p.xp||0)/1000)+1,updated_at:now()};
 const {error}=await client().from('profiles').upsert(row,{onConflict:'user_id'});if(error)throw error;await ensurePresence();return true;
}
async function submitGame(evt){
 if(!user)return false;
 const score=Number(evt.score||0), correct=Number(evt.correct||0), wrong=Number(evt.wrong||0), xp=Number(evt.xp||0);
 const {error}=await client().from('game_scores').insert({user_id:user.id,score,correct,wrong,xp_earned:xp,mode:String(evt.mode||'single'),category:String(evt.category||'Karışık'),won:!!evt.won});
 if(error)throw error;
 const {data:p,error:pe}=await client().from('profiles').select('xp,season_points').eq('user_id',user.id).single();if(pe)throw pe;
 const lp=await loadLocalProfile();
 const {error:ue}=await client().from('profiles').update({username:cleanName(lp.displayName),avatar:lp.avatar||'brain',xp:Number(lp.xp||p.xp||0),level:ZDModel?.xpLevel?ZDModel.xpLevel(Number(lp.xp||p.xp||0)):Math.floor(Number(lp.xp||p.xp||0)/1000)+1,season_points:Number(p.season_points||0)+score,updated_at:now()}).eq('user_id',user.id);
 if(ue)throw ue;await ensurePresence();return true;
}
async function leaderboard(limit=20){
 if(!user)return {configured:true,authenticated:false,players:[],onlineCount:null};
 const {data,error}=await client().from('profiles').select('user_id,username,avatar,xp,level,league,season_points,updated_at').order('season_points',{ascending:false}).limit(Math.min(50,Math.max(1,limit)));
 if(error)throw error;
 const cutoff=new Date(Date.now()-CONFIG.onlineTtlSec*1000).toISOString();
 const {count}=await client().from('presence').select('user_id',{count:'exact',head:true}).gte('last_seen',cutoff);
 return {configured:true,authenticated:true,players:(data||[]).map((p,i)=>({rank:i+1,id:p.user_id,name:p.username||'Zihin Oyuncusu',avatar:p.avatar||'brain',xp:Number(p.xp||0),level:Number(p.level||1),league:p.league||'Bronz',score:Number(p.season_points||0)})),onlineCount:count||0};
}
async function onlineCount(){
 if(!user)return {configured:true,authenticated:false,count:null};
 const cutoff=new Date(Date.now()-CONFIG.onlineTtlSec*1000).toISOString();
 const {count,error}=await client().from('presence').select('user_id',{count:'exact',head:true}).gte('last_seen',cutoff);
 if(error)throw error;return {configured:true,authenticated:true,count:count||0};
}
function startHeartbeat(){stopHeartbeat();const beat=async()=>{if(!user)return;try{await ensurePresence()}catch(e){}};beat();heartbeatTimer=setInterval(beat,CONFIG.heartbeatMs)}
function stopHeartbeat(){clearInterval(heartbeatTimer);heartbeatTimer=null}
function stop(){stopHeartbeat();ready=false}
window.ZDOnline={CONFIG,configured:()=>true,init,ensureIdentity:init,signInGoogle,signOut,syncProfile,submitGame,leaderboard,onlineCount,stop,get user(){return user},get session(){return session},get ready(){return ready}};
})();
