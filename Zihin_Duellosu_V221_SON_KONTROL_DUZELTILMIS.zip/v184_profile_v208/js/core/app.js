/* V181 script 9; execution order preserved. */

(async()=>{
'use strict';
try{await Promise.race([ZDStore.init(),new Promise(r=>setTimeout(r,750))])}catch(e){}
const APP_VERSION='210';
const QUESTION_TIME_MS=20000;
const NEXT_QUESTION_DELAY_MS=1500;
const MAX_WRONG=4;
const XP_PER_LEVEL=1000;
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const screens=['home','category','mode','game','result','dna','achievements','daily','leaderboard'];
const state={previousScreen:'home',level:1,mode:'single',duel:null,score:0,combo:0,maxComboRound:0,hearts:MAX_WRONG,index:0,deadline:0,timer:null,answered:false,current:null,used:new Set(),usedQuestions:new Set(),usedFacts:new Set(),recent:[],lastCategory:'',adaptiveHistory:[],adaptiveLevel:1,selectedCategory:'Karışık',questionStart:0,roundStart:0,xpBefore:0,roundCorrect:0,roundWrong:0,categorySeen:Object.create(null),difficultyStats:Object.create(null),jokers:{fifty:2,freeze:2,skip:2},questionEngine:null};
const bank=Array.isArray(window.ZD_QUESTION_BANK)?window.ZD_QUESTION_BANK:[];
const questionKey=q=>String(q.question||'').toLocaleLowerCase('tr-TR').replace(/\s+/g,' ').trim();
const factKey=q=>String(q.category||'')+'|'+String(q.fact||questionKey(q));

let profile={...ZDModel.profileDefaults};
let difficultyStats={};
let dna={version:1,questions:{},categories:{},levels:{},history:[]};
try{profile=(await ZDModel.load()).profile||profile}catch(e){}
try{difficultyStats=await ZDStore.get('difficulty')||{}}catch(e){difficultyStats={}};
try{dna=await ZDStore.get('dna')||dna}catch(e){};
dna.questions=dna.questions||{};dna.categories=dna.categories||{};dna.levels=dna.levels||{};dna.history=Array.isArray(dna.history)?dna.history:[];
/* V196: uzun cevap seçenekleri sabit yükseklikli kutulara CSS ile her zaman
   sığmıyordu (metin taşıp altta kesiliyordu). Her soru render edildikten sonra
   gerçek yerleşimi ölçüp, taşan seçeneklerin yazı boyutunu kutuya sığana kadar
   kademeli küçültüyoruz — metin uzunluğundan bağımsız garanti bir çözüm. */
function fitAnswerButtons(container){
 if(!container)return;
 requestAnimationFrame(()=>{
  container.querySelectorAll('.answer').forEach(btn=>{
   const label=btn.querySelector('b'); if(!label)return;
   label.style.removeProperty('font-size');
   const base=parseFloat(getComputedStyle(label).fontSize)||16;
   const minSize=Math.max(10,base*0.6);
   let size=base, guard=0;
   // CSS sets font-size with !important, so a plain inline style is ignored —
   // setProperty(...,'important') is required to actually shrink it.
   while(btn.scrollHeight>btn.clientHeight+1 && size>minSize && guard<24){
    size-=0.5; label.style.setProperty('font-size',size+'px','important'); guard++;
   }
  });
 });
}

async function initOnline(){try{return await ZDOnline.init()}catch(e){return false}}
async function bootAuth(){
 try{
  const signedIn=await ZDSupabase.completeOAuthCallback();
  // V197: OAuth now returns to this same game document. There is no popup
  // or duplicate tab to close; the session is restored below by initOnline().
 }catch(e){console.warn('OAuth callback failed',e);try{modal('Google giriş',`<p>Üyelik tamamlanamadı.</p><p class=\"muted\">${escapeHtml(e?.message||'Google oturumu doğrulanamadı.')}</p>`)}catch(_){}}
 return initOnline()
}
function accountGate(){const g=$('#accountGate');if(!g)return; if(ZDOnline?.user){g.classList.remove('show');return} let guest=false;try{guest=localStorage.getItem('zd_guest_mode')==='1'}catch{} if(!guest)g.classList.add('show')}
function closeAccountGate(){const g=$('#accountGate');if(g)g.classList.remove('show')}
async function continueGuest(){try{localStorage.setItem('zd_guest_mode','1')}catch{} closeAccountGate(); status('Misafir olarak devam ediliyor')}
async function accountGoogle(){try{await ZDOnline.signInGoogle()}catch(e){console.warn('Google OAuth failed',e);modal('Google giriş',`<p>Google giriş başlatılamadı.</p><p class="muted">${escapeHtml(e?.message||'OAuth bağlantısı kurulamadı.')}</p>`)} }
async function accountApple(){try{await ZDOnline.signInApple()}catch(e){console.warn('Apple OAuth failed',e);modal('Apple giriş',`<p>Apple ile giriş şu anda sağlayıcı yapılandırması gerektiriyor.</p><p class="muted">${escapeHtml(e?.message||'Apple OAuth başlatılamadı.')}</p>`)} }
async function renderOnlineLeaderboard(){
 const statusEl=$('#leaderboardStatus'), list=$('#onlineLeaderboardList');
 if(!statusEl||!list)return;
 statusEl.textContent='Çevrimiçi liderlik tablosu yükleniyor…';
 list.innerHTML='<div class="onlineEmpty">Sunucudan veriler alınıyor…</div>';
 const data=await ZDOnline.leaderboard(20);
 if(!data.configured){
   statusEl.textContent='Online sistem yapılandırılmadı';
   list.innerHTML='<div class="onlineEmpty"><div class="onlineEmptyIcon">☁️</div><b>Çevrimiçi sistem hazır değil</b><span>Supabase bağlantısı yapılandırılmalı.</span></div>'; return;
 }
 if(!data.authenticated){
   statusEl.innerHTML='<span class="onlineCountDot offline"></span> Hesap bağlantısı gerekli';
   list.innerHTML='<div class="onlineEmpty"><div class="onlineEmptyIcon">🔐</div><b>Gerçek liderlik için giriş yap</b><span>Google veya Apple hesabını bağladığında gerçek skorun ve online durumun burada görünür.</span><button class="modalAction" data-action="accountGoogle">🔵 Google ile giriş</button></div>'; return;
 }
 if(data.offline){
   statusEl.textContent='Sunucuya ulaşılamıyor';
   list.innerHTML='<div class="onlineEmpty"><div class="onlineEmptyIcon">⚠️</div><b>Bağlantı kurulamadı</b><span>Gerçek oyuncu verisi gelmeden sayı veya sıralama gösterilmiyor.</span><button class="modalAction" data-action="leaderboardRefresh">↻ Tekrar dene</button></div>'; return;
 }
 const count=data.onlineCount==null?'':`<span class="onlineCountDot"></span>${data.onlineCount} aktif oyuncu`;
 statusEl.innerHTML=`${count||'Online bağlantı aktif'} • Son güncelleme şimdi`;
 const rows=Array.isArray(data.players)?data.players:[];
 list.innerHTML=rows.length?rows.map((p,i)=>`<div class="onlineRow"><div class="onlineRank">#${i+1}</div><div><div class="onlineName">${escapeHtml(p.name||'Zihin Oyuncusu')}</div><div class="onlineMeta">Seviye ${Number(p.level||1)} • ${escapeHtml(p.league||'Bronz')}</div></div><div class="onlineScore">${Number(p.score||0).toLocaleString('tr-TR')}</div></div>`).join(''):'<div class="onlineEmpty">Henüz çevrimiçi skor bulunmuyor.</div>';
}
async function showOnlineCount(){
 const data=await ZDOnline.onlineCount();
 if(!data.configured){modal('Çevrimiçi Oyuncular','<p>Online sunucu henüz yapılandırılmadı.</p>');return}
 if(data.count==null){modal('Çevrimiçi Oyuncular',`<div class="onlineOfflineCard"><div class="onlineOfflineIcon">☁️</div><h4>Sunucu bağlantısı bekleniyor</h4><p>Gerçek oyuncu sayısını göstermek için hesabın ve sunucu bağlantının aktif olması gerekiyor.</p><button class="modalAction onlineRetryBtn" data-action="homeOnline">↻ Tekrar kontrol et</button><button class="modalAction onlineLoginBtn" data-action="accountGoogle">🔵 Google ile bağlan</button></div>`);return}
 modal('Çevrimiçi Oyuncular',`<div class="onlineLiveCard"><div class="onlineLiveBadge">● CANLI</div><strong>${Number(data.count).toLocaleString('tr-TR')} aktif oyuncu</strong><p>Son 90 saniyede kalp atışı gönderen gerçek hesaplar.</p><button class="modalAction" data-action="homeOnline">↻ Yenile</button></div>`);
}

const asset=name=>`assets/${name}?v=${APP_VERSION}`;
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
async function save(){try{await Promise.all([ZDStore.set('profile',profile),ZDStore.set('difficulty',difficultyStats),ZDStore.set('dna',dna)])}catch{}}
function stopTimer(){if(state.timer){clearInterval(state.timer);state.timer=null}}
function stopTransition(){if(state.transitionTimer){clearInterval(state.transitionTimer);state.transitionTimer=null}}
let dailyCountdownTimer=null;
function stopDailyCountdown(){if(dailyCountdownTimer){clearInterval(dailyCountdownTimer);dailyCountdownTimer=null}}
function go(id){
 if(!screens.includes(id) || !$('#'+id)) id='home';
 const current=screens.find(x=>$('#'+x)?.classList.contains('active'));
 if(current && current!==id)state.previousScreen=current;
 window.__ZD_PREVIOUS_SCREEN__=state.previousScreen||'home';
 stopTimer();stopTransition();stopDailyCountdown();
 for(const x of screens){
  const el=$('#'+x);
  if(el)el.classList.toggle('active',x===id);
 }
 if(id==='dna')renderDNA();
 if(id==='daily'){try{renderDaily()}catch(e){}}
 if(id==='leaderboard'){try{renderOnlineLeaderboard()}catch(e){}}
 try{window.scrollTo(0,0)}catch(e){}
}
function modal(title,body){const m=$('#modal'),t=$('#modalTitle'),b=$('#modalBody');if(!m||!t||!b)return;t.textContent=title;b.innerHTML=body;m.classList.add('show')}
function status(t){const e=$('#status');if(!e)return;e.textContent=t;e.classList.add('show');clearTimeout(status.t);status.t=setTimeout(()=>e.classList.remove('show'),1300)}
function levelLabel(n){return ['','Kolay','Orta','Zor','Uzman','Usta'][clamp(Number(n)||2,1,5)]||'Orta'}
function declaredLevel(q){return clamp(Number(q?.level)||2,1,5)}
function dnaNode(map,key){return map[key]||(map[key]={attempts:0,correct:0,totalMs:0,fast:0,wrong:0,timeout:0,skip:0,repeatNeed:0.25,lastSeen:0})}
function dnaMetrics(n){const attempts=n.attempts||0;const accuracy=attempts?n.correct/attempts:0.5;const avgMs=attempts?n.totalMs/attempts:10000;const speed=1-clamp(avgMs/QUESTION_TIME_MS,0,1);return {accuracy,speed,repeat:clamp(n.repeatNeed??0.25,0,1)}}
function recordDNA(q,ok,timeMs,errorType){if(!q?.id)return;const now=Date.now(),cat=q.category||'Genel Bilgi',lev=String(calibratedLevel(q));for(const [map,key] of [[dna.questions,q.id],[dna.categories,cat],[dna.levels,lev]]){const n=dnaNode(map,key);n.attempts++;if(ok)n.correct++;n.totalMs+=timeMs;if(ok&&timeMs<=7000)n.fast++;if(errorType)n[errorType]=(n[errorType]||0)+1;n.lastSeen=now;n.repeatNeed=ok?clamp(n.repeatNeed-0.16,0,1):clamp(n.repeatNeed+(errorType==='timeout'?.38:errorType==='wrong'?.28:.12),0,1)}dna.history.push({id:q.id,category:cat,level:calibratedLevel(q),ok,timeMs,errorType,at:now});if(dna.history.length>60)dna.history.shift()}
function dnaQuestionNeed(q){return dnaMetrics(dnaNode(dna.questions,q.id)).repeat}
function dnaCategoryNeed(q){const m=dnaMetrics(dnaNode(dna.categories,q.category||'Genel Bilgi'));return (1-m.accuracy)*.65+m.repeat*.35}
function dnaLevelNeed(q){const m=dnaMetrics(dnaNode(dna.levels,String(calibratedLevel(q))));return (1-m.accuracy)*.55+m.repeat*.45}
function calibratedLevel(q){
 const base=declaredLevel(q), s=difficultyStats[q?.id];
 if(!s||s.attempts<5)return base;
 const acc=s.correct/s.attempts, avg=(s.totalMs/s.attempts);
 let shift=0;
 if(acc>=.85&&avg<6500)shift=1; else if(acc<.45||avg>11500)shift=-1;
 return clamp(base+shift,1,5);
}
function baseTarget(){
 // Her kategori için ilk iki soru özellikle erişilebilir tutulur;
 // sonrasında zorluk iki soruluk basamaklarla yükselir.
 if(state.index<=2)return 1;
 if(state.index<=4)return 2;
 if(state.index<=6)return 3;
 if(state.index<=8)return 4;
 return 5;
}
function targetAdaptiveLevel(){
 const base=baseTarget(), h=state.adaptiveHistory.slice(-5);
 const acc=h.length?h.filter(x=>x.ok).length/h.length:0.5;
 const avg=h.length?h.reduce((a,x)=>a+x.timeMs,0)/h.length:QUESTION_TIME_MS;
 let target=base;
 if(h.length>=3){
   if(acc>=.90 && avg<=7500) target=Math.min(5,base+1);
   else if(acc>=.96 && avg<=6000) target=Math.min(5,base+2);
   else if(acc<=.40 || avg>=13000) target=Math.max(1,base-1);
   else if(acc<=.25) target=Math.max(1,base-2);
 }
 state.adaptiveLevel=target;return target;
}
function choose(){
 const engine=state.questionEngine;
 if(!engine)return null;
 const target=targetAdaptiveLevel();
 const q=engine.next(state.selectedCategory||'Karışık',target,difficultyStats);
 if(q){state.adaptiveLevel=target;state.lastCategory=q.category||'🌍 Genel Kültür';}
 return q;
}
function setQuestionVisual(q){$('#visualDifficulty').textContent=`Zorluk: ${levelLabel(calibratedLevel(q))}`}
function shuffle(items){for(let i=items.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[items[i],items[j]]=[items[j],items[i]]}return items}
function selectCategory(cat){
 const allowed=new Set(['🏛️ Tarih','🌍 Coğrafya','💭 Felsefe','🩺 Tıp','🔬 Bilim','💻 Teknoloji','📖 Edebiyat','🎨 Sanat','⚽ Spor','💼 Ekonomi','🌍 Genel Kültür','📚 Dil','🎵 Müzik','🎬 Sinema','📘 İngilizce Gramer','⚖️ Hukuk','Karışık']);
 if(!allowed.has(cat))return;
 state.selectedCategory=cat;
 const label=$('#selectedCategoryLabel');if(label)label.textContent=cat;
 go('mode');
}
function categoryBack(){go('home')}
function startDuel(){state.score=0;state.combo=0;state.maxComboRound=0;state.hearts=MAX_WRONG;state.index=0;state.roundStart=Date.now();state.xpBefore=profile.xp||0;state.roundCorrect=0;state.roundWrong=0;state.adaptiveHistory=[];state.categorySeen=Object.create(null);state.duel={active:true};go('game');modal('Rakip aranıyor…','<p>Gerçek zamanlı rakip aranıyor.</p><p>Rakip bulunduğunda oyun otomatik başlayacak.</p>');ZDuelClient.join(state.selectedCategory||'Karışık').catch(err=>{ZDuelClient.leave();state.duel=null;$('#modal').classList.remove('show');modal('Düello bağlantısı','<p>'+escapeHtml(err.message||'Sunucuya bağlanılamadı.')+'</p><p>Yerel düello sunucusu için <b>server/</b> klasörünü çalıştırabilirsin.</p>');go('mode')});}
function start(){if(state.mode==='duel'){startDuel();return}state.score=0;state.combo=0;state.maxComboRound=0;state.hearts=MAX_WRONG;state.index=0;state.roundStart=Date.now();state.xpBefore=profile.xp||0;state.used.clear();state.usedQuestions.clear();state.usedFacts.clear();state.recent=[];state.recentCategories=[];state.recentTopics=[];state.lastCategory='';state.adaptiveHistory=[];state.adaptiveLevel=state.level;state.roundCorrect=0;state.roundWrong=0;state.categorySeen=Object.create(null);state.jokers={fifty:2,freeze:2,skip:2};state.questionEngine=new ZDQuestionEngine(bank);updateJokerUI();go('game');load()}
function load(){
 stopTimer();state.answered=false;const fb=$('#answerFeedback');if(fb)fb.className='answerFeedback';state.index++;
 if(state.roundWrong>=MAX_WRONG){finish();return}
 state.current=choose();if(!state.current){finish('pool');return}
 setQuestionVisual(state.current);$('#qnum').textContent=String(state.index);const catLabel=$('#selectedCategoryLabel');if(catLabel)catLabel.textContent=state.selectedCategory||'Karışık';$('#progressFill').style.width=`${Math.min(100, state.index*4)}%`;$('#score').textContent=state.score;$('#hearts').textContent=`${state.roundWrong}/${MAX_WRONG}`;$('#comboFooter').textContent=`x${state.combo}`;$('#adaptiveLabel').textContent=state.adaptiveLevel;$('#time').textContent=String(QUESTION_TIME_MS/1000);state.questionStart=Date.now();$('#question').textContent=state.current.question;
 const a=$('#answers');a.replaceChildren();shuffle([...state.current.options]).forEach((opt,i)=>{const b=document.createElement('button');b.className='answer';b.dataset.answer=opt;const label=document.createElement('span');label.textContent=String.fromCharCode(65+i);const text=document.createElement('b');text.textContent=opt;b.append(label,text);a.appendChild(b)});fitAnswerButtons(a);
 state.deadline=Date.now()+QUESTION_TIME_MS;updateJokerUI();state.timer=setInterval(tick,250)
}
function tick(){const left=Math.max(0,state.deadline-Date.now());$('#time').textContent=Math.ceil(left/1000);if(left<=0)answer(null,true)}
function recordDifficulty(q,ok,timeMs,errorType){if(!q?.id)return;const s=difficultyStats[q.id]||{attempts:0,correct:0,totalMs:0,wrong:0,timeout:0,skip:0};s.attempts++;if(ok)s.correct++;s.totalMs+=clamp(timeMs,0,QUESTION_TIME_MS);if(errorType)s[errorType]=(s[errorType]||0)+1;difficultyStats[q.id]=s}
async function answer(btn,timeout=false){
 if(state.answered)return;
 const q=state.current;const opt=btn?.dataset.answer;if(state.mode==='duel'&&state.duel?.active){state.answered=true;stopTimer();state.duel.lastAnswer=opt;$$('.answer').forEach(b=>b.disabled=true);if(btn)btn.classList.add('selected');ZDuelClient.answer(opt,timeout);return}state.answered=true;stopTimer();const ok=!timeout&&opt===q.correct;const timeMs=clamp(QUESTION_TIME_MS-(q?Math.max(0,state.deadline-Date.now()):0),0,QUESTION_TIME_MS);const errorType=timeout?'timeout':ok?null:'wrong';state.adaptiveHistory.push({ok,timeMs,category:q.category,difficulty:calibratedLevel(q),errorType});recordDifficulty(q,ok,timeMs,errorType);recordDNA(q,ok,timeMs,errorType);if(ok)state.roundCorrect++;else state.roundWrong++;
 $$('.answer').forEach(b=>b.disabled=true);
 // Sonuç: yanlış seçilen şık kırmızı, doğru cevap aynı anda yeşil neon olur.
 if(btn)btn.classList.add(ok?'correct':'wrong');
 if(!ok){const correctBtn=$$('.answer').find(b=>b.dataset.answer===q.correct);if(correctBtn)correctBtn.classList.add('correct');}
 markAnswerFeedback(ok,timeout);
 if(ok){state.combo++;state.maxComboRound=Math.max(state.maxComboRound,state.combo);const pts=100+Math.ceil(Math.max(0,state.deadline-Date.now())/100)*2+state.combo*10;state.score+=pts;state.lastPoints=pts;profile.bestCombo=Math.max(profile.bestCombo,state.combo)}
 else{state.combo=0;state.hearts=Math.max(0,state.hearts-1);state.score=Math.max(0,state.score-20);state.lastPoints=-20}
 profile.bestScore=Math.max(profile.bestScore,state.score);profile.xp+=ok?20:5;await ZDModel.recordSession({type:'answer',ok,points:ok?Math.max(0,state.lastPoints||0):0,category:q.category,combo:state.combo});if($('#daily')?.classList.contains('active'))renderDaily();profile=await ZDStore.get('profile')||profile;await save();$('#score').textContent=state.score;$('#hearts').textContent=`${state.roundWrong}/${MAX_WRONG}`;$('#comboFooter').textContent=`x${state.combo}`;
 // Sonuç penceresi açılmaz; kısa görsel geri bildirimden sonra soru değişir.
 updateJokerUI();startTransitionCountdown(()=>{if(state.mode!=='duel'){if(state.roundWrong>=MAX_WRONG)finish();else load()}});
}
function markAnswerFeedback(ok,timeout){
 const box=$('#answerFeedback');
 if(!box)return;
 box.className='answerFeedback '+(ok?'is-correct':'is-wrong');
 box.textContent=timeout?'⏱ Süre doldu':(ok?'✓ Doğru cevap':'✕ Yanlış cevap');
 box.classList.remove('feedback-pop');void box.offsetWidth;box.classList.add('feedback-pop');
}
function startTransitionCountdown(callback){
 let left=Math.ceil(NEXT_QUESTION_DELAY_MS/1000);
 const box=$('#answerFeedback');
 if(box)box.textContent += ` • Yeni soru ${left}`;
 const timer=setInterval(()=>{left--;if(left<=0){clearInterval(timer);callback();return}if(box)box.textContent=box.textContent.replace(/ • Yeni soru \d+$/,'')+` • Yeni soru ${left}`},1000);
 state.transitionTimer=timer;
}
function escapeHtml(s){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
function next(){if(state.roundWrong>=MAX_WRONG)finish();else{go('game');load()}}
const RESULT_QUOTES=['"Her yanlış, seni doğruya bir adım daha yaklaştırır."','"Bilgi, her zaman kazanır!"','"Pes etme, daha güçlüsün!"','"Bugünkü hata, yarının doğrusu."'];
function renderResultScreen({title,subtitle,extra='',correct=0,wrong=0,maxStreak=0,score=0,durationMs=0}){
 const total=correct+wrong;
 const accuracy=total?Math.round((correct/total)*100):0;
 const xpNow=Math.max(0,profile.xp||0);
 const xpGained=Math.max(0,xpNow-(state.xpBefore||0));
 const level=Math.floor(xpNow/XP_PER_LEVEL)+1;
 const xpInLevel=xpNow%XP_PER_LEVEL;
 const mins=Math.floor(durationMs/60000), secs=Math.max(0,Math.round((durationMs%60000)/1000));
 $('#resultTitle').textContent=title;
 $('#resultCopy').textContent=subtitle;
 const extraEl=$('#resultExtra');if(extraEl){if(extra){extraEl.textContent=extra;extraEl.hidden=false}else{extraEl.hidden=true}}
 $('#statCorrect').textContent=correct;
 $('#statWrong').textContent=wrong;
 $('#statMaxStreak').textContent=maxStreak;
 $('#statLongestStreak').textContent=`${maxStreak} doğru`;
 $('#statScore').textContent=score;
 $('#statLevel').textContent=level;
 $('#statXpGain').textContent=xpGained;
 $('#resultXpFill').style.width=`${clamp((xpInLevel/XP_PER_LEVEL)*100,0,100)}%`;
 $('#resultXpText').textContent=`${xpInLevel} / ${XP_PER_LEVEL} XP`;
 $('#statTotalQ').textContent=total;
 $('#statDuration').textContent=mins>0?`${mins} dk ${secs} sn`:`${secs} sn`;
 $('#statAccuracy').textContent=`%${accuracy}`;
 $('#resultQuote').textContent=RESULT_QUOTES[Math.floor(Math.random()*RESULT_QUOTES.length)];
 $('#resultNextHot').textContent='🏠 Ana Sayfaya Dön';$('#resultNextHot').disabled=false;$('#resultNextHot').dataset.finish='1';
 const summary=$('#resultAccessibleSummary');if(summary)summary.textContent=`Oyun bitti. ${correct} doğru, ${wrong} yanlış, ${score} puan. Seviye ${level}.`;
 go('result');
}
async function finish(reason='mistakes'){
 stopTimer();
 const durationMs=Math.max(0,Date.now()-(state.roundStart||Date.now()));
 await ZDModel.recordSession({type:'gameComplete',score:state.score,correct:state.roundCorrect,wrong:state.roundWrong,bestCombo:state.maxComboRound});
 profile=await ZDStore.get('profile')||profile;
 await save();
 try{await ZDOnline.submitGame({score:state.score,correct:state.roundCorrect,wrong:state.roundWrong,xp:100+state.roundCorrect*20+state.roundWrong*5,mode:state.mode,category:state.selectedCategory,durationMs});}catch(e){}
 renderResultScreen({
  title: reason==='pool'?'Kategori Tamamlandı!':'Oyun Bitti!',
  subtitle: reason==='pool'?'Bu kategorideki tüm soruları bir kez tamamladın.':'Pes etme, daha güçlüsün!',
  correct: state.roundCorrect,
  wrong: state.roundWrong,
  maxStreak: state.maxComboRound,
  score: state.score,
  durationMs
 });
}
function updateJokerUI(){
  for(const [id,count] of Object.entries(state.jokers)){
    const b=$(`.v161Jokers [data-action="${id}"]`);
    if(!b)continue;
    const depleted=count<=0;
    b.disabled=depleted||state.answered||state.mode==='duel';
    b.classList.toggle('joker-depleted',depleted);
    b.setAttribute('aria-disabled',String(b.disabled));
    b.setAttribute('data-uses-left',String(count));
    const badge=b.querySelector('.jokerCount');
    if(badge)badge.textContent=String(count);
  }
}
function consumeJoker(kind){
  if(state.mode==='duel'){status('Jokerler tek oyunculu oyunda kullanılır');return false}
  if(state.answered||!state.current||state.jokers[kind]<=0)return false;
  state.jokers[kind]--;
  updateJokerUI();
  return true;
}
function useFifty(){
  if(!consumeJoker('fifty'))return;
  const answers=$$('#answers .answer').filter(b=>!b.disabled);
  const wrong=answers.filter(b=>b.dataset.answer!==state.current.correct);
  shuffle(wrong).slice(0,2).forEach(b=>{
    b.disabled=true;
    b.classList.remove('correct','wrong');
    b.classList.add('eliminated');
    b.setAttribute('aria-disabled','true');
  });
  updateJokerUI();
}
function useFreeze(){
  if(!consumeJoker('freeze'))return;
  state.deadline+=5000;
  const left=Math.max(0,state.deadline-Date.now());
  const timeEl=$('#time');
  if(timeEl)timeEl.textContent=String(Math.ceil(left/1000));
  status(`+5 saniye • ${state.jokers.freeze} kaldı`);
}
function useSkip(){
  if(!consumeJoker('skip'))return;
  state.answered=true;
  stopTimer();
  const t=clamp(Date.now()-state.questionStart,0,QUESTION_TIME_MS);
  state.adaptiveHistory.push({ok:false,timeMs:t,category:state.current.category,difficulty:calibratedLevel(state.current),errorType:'skip'});
  recordDifficulty(state.current,false,t,'skip');
  recordDNA(state.current,false,t,'skip');
  save();
  status(`Soru değiştirildi • ${state.jokers.skip} kaldı`);
  startTransitionCountdown(()=>{if(state.roundWrong>=MAX_WRONG)finish();else load()});
}
function startDailyCountdown(){stopDailyCountdown();const tick=()=>{const el=$('#dailyCountdown');if(!el)return;const parts=new Intl.DateTimeFormat('en-GB',{timeZone:'Europe/Istanbul',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false}).formatToParts(new Date());const g=t=>Number(parts.find(p=>p.type===t)?.value||0);const nowSec=g('hour')*3600+g('minute')*60+g('second');let diff=Math.max(0,86400-nowSec);const h=String(Math.floor(diff/3600)).padStart(2,'0');diff%=3600;const m=String(Math.floor(diff/60)).padStart(2,'0');const s=String(diff%60).padStart(2,'0');el.textContent=`${h}:${m}:${s}`};tick();dailyCountdownTimer=setInterval(tick,1000)}
async function renderDaily(){
 const data=await ZDModel.load();const d=data.daily;const defs=ZDModel.dailyDefs;
 const list=$('#dailyMissionList');
 if(list)list.innerHTML=defs.map(x=>{
  const m=d.missions[x.id]||{progress:0,claimed:false};
  const progress=Math.min(m.progress,x.goal);const done=progress>=x.goal;const pct=Math.round((progress/x.goal)*100);
  const playAction=x.type==='duel'?'dailyPlayDuel':'dailyPlaySingle';
  const actionHtml=m.claimed?`<span class="dailyDone">✓ Alındı</span>`:done?`<button class="dailyClaimBtn" data-claim-daily="${x.id}">Al +${x.reward} XP</button>`:`<button class="dailyPlayBtn" data-action="${playAction}">Devam Ediyor</button>`;
  return `<div class="dailyCard${done?' dailyCardDone':''}"><div class="dailyCardIcon">${x.icon||'⭐'}</div><div class="dailyCardBody"><div class="dailyCardTitle">${escapeHtml(x.title)}</div><div class="dailyCardDesc">${escapeHtml(x.desc||'')}</div><div class="dailyProgressTrack"><div class="dailyProgressFill" style="width:${pct}%"></div></div><div class="dailyProgressLabel">${progress}/${x.goal}</div></div><div class="dailyCardSide"><div class="dailyRewardPill">⭐ +${x.reward} XP</div>${actionHtml}</div></div>`;
 }).join('');
 const allClaimed=defs.every(x=>d.missions[x.id]?.claimed);
 const chestBox=$('#dailyChestBox');
 if(chestBox){
  chestBox.classList.toggle('dailyChestReady',allClaimed&&!d.chestClaimed);
  chestBox.classList.toggle('dailyChestDone',!!d.chestClaimed);
  const label=$('#dailyChestLabel');
  if(label)label.textContent=d.chestClaimed?'Sandık açıldı! ✨':(allClaimed?`Sandığı aç: +${ZDModel.chestReward} XP`:'Görevleri tamamla, özel ödüller kazan!');
  const btn=chestBox.querySelector('.dailyChestBtn');
  if(btn){btn.disabled=!(allClaimed&&!d.chestClaimed);btn.textContent=d.chestClaimed?'Açıldı':'Sandığı Aç'}
 }
 startDailyCountdown();
}
function settingsModal(){modal('Ayarlar','<p>Oyun sessiz modda çalışır.</p>')}
async function languageModal(){const current=(await ZDStore.get('settings'))?.language||'tr';modal('Dil Seçimi',`<p>Mevcut dil: <b>${current.toUpperCase()}</b></p><div class="langGrid">${[['tr','🇹🇷 Türkçe'],['en','🇬🇧 English'],['es','🇪🇸 Español'],['fr','🇫🇷 Français'],['de','🇩🇪 Deutsch']].map(([k,n])=>`<button data-lang="${k}">${n}</button>`).join('')}</div>`)}
async function collectionState(){
 const settings=await ZDStore.get('settings')||{};
 return {avatar:settings.avatar||'brain',title:settings.title||'Meraklı Zihin',theme:settings.theme||'midnight'};
}
async function collectionModal(type){
 const s=await collectionState();
 const level=Math.floor((profile.xp||0)/XP_PER_LEVEL)+1;
 const data={
  avatar:{title:'Özel Avatarlar',note:'Kendi evrenimize ait avatarlar. Seçtiğin avatar profilinde kullanılmak üzere kaydedilir.',items:[
   ['brain','🧠','Zihin Çekirdeği','Başlangıç avatarı'],['spark','✦','Neon Kıvılcım','Seviye 2 ile açılır'],['orbit','◉','Yörünge','Seviye 4 ile açılır'],['crown','♛','Altın Taç','Seviye 6 ile açılır']]},
  title:{title:'Unvanlar',note:'Oyun tarzını yansıtan özgün unvanını seç.',items:[
   ['Meraklı Zihin','MERAKLI ZİHİN','İlk adımın unvanı'],['Hızlı Düşünen','HIZLI DÜŞÜNEN','Seviye 3 ile açılır'],['Bilgi Avcısı','BİLGİ AVCISI','Seviye 5 ile açılır'],['Zihin Ustası','ZİHİN USTASI','Seviye 8 ile açılır']]},
  theme:{title:'Tema Kartları',note:'Arayüz atmosferini değiştiren özgün renk temaları.',items:[
   ['midnight','🌌','Gece Mavisi','Klasik Zihin Düellosu'],['aurora','🌈','Aurora','Canlı ve modern'],['royal','👑','Kraliyet','Altın vurgu'],['violet','◈','Violet','Mor neon atmosfer']]}
 }[type];
 const unlocked=(key,i)=>type==='avatar' ? (key==='brain'||level>=({spark:2,orbit:4,crown:6}[key]||99)) : type==='theme' ? true : (i===0||level>=[3,5,8][i-1]);
 const cards=data.items.map((item,i)=>{
   const key=item[0], ok=unlocked(key,i), selected=s[type]===key;
   const icon=type==='avatar'?item[1]:type==='theme'?item[1]:'✦';
   const name=type==='avatar'?item[2]:type==='theme'?item[2]:item[1];
   const desc=type==='avatar'?item[3]:type==='theme'?item[3]:item[2];
   const action=ok?`<button data-collection-select="${escapeHtml(type)}" data-collection-key="${escapeHtml(key)}" class="${selected?'equipped':''}">${selected?'✓ Seçili':'Kullan'}</button>`:`<button disabled>🔒 Kilitli</button>`;
   return `<div class="collectionCard"><div class="collectionIcon">${icon}</div><div class="collectionTitle">${escapeHtml(name)}</div><p>${escapeHtml(desc)}</p>${action}</div>`;
 }).join('');
 modal(data.title,`<p>${escapeHtml(data.note)}</p><div class="collectionGrid">${cards}</div><p class="collectionNote">Seçimler cihazında güvenli olarak saklanır.</p>`);
}
async function applyCollection(type,key){
 const settings=await ZDStore.get('settings')||{};
 settings[type]=key;await ZDStore.set('settings',settings);profile=await ZDModel.updateIdentity({[type]:key});
 if(type==='theme'){
  document.documentElement.dataset.zdTheme=key;
  const themes={midnight:['#18a8ff','#63e6ff','#ffd24a'],aurora:['#48e0c2','#8ef0ff','#ffe66d'],royal:['#55bfff','#d7efff','#ffd24a'],violet:['#b86cff','#ef9cff','#ffe06b']}[key]||['#18a8ff','#63e6ff','#ffd24a'];
  document.documentElement.style.setProperty('--blue',themes[0]);document.documentElement.style.setProperty('--cyan',themes[1]);document.documentElement.style.setProperty('--gold',themes[2]);
 }
 status(type==='avatar'?'Avatar seçildi':type==='title'?'Unvan seçildi':'Tema uygulandı');
 $('#modal').classList.remove('show');
}

function dnaCategoryScore(name){
 const n=dna.categories[name]||dna.categories[name.replace(/^[^ ]+ /,'')];
 if(!n||!(n.attempts>0))return 50;
 const m=dnaMetrics(n); return Math.round(clamp((m.accuracy*.68+m.speed*.22+(1-m.repeat)*.10)*100,0,100));
}
function renderDNA(){
 const names=['🏛️ Tarih','🔬 Bilim','🌍 Coğrafya','💻 Teknoloji','⚽ Spor','🎨 Sanat','🌍 Genel Kültür'];
 const labels=names.map(x=>x.replace(/^\S+\s/,''));
 const scores=names.map(n=>{let v=dnaCategoryScore(n); if(!dna.categories[n]){const bare=n.replace(/^\S+\s/,''); const key=Object.keys(dna.categories).find(k=>k.includes(bare)); if(key)v=dnaCategoryScore(key)} return v});
 // New profiles start at a neutral midpoint until enough answers exist.
 const pts=scores.map((v,i)=>{const a=(Math.PI*2*i/7)-Math.PI/2;const r=1.28*v;return [Math.cos(a)*r,Math.sin(a)*r]});
 const area=document.getElementById('dnaArea');if(area)area.setAttribute('points',pts.map(p=>p.join(',')).join(' '));
 const pg=document.getElementById('dnaPoints');if(pg)pg.innerHTML=pts.map(p=>`<circle class="dnaPoint" cx="${p[0].toFixed(1)}" cy="${p[1].toFixed(1)}" r="4"/>`).join('');
 $$('.dnaChip, [data-dna-index]').forEach((el)=>{const i=Number(el.dataset.dnaIndex);if(!Number.isInteger(i)||i<0||i>6)return;el.onclick=()=>{const raw=names[i];const key=Object.keys(dna.categories).find(k=>k===raw||k.includes(labels[i]));const n=key?dna.categories[key]:null;const m=n?dnaMetrics(n):null;modal(labels[i],`<p><b>Profil puanın: ${scores[i]}/100</b></p><p>${m?`Doğruluk: <b>%${Math.round(m.accuracy*100)}</b><br>Hız: <b>%${Math.round(m.speed*100)}</b><br>Tekrar ihtiyacı: <b>%${Math.round(m.repeat*100)}</b>`:'Bu alanda henüz yeterli oyun verisi yok. Oynadıkça Zihin DNA profilin otomatik güncellenecek.'}</p>`)}});
 const ranked=labels.map((name,i)=>({name,score:scores[i]})).sort((a,b)=>b.score-a.score);const strong=document.getElementById('dnaStrengths'),growth=document.getElementById('dnaGrowth');if(strong)strong.textContent=ranked.slice(0,3).map(x=>x.name).join(', ');if(growth)growth.textContent=ranked.slice(-2).reverse().map(x=>x.name).join(', ');
}
function dnaModal(){const rows=Object.entries(dna.categories).map(([k,n])=>{const m=dnaMetrics(n);return `<div><b>${escapeHtml(k)}</b><span>%${Math.round(m.accuracy*100)} doğruluk • ${Math.round(m.speed*100)} hız • ${Math.round(m.repeat*100)} tekrar ihtiyacı</span></div>`}).sort();modal('Zihin DNA',`<p>Profilin <b>hız + doğruluk + kategori + zorluk + hata tipi + tekrar ihtiyacı</b> üzerinden canlı güncelleniyor.</p><div class="dnaMini">${rows.slice(0,6).join('')}</div>`)}
function profileAvatarIcon(key){return ({brain:'🧠',spark:'✦',orbit:'◉',crown:'♛'})[key]||'🧠'}
function profileModal(){
 const xp=Number(profile.xp||0), level=ZDModel.xpLevel?ZDModel.xpLevel(xp):Math.floor(xp/XP_PER_LEVEL)+1;
 const inLevel=ZDModel.xpInLevel?ZDModel.xpInLevel(xp):xp%XP_PER_LEVEL;
 const pct=ZDModel.levelProgress?ZDModel.levelProgress(xp):Math.round(inLevel/XP_PER_LEVEL*100);
 const total=Number(profile.correct||0)+Number(profile.wrong||0);
 const acc=total?Math.round(Number(profile.correct||0)/total*100):0;
 const avatar=profileAvatarIcon(profile.avatar);
 const name=escapeHtml(profile.displayName||'Zihin Oyuncusu');
 const onlineUser=ZDOnline?.user||null;
 const accountBlock=onlineUser?`<div class="profileIdentity accountLinked"><div class="accountLinkedTop"><div><label>Gerçek hesap</label><strong>✓ ${escapeHtml(onlineUser.user_metadata?.full_name||onlineUser.user_metadata?.name||onlineUser.email?.split('@')[0]||'Google hesabı')}</strong><small>Google ile bağlandı • Profil, XP ve online durumun senkronize ediliyor.</small></div><span class="accountOnlineBadge">● Aktif</span></div><button data-action="profileLogout">Hesaptan çıkış yap</button></div>`:`<div class="profileIdentity accountUnlinked"><label>Gerçek hesap</label><small>Profilini cihazdan bağımsız saklamak, gerçek liderlik tablosuna katılmak ve çevrimiçi oyuncu sayısına dahil olmak için giriş yap.</small><div class="accountChoiceRow"><button data-action="profileGoogle">🔵 Google ile giriş</button><button data-action="profileApple"> Apple ile giriş</button></div></div>`;
 const title=escapeHtml(profile.title||'Meraklı Zihin');
 modal('Oyuncu Profilim',`<div class="profileHeroCard">
   <div class="profileAvatarBig">${avatar}</div>
   <div class="profileHeroInfo"><div class="profileNameLine"><b>${name}</b><span>Seviye ${level}</span></div><div class="profileTitle">${title}</div><div class="profileXpText">${inLevel} / ${XP_PER_LEVEL} XP</div><div class="profileXpTrack"><div class="profileXpFill" style="width:${pct}%"></div></div><div class="profileXpMeta"><span>Toplam ${xp.toLocaleString('tr-TR')} XP</span><span>${1000-inLevel} XP sonraki seviye</span></div></div>
 </div>
 ${accountBlock}
 <div class="profileIdentity"><label>Oyuncu adı</label><div class="profileNameEdit"><input id="profileNameInput" maxlength="20" value="${name}" aria-label="Oyuncu adı"><button data-action="profileSave">Kaydet</button></div><small>Bu ad cihazında güvenli olarak saklanır.</small></div>
 <div class="profileStatsGrid"><div><span>🎮 Oyun</span><b>${profile.games||0}</b></div><div><span>🎯 Doğru</span><b>${profile.correct||0}</b></div><div><span>📈 Başarı</span><b>%${acc}</b></div><div><span>🔥 Seri</span><b>${profile.streak||0}</b></div><div><span>🏆 En yüksek skor</span><b>${profile.bestScore||0}</b></div><div><span>⚔️ Düello</span><b>${profile.duelsWon||0} galibiyet</b></div></div>
 <div class="profileActions"><button data-action="profileAchievements">🏅 Başarımlar</button><button data-action="profileAvatar">🎭 Avatar</button><button data-action="profileTitle">👑 Unvan</button><button data-action="profileTheme">🎨 Tema</button><button data-action="profileDNA">🧬 Zihin DNA</button></div>`);
}
async function profileSave(){
 const input=$('#profileNameInput'); if(!input)return;
 const value=String(input.value||'').trim().replace(/\s+/g,' ');
 if(value.length<2){status('Oyuncu adı en az 2 karakter olmalı');return}
 profile=await ZDModel.updateIdentity({displayName:value});
 status('Profil kaydedildi');try{await ZDOnline.syncProfile()}catch(e){}profileModal();
}
function profileDNA(){ $('#modal').classList.remove('show'); dnaModal(); }
async function achievementsModal(){
 const list=await ZDModel.achievementProgress(profile);
 const rows=Object.values(list).map(a=>{const progress=Math.min(a.progress,a.goal);const ready=a.unlocked&&!a.claimed;const action=ready?`<button class="modalAction" data-claim-achievement="${escapeHtml(a.id)}">Al +${a.reward} XP</button>`:a.claimed?'<span>✓ Alındı</span>':`<span>${progress}/${a.goal}</span>`;return `<div class="achievementRow"><div><b>${escapeHtml(a.name)}</b><small>${progress}/${a.goal} • +${a.reward} XP</small></div><div>${action}</div></div>`}).join('');
 modal('Başarımlar',`<p>Başarımlar tamamlandığında XP ödülünü profilinden alabilirsin.</p><div class="achievementList">${rows}</div>`);
}
function renderQuestionFromServer(q,round,total,deadlineMs,deadlineAt){go('game');state.duel=state.duel||{active:true};state.duel.lastAnswer=null;const fb=$('#answerFeedback');if(fb)fb.className='answerFeedback';state.current=q;state.index=round;state.answered=false;$('#qnum').textContent=String(round);const catLabel=$('#selectedCategoryLabel');if(catLabel)catLabel.textContent=q.category||state.selectedCategory||'Karışık';$('#progressFill').style.width=`${Math.min(100, round*4)}%`;$('#score').textContent=state.score;$('#hearts').textContent=`${state.roundWrong}/${MAX_WRONG}`;$('#comboFooter').textContent=`x${state.combo}`;$('#adaptiveLabel').textContent=state.level;$('#time').textContent=Math.ceil(deadlineMs/1000);$('#question').textContent=q.question;setQuestionVisual(q);const a=$('#answers');a.replaceChildren();shuffle([...q.options]).forEach((opt,i)=>{const b=document.createElement('button');b.className='answer';b.dataset.answer=opt;const label=document.createElement('span');label.textContent=String.fromCharCode(65+i);const text=document.createElement('b');text.textContent=opt;b.append(label,text);a.appendChild(b)});fitAnswerButtons(a);state.questionStart=Date.now();state.deadline=deadlineAt||Date.now()+deadlineMs;state.timer=setInterval(tick,250)}
ZDuelClient.handlers={
 wait:m=>status('Rakip aranıyor…'),
 match:m=>{$('#modal').classList.remove('show');status('Rakip bulundu!'),state.duel.opponent=m.opponent||'Rakip'},
 question:(q,m)=>renderQuestionFromServer(q,m.round,m.total,m.deadlineMs||QUESTION_TIME_MS,m.deadlineAt),
 result:async m=>{const me=m.results.find(x=>x.id===ZDuelClient.playerId)||m.results.find(x=>x.id);const ok=!!me?.ok;state.roundCorrect+=ok?1:0;state.roundWrong+=ok?0:1;state.score=me?.score??state.score;state.combo=me?.combo??state.combo;state.maxComboRound=Math.max(state.maxComboRound,state.combo||0);state.hearts=me?.hearts??state.hearts;$('#score').textContent=state.score;$('#hearts').textContent=`${state.roundWrong}/${MAX_WRONG}`;$('#comboFooter').textContent=`x${state.combo}`;state.current={...state.current,correct:m.correct,explanation:m.explanation,fact:m.fact};
 const chosen=$$('.answer').find(b=>b.dataset.answer===state.duel?.lastAnswer);
 if(chosen)chosen.classList.add(ok?'correct':'wrong');
 // Düelloda da yanlış seçim kırmızı; doğru cevap aynı anda yeşil neon olur.
 if(!ok){const correctBtn=$$('.answer').find(b=>b.dataset.answer===m.correct);if(correctBtn)correctBtn.classList.add('correct');}
 markAnswerFeedback(ok,!!me?.timedOut);startTransitionCountdown(()=>{});},
 finish:async m=>{
  stopTimer();
  const me=m.standings.find(x=>x.playerId===ZDuelClient.playerId)||m.standings[0];
  const opponent=m.standings.find(x=>x.playerId!==ZDuelClient.playerId);
  const won=m.winnerId===ZDuelClient.playerId;
  const durationMs=Math.max(0,Date.now()-(state.roundStart||Date.now()));
  await ZDModel.recordSession({type:'duelComplete',won,score:me?.score||state.score,correct:me?.correct||state.roundCorrect,wrong:me?.wrong||state.roundWrong,bestCombo:state.maxComboRound});if($('#daily')?.classList.contains('active'))renderDaily();
  profile=await ZDStore.get('profile')||profile;
  state.duel=null;
  $('#modal').classList.remove('show');
  renderResultScreen({
   title: won?'Rakibini Yendin!':'Düello Tamamlandı',
   subtitle:'Gerçek zamanlı düello sonucun',
   extra: opponent?`Rakibin ${opponent.name||'Rakip'}: ${opponent.score} puan`:'',
   correct: me?.correct??state.roundCorrect,
   wrong: me?.wrong??state.roundWrong,
   maxStreak: state.maxComboRound,
   score: me?.score??state.score,
   durationMs
  });
 },
 error:msg=>{ZDuelClient.leave();state.duel=null;$('#modal').classList.remove('show');modal('Düello bağlantısı',`<p>${escapeHtml(msg)}</p>`);go('category')},
 close:()=>{if(state.duel?.active){status('Bağlantı yeniden kuruluyor…')}}
};

const actions={
 accountGoogle:accountGoogle,accountApple:accountApple,accountGuest:continueGuest,
 homeStart:()=>{if(!ZDOnline?.user){try{if(localStorage.getItem('zd_guest_mode')!=='1'){accountGate();return}}catch{accountGate();return}} state.mode='single';go('category')},leaderboard:()=>go('leaderboard'),profileGoogle:accountGoogle,profileApple:accountApple ,profileLogout:async()=>{try{await ZDOnline.signOut();status('Google hesabından çıkıldı');profileModal()}catch(e){modal('Hesap','<p>Çıkış yapılamadı.</p>')}},leaderboardRefresh:()=>renderOnlineLeaderboard(),homeOnline:()=>showOnlineCount(),categoryBack:categoryBack,categorySelect:(cat)=>selectCategory(cat),profile:profileModal,settings:settingsModal,language:languageModal,
 modeBack:()=>go('category'),modeDaily:()=>go('daily'),modeProfile:profileModal,modeSettings:settingsModal,modeSingle:()=>{state.mode='single';start()},modeDuel:()=>{state.mode='duel';startDuel()},modeReward1:()=>go('achievements'),modeReward2:()=>collectionModal('avatar'),modeReward3:()=>collectionModal('title'),modeReward4:()=>collectionModal('theme'),modeBottom1:()=>go('home'),modeBottom2:()=>go('daily'),modeBottom3:profileModal,
 gameBack:()=>{if(state.duel?.active){ZDuelClient.leave();state.duel=null}go('category')},resultNextHot:next,resultReplay:()=>start(),resultLeaderboard:()=>go('leaderboard'),dnaBack:()=>go('home'),dnaInfo:()=>dnaModal(),dnaStrength:()=>dnaModal(),dnaGrowth:()=>dnaModal(),achievementsBack:()=>go(state.previousScreen||'home'),profileSave:profileSave,profileAchievements:()=>{achievementsModal()},profileAvatar:()=>collectionModal('avatar'),profileTitle:()=>collectionModal('title'),profileTheme:()=>collectionModal('theme'),profileDNA:profileDNA,achTab1:achievementsModal,achTab2:achievementsModal,achTab3:achievementsModal,achTab4:achievementsModal,achRow1:achievementsModal,achRow2:achievementsModal,achRow3:achievementsModal,achRow4:achievementsModal,achRow5:achievementsModal,achRow6:achievementsModal,achRow7:achievementsModal,achRow8:achievementsModal,achBottom1:()=>go('home'),achBottom2:()=>go('daily'),achBottom3:()=>go('achievements'),achBottom4:profileModal,navHome:()=>go('home'),navDaily:()=>go('daily'),navAchievements:()=>go('achievements'),navProfile:profileModal,dailyBack:()=>go('home'),leaderboardBack:()=>go('home'),dailyPlaySingle:()=>{state.mode='single';go('category')},dailyPlayDuel:()=>{state.mode='duel';go('category')},dailyNavHome:()=>go('home'),dailyNavLeaderboard:()=>go('leaderboard'),dailyNavPlay:()=>{state.mode='single';go('category')},dailyNavStats:()=>modal('İstatistik','<p>Doğruluk, hız, zorluk ve kategori performansın oyun motoru tarafından ayrı ayrı ölçülür.</p>'),dailyNavSettings:settingsModal
};
document.addEventListener('click',async e=>{const collection=e.target.closest('[data-collection-select]');if(collection){e.preventDefault();await applyCollection(collection.dataset.collectionSelect,collection.dataset.collectionKey);return}const claim=e.target.closest('[data-claim-daily]');if(claim){if(await ZDModel.claimDaily(claim.dataset.claimDaily)){profile=await ZDStore.get('profile')||profile;status('Ödül alındı');await renderDaily()}return}const claimChest=e.target.closest('[data-claim-chest]');if(claimChest){if(await ZDModel.claimChest()){profile=await ZDStore.get('profile')||profile;status(`Sandık açıldı! +${ZDModel.chestReward} XP`);await renderDaily()}else{status('Önce tüm görevleri tamamla')}return}const a=e.target.closest('[data-action]');if(!a)return;e.preventDefault();const id=a.dataset.action;if(id==='categorySelect'){selectCategory(a.dataset.category);return}if(id==='resultNextHot'&&a.dataset.finish==='1'){go('home');return}if(id==='modalClose'){e.stopPropagation();$('#modal').classList.remove('show');return}if(id==='fifty'){useFifty();return}if(id==='freeze'){useFreeze();return}if(id==='skip'){useSkip();return}if(id==='resultNextHot'){next();return}if(actions[id])actions[id]()});
const answerRoot=$('#answers');if(answerRoot)answerRoot.addEventListener('click',e=>{const b=e.target.closest('.answer');if(b && !b.disabled)answer(b,false)});const closeModal=$('#closeModal');if(closeModal)closeModal.addEventListener('click',()=>$('#modal').classList.remove('show'));
const modalRoot=$('#modal');if(modalRoot)modalRoot.addEventListener('click',async e=>{
 if(e.target.id==='modal'){e.currentTarget.classList.remove('show');return}
 const lang=e.target.closest('[data-lang]');if(lang){await ZDStore.set('settings',{language:lang.dataset.lang});$('#modal').classList.remove('show');status('Dil seçildi')}});
bootAuth().then(()=>accountGate());
window.addEventListener('zd-auth-profile',async()=>{try{profile=(await ZDModel.load()).profile||profile}catch(_){} accountGate(); if($('#modal')?.classList.contains('show')){const title=$('#modalTitle')?.textContent||'';if(title==='Oyuncu Profilim')profileModal()} if($('#leaderboard')?.classList.contains('active'))renderOnlineLeaderboard()});
window.addEventListener('online',()=>{initOnline();if($('#leaderboard')?.classList.contains('active'))renderOnlineLeaderboard()});
window.addEventListener('resize',()=>{if($('#game')?.classList.contains('active'))fitAnswerButtons($('#answers'))});
window.addEventListener('orientationchange',()=>{if($('#game')?.classList.contains('active'))setTimeout(()=>fitAnswerButtons($('#answers')),150)});
window.ZD_USE_FIFTY=useFifty;
window.ZD_USE_FREEZE=useFreeze;
window.ZD_USE_SKIP=useSkip;
window.ZD={go,start,startDuel,levelValue:()=>state.adaptiveLevel,stats:{bank:bank.length},version:'198',engine:'V198 unique 286 authored question bank + progressive category difficulty + knowledge-family diversity + adaptive difficulty + unique-per-game questions + Supabase Google accounts + real profiles + real leaderboard + real online presence'};
})();

