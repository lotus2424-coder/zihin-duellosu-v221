/* Zihin Düellosu V197 — Google OAuth mobile/itch.io stability fix */
(()=>{
'use strict';

const SUPABASE_URL='https://mzzfuktigdsdrycmnwpz.supabase.co';
const SUPABASE_PUBLISHABLE_KEY='sb_publishable_S2OF4azJVyWvBHkYxFBuIg_X8GqnFUJ';

const ready=()=>!!(window.supabase&&window.supabase.createClient);
let client=null;

function getClient(){
 if(!ready())throw new Error('SUPABASE_LIBRARY_NOT_LOADED');
 if(!client){
  client=window.supabase.createClient(
   SUPABASE_URL,
   SUPABASE_PUBLISHABLE_KEY,
   {
    auth:{
     persistSession:true,
     autoRefreshToken:true,
     // V197: OAuth returns a PKCE authorization code. We exchange it
     // explicitly in bootAuth(), so Supabase must not process the URL twice.
     detectSessionInUrl:false,
     flowType:'pkce'
    }
   }
  );
 }
 return client;
}

async function getSession(){
 const {data,error}=await getClient().auth.getSession();
 if(error)throw error;
 return data.session;
}

function cleanOAuthUrl(){
 try{
  const u=new URL(window.location.href);
  u.searchParams.delete('code');
  u.searchParams.delete('error');
  u.searchParams.delete('error_code');
  u.searchParams.delete('error_description');
  u.searchParams.delete('state');
  history.replaceState({},document.title,u.pathname+(u.search?'?'+u.searchParams.toString():'')+u.hash);
 }catch(_){}
}

async function completeOAuthCallback(){
 const url=new URL(window.location.href);
 const code=url.searchParams.get('code');
 const errorCode=url.searchParams.get('error');
 if(errorCode){
  const desc=url.searchParams.get('error_description')||errorCode;
  cleanOAuthUrl();
  throw new Error(desc);
 }
 if(!code)return false;

 // V197: PKCE code exchange is performed exactly once, in the same tab
 // that received the OAuth redirect. This avoids the old popup/second-tab
 // race on iOS Safari.
 const {data,error}=await getClient().auth.exchangeCodeForSession(code);
 if(error)throw error;
 cleanOAuthUrl();
 return !!data?.session;
}

function appReturnUrl(){
 // Use the exact game document that started OAuth. Supabase/Google must have
 // this URL allowlisted. Remove only the OAuth hash/query, never the path.
 const u=new URL(window.location.href);
 u.search='';
 u.hash='';
 return u.toString();
}

async function signInProvider(provider){
 const redirectTo=appReturnUrl();

 const {data,error}=await getClient().auth.signInWithOAuth({
  provider,
  options:{
   redirectTo,
   // V197: do NOT open about:blank / popup. On iPhone + itch.io this could
   // leave a dead tab or close the game after the Google account picker.
   // Navigating the current document keeps the PKCE verifier and OAuth state
   // in the same browser storage context.
   skipBrowserRedirect:true,
   queryParams:provider==='google'
    ?{access_type:'offline',prompt:'select_account'}
    :undefined
  }
 });

 if(error)throw error;
 const oauthUrl=data?.url;
 if(!oauthUrl)throw new Error('OAUTH_URL_MISSING');

 // The game may be embedded by itch.io. Navigate the top-level page when
 // possible so Google is never rendered inside an iframe (X-Frame-Options
 // would otherwise make the flow appear to crash/close).
 try{
  if(window.top && window.top!==window){
   window.top.location.assign(oauthUrl);
  }else{
   window.location.assign(oauthUrl);
  }
 }catch(_){
  window.location.assign(oauthUrl);
 }
 return data;
}

async function signInGoogle(){return signInProvider('google')}
async function signInApple(){return signInProvider('apple')}
async function signOut(){
 const {error}=await getClient().auth.signOut();
 if(error)throw error;
}
async function currentUser(){
 const s=await getSession();
 return s?.user||null;
}
function onAuthStateChange(fn){
 return getClient().auth.onAuthStateChange(fn);
}

window.ZDSupabase={
 SUPABASE_URL,
 getClient,
 getSession,
 completeOAuthCallback,
 currentUser,
 signInProvider,
 signInGoogle,
 signInApple,
 signOut,
 onAuthStateChange
};
})();
