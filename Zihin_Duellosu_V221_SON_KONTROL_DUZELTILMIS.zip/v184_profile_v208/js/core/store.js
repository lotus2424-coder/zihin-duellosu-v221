/* V181 script 6; execution order preserved. */

/* Zihin Düellosu V51/V55 — bounded resilient storage */
(()=>{
'use strict';
const DB='zihin_duellosu_data', VER=1;
const stores=['profile','settings','dna','difficulty','achievements','daily'];
const TIMEOUT=700;
let dbPromise=null, fallback=false;
const memory=Object.create(null);
const key=(s,k='state')=>`zd:${s}:${k}`;

function memGet(s,k='state'){
  const id=key(s,k);
  if(Object.prototype.hasOwnProperty.call(memory,id)) return memory[id];
  try{const v=localStorage.getItem(id);return v===null?undefined:JSON.parse(v)}catch{return undefined}
}
function memSet(s,v,k='state'){
  memory[key(s,k)]=v;
  try{localStorage.setItem(key(s,k),JSON.stringify(v))}catch{}
  return v;
}
function withTimeout(p,ms=TIMEOUT){
  return Promise.race([
    p,
    new Promise((_,rej)=>setTimeout(()=>rej(new Error('storage timeout')),ms))
  ]);
}
function open(){
  if(fallback)return Promise.reject(new Error('fallback'));
  if(dbPromise)return dbPromise;
  dbPromise=withTimeout(new Promise((resolve,reject)=>{
    try{
      if(!window.indexedDB){reject(new Error('no indexeddb'));return}
      const r=indexedDB.open(DB,VER);
      r.onupgradeneeded=()=>{
        const d=r.result;
        for(const s of stores)if(!d.objectStoreNames.contains(s))d.createObjectStore(s);
      };
      r.onsuccess=()=>resolve(r.result);
      r.onerror=()=>reject(r.error||new Error('indexeddb error'));
      r.onblocked=()=>reject(new Error('indexeddb blocked'));
    }catch(e){reject(e)}
  })).catch(e=>{fallback=true;dbPromise=null;throw e});
  return dbPromise;
}
async function get(s,k='state'){
  try{
    const db=await open();
    return await withTimeout(new Promise((resolve,reject)=>{
      try{
        const r=db.transaction(s,'readonly').objectStore(s).get(k);
        r.onsuccess=()=>resolve(r.result);
        r.onerror=()=>reject(r.error);
      }catch(e){reject(e)}
    }));
  }catch{return memGet(s,k)}
}
async function set(s,v,k='state'){
  try{
    const db=await open();
    return await withTimeout(new Promise((resolve,reject)=>{
      try{
        const r=db.transaction(s,'readwrite').objectStore(s).put(v,k);
        r.onsuccess=()=>resolve(v);
        r.onerror=()=>reject(r.error);
      }catch(e){reject(e)}
    }));
  }catch{return memSet(s,v,k)}
}
async function migrate(){
  try{
    const oldP=memGet('legacy_profile','state')||JSON.parse(localStorage.getItem('zd_profile_v5')||'null');
    const oldD=memGet('legacy_difficulty','state')||JSON.parse(localStorage.getItem('zd_difficulty_v49')||'null');
    const oldN=memGet('legacy_dna','state')||JSON.parse(localStorage.getItem('zd_dna_v49')||'null');
    if(oldP && !await get('profile')) await set('profile',oldP);
    if(oldD && !await get('difficulty')) await set('difficulty',oldD);
    if(oldN && !await get('dna')) await set('dna',oldN);
  }catch{}
  try{
    ['zd_profile_v5','zd_difficulty_v49','zd_dna_v49','zd_lang'].forEach(k=>localStorage.removeItem(k));
  }catch{}
}
async function init(){
  // Never block application boot on storage initialization.
  try{await withTimeout(open(),TIMEOUT)}catch{fallback=true}
  // Migration is deliberately background work; the UI/game must boot first.
  migrate().catch(()=>{});
  return true;
}
window.ZDStore={init,get,set,removeLegacy:async()=>{}};
})();
