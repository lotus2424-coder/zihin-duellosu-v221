/* V181 script 7; execution order preserved. */

/* V51 domain model: profile, achievements and daily missions. */
(()=>{
'use strict';
const profileDefaults={version:2,xp:0,games:0,correct:0,wrong:0,bestCombo:0,bestScore:0,streak:0,lastPlayedDate:null,duelsPlayed:0,duelsWon:0,duelsLost:0,displayName:'Zihin Oyuncusu',avatar:'brain',title:'Meraklı Zihin',theme:'midnight',createdAt:null,lastActiveAt:null};
const achievementDefs=[
{id:'first_step',name:'İlk Adım',goal:1,field:'games',reward:50},
{id:'ten_correct',name:'10 Doğru',goal:10,field:'correct',reward:100},
{id:'combo_master',name:'Combo Ustası',goal:5,field:'bestCombo',reward:150},
{id:'science_expert',name:'Bilim Uzmanı',goal:10,field:'category:Bilim',reward:200},
{id:'mind_champion',name:'Zihin Şampiyonu',goal:100,field:'correct',reward:500},
{id:'duel_winner',name:'Düello Galibi',goal:1,field:'duelsWon',reward:250},
{id:'daily_master',name:'Günlük Usta',goal:7,field:'dailyCompleted',reward:300},
{id:'streak_master',name:'Kesintisiz Seri',goal:7,field:'streak',reward:400}
];
/* Daily missions — matches the in-game "Günlük Görevler" screen artwork. */
const dailyDefs=[
{id:'play3',title:'3 Soru Çöz',desc:'Bugün en az 3 soru cevapla.',goal:3,type:'questions',reward:50,icon:'💡'},
{id:'category3',title:'Farklı Kategori Oyna',desc:'Bugün en az 3 farklı kategoride oyna.',goal:3,type:'category',reward:75,icon:'🌍'},
{id:'combo3',title:'Combo Yap (3+)',desc:'Arka arkaya en az 3 doğru cevap ver.',goal:1,type:'combo',reward:100,icon:'🎯'},
{id:'duel1',title:'Düello Oyna',desc:'Bugün en az 1 düello maçı yap.',goal:1,type:'duel',reward:100,icon:'⚔️'}
];
const CHEST_REWARD=200;
function dayKey(d=new Date()){return new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Istanbul'}).format(d)}
function freshDaily(){return {date:dayKey(),completed:false,chestClaimed:false,categories:[],missions:Object.fromEntries(dailyDefs.map(x=>[x.id,{progress:0,claimed:false}]))}}
function mergeProfile(p){const out={...profileDefaults,...(p||{})}; if(!out.createdAt)out.createdAt=new Date().toISOString(); if(!out.lastActiveAt)out.lastActiveAt=out.createdAt; return out}
function xpLevel(xp=0){return Math.floor(Math.max(0,Number(xp)||0)/1000)+1}
function xpInLevel(xp=0){return Math.max(0,Number(xp)||0)%1000}
function xpToNext(xp=0){return 1000-xpInLevel(xp)}
function levelProgress(xp=0){return Math.round((xpInLevel(xp)/1000)*100)}
async function updateIdentity(patch={}){const data=await load();const p=mergeProfile({...data.profile,...patch,lastActiveAt:new Date().toISOString()});await saveProfile(p);return p}
function normalizeDaily(d){
 if(!d||d.date!==dayKey())return freshDaily();
 if(!d.missions||!dailyDefs.every(x=>d.missions[x.id]))return freshDaily();
 d.categories=Array.isArray(d.categories)?d.categories:[];
 d.chestClaimed=!!d.chestClaimed;
 return d;
}
async function load(){return {profile:mergeProfile(await ZDStore.get('profile')),achievements:await ZDStore.get('achievements')||{},daily:normalizeDaily(await ZDStore.get('daily'))}}
async function saveProfile(p){return ZDStore.set('profile',mergeProfile(p))}
async function recordSession(evt){
 const data=await load(); const p=data.profile; const d=data.daily;
 if(evt.type==='answer'){
  if(d.missions.play3)d.missions.play3.progress=Math.min(3,d.missions.play3.progress+1);
  const cat=String(evt.category||'').trim();
  if(cat&&!d.categories.includes(cat)){d.categories.push(cat);if(d.missions.category3)d.missions.category3.progress=Math.min(3,d.categories.length)}
  if((evt.combo||0)>=3&&d.missions.combo3)d.missions.combo3.progress=1;
  if(String(evt.category||'').includes('Bilim')&&evt.ok){const a=await ZDStore.get('achievements')||{};a.science_expert={...(a.science_expert||{}),progress:(a.science_expert?.progress||0)+1};await ZDStore.set('achievements',a);}
 }
 if(evt.type==='gameComplete'){p.games++;p.xp+=100;const today=dayKey();p.streak=p.lastPlayedDate===today?p.streak: (p.lastPlayedDate===dayKey(new Date(Date.now()-86400000))?p.streak+1:1);p.lastPlayedDate=today;}
 if(evt.type==='duelComplete'){p.duelsPlayed++;if(evt.won)p.duelsWon++;else p.duelsLost++;if(d.missions.duel1)d.missions.duel1.progress=1;}
 p.correct+=evt.correct||0;p.wrong+=evt.wrong||0;p.bestCombo=Math.max(p.bestCombo,evt.bestCombo||0);p.bestScore=Math.max(p.bestScore,evt.score||0);p.xp+=evt.xp||0;p.lastActiveAt=new Date().toISOString();
 await saveProfile(p);await ZDStore.set('daily',d);return {profile:p,daily:d};
}
async function claimDaily(id){const data=await load();const d=data.daily,m=d.missions[id];if(!m)return false;const def=dailyDefs.find(x=>x.id===id);if(!def||m.claimed||m.progress<def.goal)return false;m.claimed=true;const p=data.profile;p.xp+=def.reward;await saveProfile(p);await ZDStore.set('daily',d);return true}
async function claimAchievement(id){const data=await load();const def=achievementDefs.find(x=>x.id===id);if(!def)return false;const a=data.achievements||{};const progress=def.field.startsWith('category:')?(a[id]?.progress||0):Number(data.profile[def.field]||0);if(progress<def.goal||a[id]?.claimed)return false;a[id]={...(a[id]||{}),progress,claimed:true,claimedAt:new Date().toISOString()};data.profile.xp+=def.reward;data.profile.lastActiveAt=new Date().toISOString();await saveProfile(data.profile);await ZDStore.set('achievements',a);return true}
async function claimChest(){const data=await load();const d=data.daily;if(d.chestClaimed)return false;const allDone=dailyDefs.every(x=>d.missions[x.id]?.claimed);if(!allDone)return false;d.chestClaimed=true;const p=data.profile;p.xp+=CHEST_REWARD;await saveProfile(p);await ZDStore.set('daily',d);return true}
async function achievementProgress(p){const a=await ZDStore.get('achievements')||{};const out={};for(const def of achievementDefs){let progress=0;if(def.field.startsWith('category:'))progress=a[def.id]?.progress||0;else progress=Number(p[def.field]||0);out[def.id]={...def,progress,unlocked:progress>=def.goal,claimed:!!a[def.id]?.claimed};}return out}
window.ZDModel={profileDefaults,achievementDefs,dailyDefs,chestReward:CHEST_REWARD,dayKey,freshDaily,load,saveProfile,recordSession,claimDaily,claimChest,claimAchievement,achievementProgress,xpLevel,xpInLevel,xpToNext,levelProgress,updateIdentity};
})();

