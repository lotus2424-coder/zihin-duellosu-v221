/* V181 script 1; execution order preserved. */

(function(){
  function fitArt(){
    document.querySelectorAll('.stage').forEach(function(stage){
      var img=stage.querySelector('img'); if(!img)return;
      function set(){ if(img.naturalWidth&&img.naturalHeight) stage.style.setProperty('--art-ratio',(img.naturalWidth/img.naturalHeight).toFixed(6)); }
      if(img.complete)set(); else img.addEventListener('load',set,{once:true});
    });
  }
  window.addEventListener('resize',fitArt,{passive:true});
  window.addEventListener('orientationchange',function(){setTimeout(fitArt,80);},{passive:true});
  document.addEventListener('DOMContentLoaded',fitArt);
})();
