/* V187 — mobile orientation guard. Best-effort portrait lock for Android fullscreen. */
(()=>{
'use strict';
const isMobile=()=>/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent||'');
async function lockPortrait(){
 if(!isMobile()||!screen.orientation?.lock)return false;
 try{await screen.orientation.lock('portrait');return true}catch(_){return false}
}
function sync(){
 document.documentElement.style.setProperty('--zd-vw',(window.visualViewport?.width||innerWidth)+'px');
 document.documentElement.style.setProperty('--zd-vh',(window.visualViewport?.height||innerHeight)+'px');
}
window.addEventListener('resize',sync,{passive:true});
window.addEventListener('orientationchange',()=>setTimeout(sync,80),{passive:true});
if(window.visualViewport)window.visualViewport.addEventListener('resize',sync,{passive:true});
document.addEventListener('DOMContentLoaded',()=>{sync();lockPortrait();},{once:true});
document.addEventListener('pointerdown',()=>{lockPortrait();},{once:true,passive:true});
})();
