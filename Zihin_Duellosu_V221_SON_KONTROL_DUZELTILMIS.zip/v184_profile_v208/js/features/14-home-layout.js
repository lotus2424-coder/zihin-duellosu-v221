/* V181 script 13; execution order preserved. */

(function(){
  function fitHome(){
    var home=document.getElementById('home');
    if(!home)return;
    var stage=home.querySelector('.stage');
    if(!stage)return;
    var r=stage.getBoundingClientRect(), w=r.width, h=r.height;
    if(!w||!h)return;
    var targets={homeProfile:[.031,.0415,.278,.070],homeLang:[.644,.0415,.220,.070],homeSettings:[.885,.0415,.105,.070],homeStart:[.240,.570,.520,.075],homeLeaderboard:[.082,.734,.330,.095],homeOnline:[.585,.734,.330,.095]};
    Object.keys(targets).forEach(function(k){
      var e=home.querySelector('.'+k), b=targets[k];
      if(!e)return;
      e.style.left=(b[0]*w)+'px'; e.style.top=(b[1]*h)+'px';
      e.style.width=(b[2]*w)+'px'; e.style.height=(b[3]*h)+'px';
    });
  }
  function later(){requestAnimationFrame(fitHome)}
  window.addEventListener('resize',later,{passive:true});
  window.addEventListener('orientationchange',function(){setTimeout(fitHome,120)},{passive:true});
  if(window.visualViewport)window.visualViewport.addEventListener('resize',later,{passive:true});
  document.addEventListener('DOMContentLoaded',fitHome);
  window.addEventListener('load',fitHome);
  fitHome();
  setTimeout(fitHome,100);setTimeout(fitHome,300);setTimeout(fitHome,700);
})();
