/* V181 script 2; execution order preserved. */

document.addEventListener("DOMContentLoaded", function(){
  const game=document.getElementById("game");
  if(!game || game.dataset.v143HitReady) return;
  game.dataset.v143HitReady="1";
  const layer=document.createElement("div");
  layer.style.cssText="position:absolute;inset:0;z-index:85;pointer-events:none";
  game.appendChild(layer);

  function target(cls, left, top, width, height, selectors){
    const b=document.createElement("button");
    b.type="button";
    b.setAttribute("aria-label",cls);
    b.style.cssText=`position:absolute;left:${left};top:${top};width:${width};height:${height};opacity:0;border:0;background:transparent;pointer-events:auto`;
    b.addEventListener("click",function(){
      for(const s of selectors){
        const el=game.querySelector(s);
        if(el && el!==b){el.click();return}
      }
    });
    layer.appendChild(b);
  }
  target("Geri","1.5%","1%","13%","11%",[".v141Back"]);
  target("Ayarlar","86%","1%","13%","11%",[".v141Settings"]);
});
