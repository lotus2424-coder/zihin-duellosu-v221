/* V181 script 10; execution order preserved. */

(function(){
  function bind(){
    var appReady=typeof window.ZD==='object' || typeof window.ZD==='function';
    document.addEventListener('click',function(e){
      var el=e.target.closest && e.target.closest('[data-action]');
      if(!el)return;
      var action=el.dataset.action;
      if(action==='homeStart' && !appReady){
        document.querySelectorAll('.screen').forEach(function(x){x.classList.remove('active')});
        var c=document.getElementById('category'); if(c)c.classList.add('active');
      }
      if(action==='categoryBack' && !appReady){
        document.querySelectorAll('.screen').forEach(function(x){x.classList.remove('active')});
        var h=document.getElementById('home'); if(h)h.classList.add('active');
      }
      if(action==='categorySelect' && !appReady){
        document.querySelectorAll('.screen').forEach(function(x){x.classList.remove('active')});
        var m=document.getElementById('mode'); if(m)m.classList.add('active');
      }
    },true);
    if(!appReady){
      window.__ZD_BOOTSTRAP_FALLBACK__=true;
    }
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',bind,{once:true});else bind();
})();
