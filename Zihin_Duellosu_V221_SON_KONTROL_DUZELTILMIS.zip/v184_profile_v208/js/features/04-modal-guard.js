/* V181 script 3; execution order preserved. */

document.addEventListener("keydown",function(e){
  if(e.key==="Escape"){
    const m=document.getElementById("modal");
    if(m)m.classList.remove("show");
  }
});
window.addEventListener("popstate",function(){
  const m=document.getElementById("modal");
  if(m && m.classList.contains("show"))m.classList.remove("show");
});
