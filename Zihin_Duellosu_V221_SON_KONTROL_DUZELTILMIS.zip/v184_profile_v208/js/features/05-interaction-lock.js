/* V181 script 4; execution order preserved. */

(function(){
  function isInteractive(el){
    return !!(el && el.closest && el.closest('button,a,input,select,textarea,[role="button"]'));
  }
  document.addEventListener('selectstart', function(e){
    if(!isInteractive(e.target)) e.preventDefault();
  }, true);
  document.addEventListener('dragstart', function(e){
    e.preventDefault();
  }, true);
  document.addEventListener('contextmenu', function(e){
    if(!isInteractive(e.target)) e.preventDefault();
  }, true);
  document.addEventListener('gesturestart', function(e){
    e.preventDefault();
  }, {passive:false});
  document.addEventListener('touchstart', function(e){
    if(e.touches && e.touches.length > 1) e.preventDefault();
  }, {passive:false});
})();
