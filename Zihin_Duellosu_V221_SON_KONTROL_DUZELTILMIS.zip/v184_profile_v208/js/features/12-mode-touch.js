/* V181 script 11; execution order preserved. */

(function(){
  function bind(){
    var mode=document.getElementById('mode');
    if(!mode || mode.dataset.v166Bound==='1') return;
    mode.dataset.v166Bound='1';
    var map={
      modeBack:function(){ if(window.ZD&&typeof window.ZD.go==='function') window.ZD.go('category'); else fallback('category'); },
      modeSingle:function(){ if(window.ZD&&typeof window.ZD.start==='function') window.ZD.start(); else fallback('game'); },
      modeDuel:function(){ if(window.ZD&&typeof window.ZD.startDuel==='function') window.ZD.startDuel(); else fallback('game'); },
      modeSettings:function(){ fallbackModal('Ayarlar'); },
      modeReward1:function(){ if(window.ZD&&typeof window.ZD.go==='function') window.ZD.go('achievements'); else fallback('achievements'); },
      modeReward2:function(){ fallbackModal('Özel Avatarlar'); },
      modeReward3:function(){ fallbackModal('Unvanlar'); },
      modeReward4:function(){ fallbackModal('Tema Kartları'); }
    };
    function fallback(id){
      document.querySelectorAll('.screen').forEach(function(x){x.classList.remove('active')});
      var el=document.getElementById(id); if(el) el.classList.add('active');
    }
    function fallbackModal(title){
      var m=document.getElementById('modal'),t=document.getElementById('modalTitle'),b=document.getElementById('modalBody');
      if(m&&t&&b){t.textContent=title;b.innerHTML='<p>Bu bölüm hazır. Oyuna devam edebilirsin.</p>';m.classList.add('show');}
    }
    mode.querySelectorAll('[data-action]').forEach(function(btn){
      btn.addEventListener('touchend',function(e){
        if(e.cancelable)e.preventDefault();
        var fn=map[btn.dataset.action]; if(fn){e.stopPropagation();fn();}
      },{passive:false});
      btn.addEventListener('click',function(e){
        if(btn.dataset.v166Handled==='1'){btn.dataset.v166Handled='0';return;}
        var fn=map[btn.dataset.action]; if(fn){e.stopPropagation();fn();}
      });
    });
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',bind,{once:true});else bind();
})();
