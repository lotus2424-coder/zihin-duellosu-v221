/* V181 script 12; execution order preserved. */

(function(){
  function syncHomeViewport(){
    var home=document.getElementById('home');
    if(!home)return;
    var h=window.visualViewport?window.visualViewport.height:window.innerHeight;
    var w=window.visualViewport?window.visualViewport.width:window.innerWidth;
    home.style.setProperty('--viewport-w',w+'px');
    home.style.setProperty('--viewport-h',h+'px');
  }
  window.addEventListener('resize',syncHomeViewport,{passive:true});
  window.addEventListener('orientationchange',function(){setTimeout(syncHomeViewport,80);},{passive:true});
  if(window.visualViewport) window.visualViewport.addEventListener('resize',syncHomeViewport,{passive:true});
  document.addEventListener('DOMContentLoaded',syncHomeViewport,{once:true});
  syncHomeViewport();
})();
