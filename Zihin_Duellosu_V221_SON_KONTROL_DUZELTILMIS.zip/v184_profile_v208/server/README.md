# Zihin Düellosu — Online Backend + Gerçek Zamanlı Düello

Node 18+. **Artık `ws` paketine ihtiyaç var** (önceki sürümde yoktu, bu yüzden
WebSocket düello çalışmıyordu). Kurulumdan önce mutlaka:

```
npm install
```

## Çalıştırma
`ZD_SECRET` değerini üretim öncesi değiştirin:
```
ZD_SECRET="uzun-rastgele-bir-secret" npm start
```
Varsayılan port: `8787`.

## Bu backend neyi karşılıyor, neyi karşılamıyor
- **Gerçek zamanlı Düello (WebSocket)**: Bu backend'in tek gerçek işi bu. Rakip
  eşleştirme, soru gönderme, cevap toplama, puanlama ve maç sonucu burada, bellekte
  (in-memory) yönetilir. Sunucu yeniden başlarsa devam eden maçlar sıfırlanır — bu
  normaldir.
- **Google ile giriş, profil, XP, lider tablosu, çevrimiçi sayaç**: Bunlar bu
  backend'i KULLANMAZ. Bunlar tamamen Supabase üzerinden (`js/core/supabase-client.js`,
  `js/core/online-service.js`) yürür. Yani bu sunucuyu deploy etmek Google girişini
  düzeltmez — o ayrı bir konfigürasyon meselesi (bkz. proje kökündeki kurulum notu).
- `/api/guest` sadece düello için anonim/misafir bir oyuncu kimliği (token) üretir.

## Deploy (zorunlu — telefon/itch.io'dan bağlanmak için)
`ws://localhost:8787` sadece kendi bilgisayarınızda çalışır; itch.io'da oynayan
gerçek kullanıcılar buna asla ulaşamaz. Bu yüzden:
1. Bu `server/` klasörünü Render, Railway, Fly.io gibi Node çalıştırabilen bir
   servise deploy edin (build: `npm install`, start: `npm start`).
2. Servis size `https://xxxx.onrender.com` gibi bir adres verecek. Düello WebSocket
   için bunun `wss://` hali kullanılır: `wss://xxxx.onrender.com`.
3. Oyunun kökündeki `index.html` içinde `window.ZD_DUEL_URL` satırını bu adresle
   güncelleyin, projeyi yeniden zip'leyip itch.io'ya yükleyin.

## API (misafir/düello + eski REST uçları)
- `POST /api/guest` — düello için kalıcı misafir oyuncu kimliği oluşturur
- `GET/PUT /api/profile`, `POST /api/score`, `POST /api/online/heartbeat`,
  `GET /api/online/count`, `GET /api/leaderboard` — eski REST uçları (opsiyonel,
  şu an ön yüzde kullanılmıyor, Supabase kullanılıyor)

Üretimde kalıcı disk/database önerilir; bu örnek backend JSON dosyası kullanır ve
düello eşleşmeleri bellekte tutulur (kalıcı değildir, restart'ta sıfırlanır).
