// Zihin Düellosu — Online Backend + GERÇEK ZAMANLI DÜELLO (WebSocket)
// Node 18+; "ws" paketi gerekir (package.json içinde eklendi, `npm install` şart).
// Deploy: Render/Railway/Fly.io gibi bir yere koy, HTTPS + WSS ile yayınla,
// sonra index.html içindeki window.ZD_DUEL_URL değerini bu adresin wss:// haline eşitle.
'use strict';
const http=require('http'), crypto=require('crypto'), fs=require('fs'), path=require('path');
const { WebSocketServer } = require('ws');

const PORT=Number(process.env.PORT||8787);
const SECRET=process.env.ZD_SECRET||'change-this-secret-before-production';
const DATA_DIR=path.join(__dirname,'data'), DATA_FILE=path.join(DATA_DIR,'data.json');
fs.mkdirSync(DATA_DIR,{recursive:true});
function read(){try{return JSON.parse(fs.readFileSync(DATA_FILE,'utf8'))}catch{return {players:{},scores:[],presence:{}}}}
function write(d){fs.writeFileSync(DATA_FILE,JSON.stringify(d,null,2))}
function b64(o){return Buffer.from(JSON.stringify(o)).toString('base64url')}
function tokenFor(id){const h=b64({alg:'HS256',typ:'JWT'}),p=b64({sub:id,iat:Date.now()});const s=crypto.createHmac('sha256',SECRET).update(h+'.'+p).digest('base64url');return h+'.'+p+'.'+s}
function auth(req){const t=(req.headers.authorization||'').replace(/^Bearer\s+/,'');return verifyToken(t)}
function verifyToken(t){
 try{
  const a=String(t||'').split('.'); if(a.length!==3)return null;
  const sig=crypto.createHmac('sha256',SECRET).update(a[0]+'.'+a[1]).digest('base64url');
  if(sig.length!==a[2].length)return null;
  if(!crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(a[2])))return null;
  return JSON.parse(Buffer.from(a[1],'base64url').toString()).sub;
 }catch{return null}
}
function send(res,status,obj){const body=JSON.stringify(obj);res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type, Authorization','Access-Control-Allow-Methods':'GET,POST,PUT,OPTIONS'});res.end(body)}
function body(req){return new Promise((resolve,reject)=>{let s='';req.on('data',c=>{s+=c;if(s.length>1e6)req.destroy()});req.on('end',()=>{try{resolve(s?JSON.parse(s):{})}catch(e){reject(e)}})})}
function cleanName(v){return String(v||'Zihin Oyuncusu').replace(/[<>]/g,'').trim().slice(0,32)||'Zihin Oyuncusu'}

/* ============================================================
   GERÇEK ZAMANLI DÜELLO (WebSocket) — bu bölüm eskiden YOKTU.
   Ön yüz (duel-client.js) bir WebSocket protokolü bekliyordu ama
   bu dosya sadece düz HTTP API sağlıyordu; "Düello bağlantısı /
   Load failed" hatasının asıl sebebi buydu. Aşağıda gerçek
   eşleştirme + soru + puan mantığı uygulanıyor.
   ============================================================ */
const ROUND_COUNT=10, ROUND_MS=20000, MAX_WRONG=4, RECONNECT_GRACE_MS=20000;

let QUESTION_BANK=[];
try{
 let raw=fs.readFileSync(path.join(__dirname,'..','js','data','question-bank.js'),'utf8');
 raw=raw.replace(/^\/\*[\s\S]*?\*\//,'').trim();
 raw=raw.replace(/^window\.ZD_QUESTION_BANK\s*=\s*/,'').replace(/;\s*$/,'');
 QUESTION_BANK=JSON.parse(raw);
 console.log(`Soru bankası yüklendi: ${QUESTION_BANK.length} soru`);
}catch(e){ console.error('Soru bankası yüklenemedi:', e.message); }

const byCategory=new Map();
for(const q of QUESTION_BANK){const k=q.category||'Karışık'; if(!byCategory.has(k))byCategory.set(k,[]); byCategory.get(k).push(q);}

function pickQuestions(category,count){
 const pool=(category && category!=='Karışık' && byCategory.has(category)) ? byCategory.get(category) : QUESTION_BANK;
 const copy=pool.slice(); const out=[];
 for(let i=0;i<count && copy.length;i++){const idx=Math.floor(Math.random()*copy.length); out.push(copy.splice(idx,1)[0]);}
 return out;
}
function publicQuestion(q){return {question:q.question,options:q.options,category:q.category,level:q.level};}
function playerName(id){const d=read(); return d.players[id]?.displayName || 'Oyuncu';}

const queues=new Map();     // category -> [{playerId,name}]
const matches=new Map();    // matchId -> match
const sockets=new Map();    // playerId -> ws (aktif bağlantı)

function wsSend(ws,obj){ if(ws && ws.readyState===1) ws.send(JSON.stringify(obj)); }
function removeFromQueues(playerId){ for(const list of queues.values()){ const i=list.findIndex(p=>p.playerId===playerId); if(i!==-1) list.splice(i,1); } }
function matchOf(playerId){ for(const m of matches.values()) if(!m.finished && m.players.includes(playerId)) return m; return null; }

function createMatch(a,b,category){
 const id=crypto.randomUUID();
 const questions=pickQuestions(category,ROUND_COUNT);
 const match={
  id,category,questions,round:0,finished:false,
  players:[a.playerId,b.playerId],
  state:{
   [a.playerId]:{name:a.name,score:0,correct:0,wrong:0,combo:0,answer:undefined,timedOut:false},
   [b.playerId]:{name:b.name,score:0,correct:0,wrong:0,combo:0,answer:undefined,timedOut:false}
  },
  disconnectTimers:{}, roundTimer:null
 };
 matches.set(id,match);
 return match;
}

function sendQuestion(match){
 match.round++;
 for(const pid of match.players){ match.state[pid].answer=undefined; match.state[pid].timedOut=false; }
 const q=match.questions[match.round-1];
 const deadlineAt=Date.now()+ROUND_MS;
 const payload={type:'question',round:match.round,total:match.questions.length,deadlineMs:ROUND_MS,deadlineAt,question:publicQuestion(q)};
 for(const pid of match.players) wsSend(sockets.get(pid),payload);
 clearTimeout(match.roundTimer);
 match.roundTimer=setTimeout(()=>resolveRound(match),ROUND_MS+800);
}

function resolveRound(match){
 if(match.finished)return;
 clearTimeout(match.roundTimer);
 const q=match.questions[match.round-1];
 const results=[];
 for(const pid of match.players){
  const st=match.state[pid];
  if(st.answer===undefined) st.timedOut=true;
  const ok=!st.timedOut && st.answer===q.correct;
  if(ok){ st.combo++; st.correct++; st.score+=100+Math.min(st.combo,5)*20; }
  else{ st.combo=0; st.wrong++; }
  results.push({id:pid,ok,score:st.score,combo:st.combo,hearts:st.wrong,timedOut:!!st.timedOut});
 }
 const payload={type:'round_result',results,correct:q.correct,explanation:q.explanation,fact:q.fact};
 for(const pid of match.players) wsSend(sockets.get(pid),payload);
 const heartsOut=match.players.some(pid=>match.state[pid].wrong>=MAX_WRONG);
 if(match.round>=match.questions.length || heartsOut) setTimeout(()=>finishMatch(match),900);
 else setTimeout(()=>sendQuestion(match),1600);
}

function finishMatch(match){
 if(match.finished)return; match.finished=true; clearTimeout(match.roundTimer);
 const standings=match.players.map(pid=>({playerId:pid,name:match.state[pid].name,score:match.state[pid].score,correct:match.state[pid].correct,wrong:match.state[pid].wrong}));
 let winnerId=null;
 if(standings[0].score!==standings[1].score) winnerId=standings[0].score>standings[1].score?standings[0].playerId:standings[1].playerId;
 else if(standings[0].correct!==standings[1].correct) winnerId=standings[0].correct>standings[1].correct?standings[0].playerId:standings[1].playerId;
 const payload={type:'match_result',standings,winnerId};
 for(const pid of match.players) wsSend(sockets.get(pid),payload);
 setTimeout(()=>matches.delete(match.id),30000);
}

function handleAnswer(playerId,msg){
 const match=matches.get(msg.matchId)||matchOf(playerId);
 if(!match||match.finished)return;
 if(msg.round!==match.round)return;
 const st=match.state[playerId]; if(!st||st.answer!==undefined)return;
 st.answer=msg.timedOut?null:msg.answer; st.timedOut=!!msg.timedOut;
 const other=match.players.find(p=>p!==playerId);
 if(match.state[other].answer!==undefined) resolveRound(match);
}

function handleJoin(playerId,name,category){
 removeFromQueues(playerId);
 const cat=category||'Karışık';
 const list=queues.get(cat)||[]; queues.set(cat,list);
 const opponent=list.shift();
 if(opponent && opponent.playerId!==playerId){
  const match=createMatch(opponent,{playerId,name},cat);
  for(const pid of match.players){
   const opp=match.players.find(p=>p!==pid);
   wsSend(sockets.get(pid),{type:'match_found',matchId:match.id,round:0,opponent:match.state[opp].name});
  }
  sendQuestion(match);
 }else{
  list.push({playerId,name});
  wsSend(sockets.get(playerId),{type:'queue_wait'});
 }
}

function handleLeave(playerId){
 removeFromQueues(playerId);
 const match=matchOf(playerId);
 if(match && !match.finished){
  match.finished=true; clearTimeout(match.roundTimer);
  const other=match.players.find(p=>p!==playerId);
  wsSend(sockets.get(other),{type:'match_result',standings:match.players.map(pid=>({playerId:pid,name:match.state[pid].name,score:match.state[pid].score,correct:match.state[pid].correct,wrong:match.state[pid].wrong})),winnerId:other});
 }
}

function handleDisconnect(playerId){
 sockets.delete(playerId);
 removeFromQueues(playerId);
 const match=matchOf(playerId);
 if(match && !match.finished){
  clearTimeout(match.disconnectTimers[playerId]);
  match.disconnectTimers[playerId]=setTimeout(()=>{ if(!match.finished && !sockets.get(playerId)) handleLeave(playerId); },RECONNECT_GRACE_MS);
 }
}

const wss=new WebSocketServer({noServer:true});
wss.on('connection',(ws)=>{
 let playerId=null;
 ws.on('message',(raw)=>{
  let msg; try{msg=JSON.parse(raw)}catch{return}
  if(msg.type==='hello'){
   playerId=verifyToken(msg.token);
   if(!playerId){ wsSend(ws,{type:'error',message:'Oturum doğrulanamadı, lütfen tekrar deneyin.'}); try{ws.close()}catch{}; return; }
   sockets.set(playerId,ws);
   const m=matchOf(playerId);
   wsSend(ws,{type:'hello_ok',playerId,matchId:m?m.id:null});
   return;
  }
  if(!playerId)return;
  if(msg.type==='resume'){
   const match=matches.get(msg.matchId)||matchOf(playerId);
   if(!match||match.finished)return;
   clearTimeout(match.disconnectTimers[playerId]);
   const st=match.state[playerId];
   wsSend(ws,{type:'resumed',matchId:match.id,round:match.round,answered:st.answer!==undefined});
   if(st.answer===undefined && match.round>0){
    const q=match.questions[match.round-1];
    wsSend(ws,{type:'question',round:match.round,total:match.questions.length,deadlineMs:ROUND_MS,deadlineAt:Date.now()+ROUND_MS,question:publicQuestion(q)});
   }
   return;
  }
  if(msg.type==='queue_join'){ handleJoin(playerId,playerName(playerId),msg.category); return; }
  if(msg.type==='queue_leave'){ handleLeave(playerId); return; }
  if(msg.type==='answer'){ handleAnswer(playerId,msg); return; }
 });
 ws.on('close',()=>{ if(playerId) handleDisconnect(playerId); });
});

/* ============================================================
   Mevcut HTTP API (misafir kimliği, profil, skor, lider tablosu)
   — bu kısım değişmedi, olduğu gibi korundu.
   ============================================================ */
const server=http.createServer(async(req,res)=>{
 if(req.method==='OPTIONS'){send(res,204,{});return}
 const u=new URL(req.url,`http://${req.headers.host}`), d=read();

  // Optional static hosting: deploy the whole v185_profile directory with this server.
  if(req.method==='GET' && u.pathname!=='/api/profile' && !u.pathname.startsWith('/api/')){
    const rel=decodeURIComponent(u.pathname==='/'?'/index.html':u.pathname).replace(/^\/+/,'');
    const file=path.resolve(__dirname,'..',rel);
    const rootReal=path.resolve(__dirname,'..');
    if(file.startsWith(rootReal+path.sep) && fs.existsSync(file) && fs.statSync(file).isFile()){
      const ext=path.extname(file).toLowerCase();
      const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webmanifest':'application/manifest+json'}[ext]||'application/octet-stream';
      res.writeHead(200,{'Content-Type':mime,'Cache-Control':ext==='.html'?'no-store':'public, max-age=3600'});
      fs.createReadStream(file).pipe(res); return;
    }
  }
 try{
  if(req.method==='POST'&&u.pathname==='/api/guest'){
   const id=crypto.randomUUID();const x=await body(req);
   d.players[id]={id,displayName:cleanName(x.name),avatar:x.avatar||'brain',title:x.title||'Meraklı Zihin',theme:x.theme||'midnight',xp:0,level:1,games:0,correct:0,wrong:0,bestScore:0,duelsWon:0,streak:0,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};
   d.presence[id]=Date.now();write(d);send(res,200,{token:tokenFor(id),playerId:id});return;
  }
  const id=auth(req);if(!id){send(res,401,{error:'AUTH_REQUIRED'});return}
  if(!d.players[id]){send(res,404,{error:'PLAYER_NOT_FOUND'});return}
  if(req.method==='GET'&&u.pathname==='/api/profile'){send(res,200,d.players[id]);return}
  if(req.method==='PUT'&&u.pathname==='/api/profile'){
   const x=await body(req), p=d.players[id];
   for(const k of ['displayName','avatar','title','theme','xp','level','games','correct','wrong','bestScore','duelsWon','streak'])if(x[k]!==undefined)p[k]=typeof x[k]==='string'?cleanName(x[k]):Number(x[k]||0);
   p.updatedAt=new Date().toISOString();d.presence[id]=Date.now();write(d);send(res,200,p);return;
  }
  if(req.method==='POST'&&u.pathname==='/api/score'){
   const x=await body(req);const p=d.players[id];
   const score=Number(x.score||0),correct=Number(x.correct||0),wrong=Number(x.wrong||0);
   d.scores.push({id:crypto.randomUUID(),playerId:id,score,correct,wrong,xp:Number(x.xp||0),mode:String(x.mode||'single'),category:String(x.category||'Karışık'),durationMs:Number(x.durationMs||0),createdAt:x.createdAt||new Date().toISOString()});
   p.bestScore=Math.max(Number(p.bestScore||0),score);p.updatedAt=new Date().toISOString();d.presence[id]=Date.now();if(d.scores.length>100000)d.scores=d.scores.slice(-100000);write(d);send(res,200,{ok:true});return;
  }
  if(req.method==='POST'&&u.pathname==='/api/online/heartbeat'){d.presence[id]=Date.now();write(d);send(res,200,{ok:true});return}
  if(req.method==='GET'&&u.pathname==='/api/online/count'){
   const cutoff=Date.now()-90000;const count=Object.values(d.presence).filter(t=>Number(t)>cutoff).length;send(res,200,{count,ttlSec:90});return;
  }
  if(req.method==='GET'&&u.pathname==='/api/leaderboard'){
   const limit=Math.min(50,Math.max(1,Number(u.searchParams.get('limit')||20)));
   const cutoff=Date.now()-90000;
   const agg=new Map();
   for(const s of d.scores){const a=agg.get(s.playerId)||{score:0,games:0,xp:0};a.score+=s.score;a.games++;a.xp+=s.xp;agg.set(s.playerId,a)}
   const players=Object.values(d.players).map(p=>{const a=agg.get(p.id)||{score:0,games:0,xp:0};return {...p,score:a.score,xpTotal:a.xp,online:Number(d.presence[p.id]||0)>cutoff}}).sort((a,b)=>b.score-a.score).slice(0,limit);
   const onlineCount=Object.values(d.presence).filter(t=>Number(t)>cutoff).length;
   send(res,200,{players,onlineCount,updatedAt:new Date().toISOString()});return;
  }
  send(res,404,{error:'NOT_FOUND'});
 }catch(e){send(res,500,{error:'SERVER_ERROR'})}
});

server.on('upgrade',(req,socket,head)=>{
 wss.handleUpgrade(req,socket,head,(ws)=>wss.emit('connection',ws,req));
});

server.listen(PORT,()=>console.log(`Zihin Düellosu online backend + WebSocket düello dinliyor: :${PORT}`));
